Create an elegant, luxurious landing page for "Lumière Aesthetics" — a premium med spa and aesthetics center.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #9C7C5C (warm champagne/gold)
- Primary Dark: #806040 (deeper gold for hover)
- Accent: #C9A96E (luxe gold)
- Rose: #D4A0A0 (soft rose)
- Light BG: #FAF8F5 (warm ivory)
- Dark: #1F1A16 (espresso black)
- Dark Surface: #2E2620
- Light Text: #FFFFFF
- Body Text: #5C524A (warm charcoal)
- Muted: #9A918A
- Card BG: #FFFFFF

### Typography
- Headings: weight 300-600, elegant serif feel — luxurious and refined
- Section subtitles: uppercase, letter-spacing=5px, size=11px, color=#C9A96E, weight=500
- Body text: size 16px, color=#5C524A, line-height 1.9

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=300
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=500
- Hero buttons: _animation='fadeInUp', _animation_delay=700
- Section headings: _animation='fadeIn', animation_duration='slow', _animation_delay=0
- Treatment cards: _animation='fadeIn', animation_duration='slow', stagger 150ms
- About image: _animation='fadeInLeft', animation_duration='slow'
- About text: _animation='fadeInRight', animation_duration='slow', _animation_delay=200
- Before/after: _animation='fadeIn', animation_duration='slow', stagger 200ms
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "med spa luxury interior elegant" — hero background
2. "facial treatment spa professional" — treatments
3. "woman beautiful skin glowing portrait" — results
4. "dermal filler injection professional" — services
5. "laser treatment skin rejuvenation" — services
6. "spa relaxation room candles" — atmosphere
7. "botox consultation doctor patient" — about
8. "luxury spa product skincare" — products

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Elegant, thin line icons:
- Sparkle/diamond icon (luxury)
- Syringe icon (injectables)
- Face/beauty icon (facial treatments)
- Laser icon (laser services)
- Shield icon (safety)
- Star icon (reviews)
- Clock icon (appointments)
- Phone icon (consultations)
- Map pin icon (location)
- Leaf icon (natural beauty)

## PAGE STRUCTURE

### 1. HERO SECTION
Full-width container:
- Background: sideloaded luxury spa interior, background_size='cover'
- Overlay: background_overlay_color='#1F1A16', background_overlay_opacity={size:0.5,unit:'px'}
- Min-height: {size:700,unit:'px'}
- Padding: {top:'120',right:'0',bottom:'120',left:'0',unit:'px'}
- Centered content:
  - Small label: "MEDICAL AESTHETICS · LUXURY CARE" — color=#C9A96E, size=12px, letter-spacing=6px, _animation='fadeIn', _animation_delay=0
  - Main heading: "Where Science Meets Beauty" — color=#FFFFFF, size=54px, weight=300, _animation='fadeIn', _animation_delay=300
  - Subtext: "Board-certified physicians delivering premium aesthetic treatments in an environment of unparalleled luxury and discretion." — color=#FAF8F5, size=17px, _animation='fadeIn', _animation_delay=500
  - Row with buttons (_animation='fadeInUp', _animation_delay=700):
    - "Book Consultation" — background_color=#C9A96E, text_color=#1F1A16, border_radius={top:2,right:2,bottom:2,left:2,unit:'px'}
    - "View Treatments" — border_color='#C9A96E', text_color=#C9A96E

### 2. TRUST STRIP
- Background: background_background='classic', background_color='#1F1A16'
- Padding: {top:'30',right:'0',bottom:'30',left:'0',unit:'px'}
- Row with 4 children:
  - "Board Certified" | "10+ Years" | "5,000+ Treatments" | "5-Star Rated"
  - Icon color=#C9A96E, text color=#FFFFFF

### 3. TREATMENTS (2 rows of 3)
- Background: background_background='classic', background_color='#FAF8F5'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "TREATMENTS" — color=#C9A96E, centered
- Heading: "Our Signature Services" — color=#1F1A16, weight=400, centered, _animation='fadeIn'
- Row 1: 3 treatment cards (_animation='fadeIn', stagger 150ms)
- Row 2: 3 treatment cards

  Each card: white bg, padding, border_radius={top:4,right:4,bottom:4,left:4,unit:'px'}, text-align center
  - SVG icon (color=#C9A96E, large)
  - Treatment name: "Botox & Dysport" — color=#1F1A16, size=18px, weight=600
  - Description — color=#5C524A, size=14px
  - Starting price: "from $12/unit" — color=#C9A96E, size=14px, weight=500

  Treatments:
  - Row 1: Botox & Dysport (from $12/unit) | Dermal Fillers (from $650) | Chemical Peels (from $150)
  - Row 2: Laser Skin Rejuvenation (from $300) | Microneedling (from $250) | Body Contouring (from $500)

### 4. ABOUT (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left: Image (doctor/consultation), _animation='fadeInLeft'
  - Right:
    - Subtitle: "OUR APPROACH" — color=#C9A96E, _animation='fadeInRight'
    - Heading: "Artistry Meets Precision" — color=#1F1A16, weight=400, _animation='fadeInRight', _animation_delay=100
    - Text: Board-certified physicians, personalized treatment plans, natural-looking results — _animation='fadeInRight', _animation_delay=200
    - Credentials: "Board Certified Dermatologist" | "Fellowship Trained" | "10,000+ Procedures" | "Published Researcher"

### 5. RESULTS / WHY CHOOSE (on dark)
- Background: background_background='classic', background_color='#1F1A16'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "WHY LUMIÈRE" — color=#C9A96E, centered
- Heading: "The Lumière Difference" — color=#FFFFFF, weight=300, centered, _animation='fadeIn'
- Row with 3 benefit cards (_animation='fadeIn', stagger 150ms):
  - Each: background_color='#2E2620', padding, border_radius, centered
  - Icon (color=#C9A96E)
  - Title: "Medical Expertise" — color=#FFFFFF
  - Description — color=#9A918A
  - Benefits: Medical Expertise | Natural Results | Luxury Experience

### 6. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#FAF8F5'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row with 3 cards (_animation='fadeIn', stagger 150ms):
  - White bg, subtle border, padding
  - Star rating (color=#C9A96E)
  - Quote — italic
  - Name + "Verified Patient"

### 7. CONSULTATION CTA (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left (_animation='fadeInLeft'):
    - Subtitle: "GET STARTED" — color=#C9A96E
    - Heading: "Complimentary Consultation" — color=#1F1A16, weight=400
    - Text: "Every journey begins with a personalized consultation. Our physicians will create a custom treatment plan tailored to your unique goals."
    - Button: "Book Now" — background_color=#C9A96E, text_color=#1F1A16
  - Right (_animation='fadeInRight'): Image (spa atmosphere)

### 8. LOCATION
- Background: background_background='classic', background_color='#FAF8F5'
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Row:
  - Left: Address, phone, hours (Mon-Fri 9AM-6PM, Sat 9AM-3PM)
  - Right: Google Maps

### 9. FOOTER
- Background: background_background='classic', background_color='#1F1A16'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row with 4 columns (_animation='fadeIn', stagger)
- Divider + copyright

## CUSTOM CSS (minimal)

### Page-Level CSS:
```css
html { scroll-behavior: smooth; }

.elementor-button {
  transition: all 0.4s ease !important;
}
.elementor-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 30px rgba(201, 169, 110, 0.3);
}

::selection {
  background: #C9A96E;
  color: #FFFFFF;
}
```

### Element-Level CSS — Treatment Cards:
```css
selector {
  transition: transform 0.5s ease, box-shadow 0.5s ease;
  border: 1px solid #FAF8F5;
}
selector:hover {
  transform: translateY(-6px);
  box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
  border-color: #C9A96E;
}
```

## CUSTOM JAVASCRIPT
Use `add-custom-js` with wrap_dom_ready=true.

```javascript
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 40);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 40);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** with _animation settings
4. **Apply page-level CSS**
5. **Apply element-level CSS** for treatment cards
6. **Inject custom JS**

## FINAL CHECKLIST
- Luxurious, elegant aesthetic — golds, champagne, ivories
- Slow, graceful animations (animation_duration='slow') — refined feel
- Trust elements: board certified, years, treatment count
- Treatment cards with starting prices
- NO flex_wrap or _flex_size
- Publish the page as draft
