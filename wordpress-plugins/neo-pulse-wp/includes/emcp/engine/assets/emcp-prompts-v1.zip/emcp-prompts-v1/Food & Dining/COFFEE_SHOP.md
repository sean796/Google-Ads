Create a warm, inviting landing page for "Ember & Brew" — an artisan coffee shop and roastery.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM (use consistently across ALL sections)

### Color Palette
- Primary: #2C1810 (rich espresso brown)
- Primary Light: #4A2C20 (lighter brown)
- Accent: #D4A574 (warm caramel/latte)
- Accent Dark: #B8895A (darker caramel for hover)
- Warm: #E8D5C0 (cream/latte foam)
- Dark: #1A0E0A (deep dark chocolate)
- Light Text: #FFFFFF
- Body Text: #5C4A3A (warm brown-gray)
- Light BG: #FAF6F1 (warm off-white/paper)
- Card BG: #FFFFFF
- Olive Accent: #5C6B4A (earthy green for organic feel)

### Typography
- Headings: weight 700-800, title case (warm and friendly, not uppercase)
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#D4A574, weight=600
- Body text: size 16-17px, color=#5C4A3A, line-height 1.8
- Display headings: consider a handwritten/script feel using italic styling

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required
- For overlays: background_overlay_background='classic', background_overlay_color='#hex', background_overlay_opacity={size:0.65,unit:'px'}

## IMAGE SOURCING — DO THIS FIRST
Before building the page, use the search-images and sideload-image tools:
1. "coffee shop interior cozy warm" — for hero background
2. "latte art barista professional" — for about section
3. "coffee beans roasting close up" — for roasting section
4. "espresso machine pouring coffee" — for menu/gallery
5. "pastry croissant coffee shop display" — for menu/food
6. "coffee shop cozy seating wooden" — for atmosphere
7. "iced coffee cold brew summer" — for menu
8. "coffee bag packaging artisan" — for shop/products

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Do NOT use Elementor's icon library. Warm, friendly line icons:
- Coffee cup icon (general)
- Coffee bean icon (roasting)
- Leaf icon (organic/sustainability)
- Clock icon (hours)
- Map pin icon (location)
- Star icon (reviews)
- Wifi icon (amenities)
- Music note icon (ambiance)
- Heart icon (favorites)
- Shopping bag icon (shop)

## PAGE STRUCTURE

### 1. HERO SECTION (full-screen atmospheric)
Full-width container:
- Background: sideloaded coffee shop interior, background_size='cover', background_position='center center'
- Overlay: background_overlay_color='#1A0E0A', background_overlay_opacity={size:0.55,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Centered content:
  - Small label: "ARTISAN COFFEE · SINCE 2015" — color=#D4A574, size=13px, uppercase, letter-spacing=4px
  - Main heading: "Where Every Cup Tells a Story" — color=#FFFFFF, size=52px, weight=700
  - Subtext: "Hand-roasted beans, crafted with care. Experience coffee the way it was meant to be — freshly ground, expertly brewed, served with warmth." — color=#E8D5C0, size=18px
  - Row with buttons:
    - "View Our Menu" — background_color=#D4A574, text_color=#1A0E0A, border_radius={top:30,right:30,bottom:30,left:30,unit:'px'}
    - "Order Online" — background=transparent, border_color='#D4A574', text_color=#D4A574, border_radius rounded
  - Small text: "Open Daily 6AM — 9PM" — color=#E8D5C0, size=14px

### 2. FEATURE STRIP (3 highlights)
- Background: background_background='classic', background_color='#2C1810'
- Padding: {top:'30',right:'0',bottom:'30',left:'0',unit:'px'}
- Row container with 3 children:
  - Each: centered row container with SVG icon + text
  - "Freshly Roasted Daily" | "100% Organic Beans" | "Free WiFi & Cozy Vibes"
  - Icon color=#D4A574, text color=#E8D5C0, size=14px

### 3. ABOUT / STORY SECTION (2-column: image left, text right)
- Background: background_background='classic', background_color='#FAF6F1'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left: Image widget (barista latte art), border_radius={top:12,right:12,bottom:12,left:12,unit:'px'}
  - Right (align_items='flex-start'):
    - Subtitle: "OUR STORY" — color=#D4A574
    - Heading: "Passion in Every Pour" — color=#2C1810, size=36px
    - Text: 2 paragraphs about founding story, sourcing beans from small farms, the craft of roasting — color=#5C4A3A
    - Row with small stats:
      - "8+" / "Bean Origins" — heading color=#2C1810, text color=#5C4A3A
      - "10K+" / "Cups Daily"
      - "100%" / "Organic"

### 4. MENU SECTION (popular items — 2 rows of 3)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "MENU HIGHLIGHTS" — color=#D4A574, centered
- Heading: "Our Most Loved Drinks" — color=#2C1810, centered
- Row 1: 3 cards side by side
- Row 2: 3 more cards

  Each menu card (column container):
  - Image widget (coffee/pastry image), border_radius top corners
  - Content area: background_color='#FFFFFF', padding, border (subtle #E8D5C0)
  - Item name heading: "Signature Caramel Latte" — color=#2C1810, size=18px
  - Description: short 1-line desc — color=#5C4A3A, size=14px
  - Price: "$5.50" — color=#D4A574, size=20px, weight=700

  Items:
  - Row 1: Signature Caramel Latte ($5.50) | Single Origin Pour Over ($4.75) | Ember Cold Brew ($5.25)
  - Row 2: Matcha Oat Latte ($6.00) | Classic Espresso ($3.50) | Honey Lavender Cappuccino ($6.25)

### 5. ROASTING SECTION (2-column: text left, image right)
- Background: background_background='classic', background_color='#2C1810'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left (align_items='flex-start'):
    - Subtitle: "THE ROASTERY" — color=#D4A574
    - Heading: "Small Batch, Big Flavor" — color=#FFFFFF, size=36px
    - Text: About the roasting process, sourcing, quality — color=#E8D5C0
    - Icon list or text list: "Single-origin sourcing" | "Roasted in-house weekly" | "Fair trade certified" — color=#E8D5C0
  - Right: Image widget (roasting beans), border_radius

### 6. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#FAF6F1'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle + heading centered
- Row with 3 cards:
  - Each: white background, padding, border_radius, border (#E8D5C0)
  - Star rating (5 stars, color=#D4A574)
  - Quote — color=#5C4A3A, italic
  - Name (#2C1810, bold) + "Regular Customer" (#8B7A6A)

### 7. VISIT US / LOCATION (2-column: info left, map right)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left:
    - Subtitle: "FIND US" — color=#D4A574
    - Heading: "Visit Ember & Brew" — color=#2C1810
    - Address, phone, email — color=#5C4A3A with SVG icons
    - Hours: "Mon-Fri: 6AM-9PM | Sat-Sun: 7AM-10PM" — color=#5C4A3A
    - Row with amenity badges: "Free WiFi" | "Pet Friendly" | "Outdoor Seating"
  - Right: Google Maps widget with a real US coffee shop address

### 8. CTA SECTION (order online / subscribe)
- Background: sideloaded cozy seating image, background_size='cover'
- Overlay: background_overlay_color='#1A0E0A', background_overlay_opacity={size:0.7,unit:'px'}
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered:
  - Heading: "Start Your Morning Right" — color=#FFFFFF, size=40px
  - Subtext: "Order ahead and skip the line, or subscribe for monthly bean deliveries." — color=#E8D5C0
  - Row with buttons:
    - "Order Now" — background_color=#D4A574, text_color=#1A0E0A
    - "Subscribe to Beans" — border_color='#D4A574', text_color=#D4A574

### 9. FOOTER
- Background: background_background='classic', background_color='#1A0E0A'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row with 4 columns:
  - Col 1: "Ember & Brew" heading + tagline — color=#E8D5C0 / #FFFFFF
  - Col 2: "Menu" links — color=#8B7A6A
  - Col 3: "About" links — color=#8B7A6A
  - Col 4: "Contact" info — color=#8B7A6A
- Divider (color=#2C1810)
- Copyright: "© 2026 Ember & Brew Coffee. All rights reserved." — color=#5C4A3A

## CUSTOM CSS — APPLY AFTER PAGE IS BUILT

### Page-Level CSS (no element_id):
```css
html { scroll-behavior: smooth; }

/* Warm button hover */
.elementor-button {
  transition: all 0.3s ease !important;
}
.elementor-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(212, 165, 116, 0.3);
}

/* Image hover zoom */
.elementor-image img {
  transition: transform 0.6s ease;
}
.elementor-image:hover img {
  transform: scale(1.05);
}

/* Warm glow selection */
::selection {
  background: #D4A574;
  color: #FFFFFF;
}
```

### Element-Level CSS — Menu Cards:
```css
selector {
  transition: transform 0.4s ease, box-shadow 0.4s ease;
  overflow: hidden;
}
selector:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 50px rgba(44, 24, 16, 0.12);
}
```

### Element-Level CSS — Testimonial Cards:
```css
selector {
  transition: transform 0.3s ease;
}
selector:hover {
  transform: translateY(-5px);
}
```

### Element-Level CSS — Feature Strip Icons:
```css
selector {
  transition: transform 0.3s ease;
}
selector:hover {
  transform: scale(1.05);
}
```

## CUSTOM JAVASCRIPT — APPLY AFTER PAGE IS BUILT
Use `add-custom-js` with wrap_dom_ready=true.

### Scroll Animations + Counters (add-custom-js, wrap_dom_ready=true):
```javascript
// Fade-in on scroll
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });

document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-icon-box-wrapper, .elementor-widget-text-editor').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(25px)';
  el.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
  observer.observe(el);
});

// Counter animation
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 35);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 35);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});

// Steam animation on coffee images (subtle float)
document.querySelectorAll('.elementor-image').forEach((img, i) => {
  if (i < 2) {
    img.style.animation = `float ${3 + i * 0.5}s ease-in-out infinite`;
  }
});

const style = document.createElement('style');
style.textContent = `
  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-6px); }
  }
`;
document.head.appendChild(style);
```

## SITE-WIDE CODE SNIPPET (Optional — Pro only)
- Title: "Ember & Brew - Smoothing & Preload"
- Location: head
- Priority: 1
- Code:
```html
<style>
  html { scroll-behavior: smooth; }
  body { -webkit-font-smoothing: antialiased; }
  ::selection { background: #D4A574; color: #FFFFFF; }
</style>
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** using build-page
4. **Apply page-level CSS** (no element_id)
5. **Apply element-level CSS** for: menu cards, testimonial cards, feature strip
6. **Inject custom JS** with wrap_dom_ready=true
7. **Create site-wide snippet** (optional, Pro only)

## FINAL CHECKLIST
- Every container with a background color MUST have both background_background='classic' AND background_color set
- All text colors explicitly set
- NO flex_wrap or _flex_size anywhere
- All images real sideloaded images
- Use SVG icons, not Elementor icon library
- Warm earthy color palette throughout — browns, creams, caramels
- Menu cards with image, name, description, price
- Cozy, inviting atmosphere reflected in design
- Publish the page as draft
