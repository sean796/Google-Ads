Create a vibrant, fun landing page for "El Fuego Tacos" — an authentic Mexican taco shop and cantina.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #DC2626 (chili red)
- Primary Dark: #B91C1C (darker red)
- Accent: #F59E0B (warm salsa yellow)
- Green: #16A34A (fresh cilantro green)
- Dark: #1A0A00 (dark adobe)
- Warm BG: #FEF3E2 (warm tortilla cream)
- Light Text: #FFFFFF
- Body Text: #5C4033 (warm brown)
- Card BG: #FFFFFF
- Border: #E8D5C0

### Typography
- Headings: bold (800), title case — fun, bold, festive
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#DC2626
- Body text: size 16px, color=#5C4033, line-height 1.7

## IMAGE SOURCING — DO THIS FIRST
1. "mexican taco shop colorful interior" — hero background
2. "authentic tacos street food" — menu
3. "fresh guacamole mexican food" — menu
4. "mexican restaurant kitchen cooking" — about
5. "burrito bowl fresh ingredients" — menu
6. "churros mexican dessert" — menu
7. "margarita cocktail lime" — drinks
8. "mexican food ingredients fresh" — about/gallery

## SVG ICONS
Bold, fun icons: Taco, Chili pepper, Flame/fire, Lime slice, Cactus, Star, Clock, Map pin, Phone, Delivery scooter.

## PAGE STRUCTURE

### 1. HERO SECTION
- Background: sideloaded taco shop interior, background_size='cover'
- Overlay: background_overlay_color='#1A0A00', background_overlay_opacity={size:0.6,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Centered:
  - "AUTHENTIC MEXICAN STREET FOOD" — color=#F59E0B, uppercase, letter-spacing
  - "Tacos So Good, You'll Need a Fiesta" — color=#FFFFFF, size=50px, weight=800
  - "Handmade tortillas, slow-cooked meats, fresh salsas. Taste the real deal." — color=#FEF3E2
  - "View Menu" + "Order Online" buttons — red bg + yellow border

### 2. FEATURE STRIP
- Background: background_color='#DC2626'
- Row 3 children: "Handmade Tortillas Daily" | "Open Till Midnight" | "Catering Available" — #FFFFFF

### 3. MENU HIGHLIGHTS (6 items in 3x2)
- Background: background_color='#FEF3E2'
- "OUR MENU" subtitle + "Fan Favorites" heading
- Row 1 + Row 2, each 3 cards:
  - Image, item name, description, price (#DC2626, bold)
  - Items: Classic Carne Asada Taco ($4.50) | Al Pastor Tacos ($4.25) | Fish Tacos ($5.00) | Loaded Burrito ($10.50) | Guacamole & Chips ($7.00) | Churros con Chocolate ($5.50)

### 4. ABOUT (2-column: text left, image right)
- Background: background_color='#FFFFFF'
- "OUR STORY" subtitle, "Three Generations of Flavor" heading (#1A0A00), story text, "Since 1998" badge

### 5. SPECIALS BANNER
- Background: background_color='#F59E0B'
- "TACO TUESDAY" heading (#1A0A00), "All Tacos $2.50 Every Tuesday 4-9PM" subtext, "See All Specials" button (#DC2626 bg)

### 6. DRINKS SECTION (3 cards)
- Background: background_color='#1A0A00'
- "CANTINA" subtitle (#F59E0B) + "Refresh & Repeat" heading (#FFFFFF)
- Row 3 cards: Margarita ($9) | Horchata ($4) | Mexican Coca-Cola ($3) — dark card bg, #FFFFFF text

### 7. TESTIMONIALS (3 cards)
- Background: background_color='#FEF3E2'
- Star rating (#F59E0B), quote (#5C4033), name

### 8. CATERING CTA
- Background: sideloaded food image, overlay
- "Feed the Whole Party" heading (#FFFFFF), subtext, "Get Catering Quote" button

### 9. LOCATION (2-column)
- Background: background_color='#FFFFFF'
- Left: Address, phone, hours (Sun-Thu 11AM-11PM, Fri-Sat 11AM-1AM)
- Right: Google Maps

### 10. FOOTER
- Background: background_color='#1A0A00'
- 4 columns: Brand | Menu | Info | Contact — color=#B08968/#FFFFFF
- Copyright

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px) scale(1.02); box-shadow: 0 8px 25px rgba(220, 38, 38, 0.3); }
.elementor-image img { transition: transform 0.5s ease; }
.elementor-image:hover img { transform: scale(1.06); }
::selection { background: #DC2626; color: #FFFFFF; }
```

### Element-Level — Menu Cards:
```css
selector { transition: transform 0.3s ease, box-shadow 0.3s ease; overflow: hidden; }
selector:hover { transform: translateY(-8px) rotate(-0.5deg); box-shadow: 0 15px 40px rgba(0,0,0,0.12); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-widget-text-editor').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(25px)'; el.style.transition = 'opacity 0.6s ease, transform 0.6s ease'; observer.observe(el);
});
// Fun wiggle on menu card hover
const style = document.createElement('style');
style.textContent = '@keyframes wiggle { 0%,100% { transform: rotate(0); } 25% { transform: rotate(-1deg); } 75% { transform: rotate(1deg); } }';
document.head.appendChild(style);
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Vibrant, festive: reds, yellows, greens, warm cream backgrounds — Menu items with photos + prices — Publish as draft
