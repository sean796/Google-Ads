Create a rugged, trustworthy landing page for "BuildRight Hardware" — a family-owned hardware and building supplies store.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #D97706 (construction orange/amber)
- Primary Dark: #B45309 (darker amber)
- Secondary: #1E3A5F (steel blue)
- Dark: #111827 (charcoal)
- Light Text: #FFFFFF
- Body Text: #4B5563 (gray-600)
- Light BG: #F3F4F6 (gray-100)
- Card BG: #FFFFFF
- Warning Yellow: #FBBF24
- Border: #D1D5DB

### Typography
- Headings: uppercase, bold (700-800), tight tracking — industrial, sturdy feel
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#D97706
- Body text: size 16px, color=#4B5563, line-height 1.7

## IMAGE SOURCING — DO THIS FIRST
1. "hardware store interior tools" — hero background
2. "power tools collection professional" — departments
3. "lumber wood building materials" — departments
4. "plumbing supplies pipes fittings" — departments
5. "paint cans colorful hardware store" — departments
6. "hardware store staff helpful" — about
7. "workshop workbench tools organized" — DIY section
8. "delivery truck building materials" — services

## SVG ICONS
Bold, solid-style icons: Wrench, Hammer, Saw, Paint roller, Lightbulb, Tape measure, Delivery truck, Shield/warranty, Clock, Map pin.

## PAGE STRUCTURE

### 1. HERO SECTION (2-column: text left, promo card right)
- Background: sideloaded hardware store, background_size='cover'
- Overlay: background_overlay_color='#111827', background_overlay_opacity={size:0.7,unit:'px'}
- Min-height: {size:620,unit:'px'}
- Row:
  - Left: "SERVING BUILDERS SINCE 1985" label (#D97706), "Everything You Need to Build It Right" heading (#FFFFFF, 48px, weight=800, uppercase), subtext (#E5E7EB), "Shop Now" + "View Deals" buttons
  - Right: Promo card — background_color='#D97706', "THIS WEEK'S DEAL" heading, "20% Off All Power Tools" (#FFFFFF), "Shop Deals" button (#111827 bg)

### 2. DEPARTMENT CATEGORIES (4 cards)
- Background: background_color='#F3F4F6'
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- "SHOP BY DEPARTMENT" subtitle + heading
- Row 4 children: each with image, overlay, department name
  - Power Tools | Lumber & Building | Plumbing & Electrical | Paint & Finishes

### 3. ABOUT / WHY US (2-column)
- Background: background_color='#FFFFFF'
- Row:
  - Left: "ABOUT BUILDRIGHT" subtitle, "Family-Owned, Community Trusted" heading, story text, stats row: "40+" years | "50K+" products | "Free" delivery over $75
  - Right: Staff image

### 4. SERVICES (4 icon boxes)
- Background: background_color='#1E3A5F'
- Row 4 children: white icon + white text
  - "Free Delivery" | "Tool Rental" | "DIY Workshops" | "Expert Advice"

### 5. FEATURED PRODUCTS (3 cards)
- Background: background_color='#F3F4F6'
- "BESTSELLERS" subtitle + heading
- Row 3 cards: product image, name, price (#D97706), "Add to Cart" button
  - DeWalt Drill Set ($189) | 4x8 Plywood Sheet ($42) | 5-Gal Interior Paint ($38)

### 6. DIY TIPS SECTION (2-column)
- Background: background_color='#FFFFFF'
- Row:
  - Left: Workshop image
  - Right: "DIY CORNER" subtitle, "Weekend Project Ideas" heading, text about workshops and free classes, "View Schedule" button

### 7. TESTIMONIALS (3 cards)
- Background: background_color='#F3F4F6'
- 3 cards: star rating (#FBBF24), quote, name + "Contractor" or "Homeowner"

### 8. CTA BANNER
- Background: background_color='#D97706'
- "Need It Today? We've Got It." heading (#FFFFFF), subtext, "Find Our Store" button (#111827 bg)

### 9. LOCATION / HOURS (2-column)
- Background: background_color='#FFFFFF'
- Left: Address, phone, hours (Mon-Sat 7AM-8PM, Sun 9AM-5PM)
- Right: Google Maps

### 10. FOOTER
- Background: background_color='#111827'
- 4 columns: Brand | Departments | Services | Contact — color=#9CA3AF
- Copyright — color=#6B7280

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; text-transform: uppercase !important; letter-spacing: 1px !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(217, 119, 6, 0.3); }
.elementor-image img { transition: transform 0.5s ease; }
.elementor-image:hover img { transform: scale(1.04); }
```

### Element-Level — Department Cards:
```css
selector { overflow: hidden; transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 15px 40px rgba(0,0,0,0.12); }
```

### Element-Level — Product Cards:
```css
selector { transition: transform 0.3s ease, box-shadow 0.3s ease; }
selector:hover { transform: translateY(-6px); box-shadow: 0 12px 35px rgba(0,0,0,0.1); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-icon-box-wrapper').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(30px)'; el.style.transition = 'opacity 0.6s ease, transform 0.6s ease'; observer.observe(el);
});
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Industrial/rugged feel: bold uppercase headings, orange accents, practical layout — Publish as draft
