Create a fun, energetic landing page for "StrikeZone Lanes" — a modern bowling alley and entertainment center.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #7C3AED (electric purple)
- Primary Light: #A855F7 (lighter purple)
- Accent: #06B6D4 (cyan/neon blue)
- Accent Pink: #EC4899 (hot pink)
- Yellow: #FBBF24 (neon yellow)
- Dark: #0C0A1A (deep midnight)
- Dark Surface: #1A1830 (card bg)
- Light Text: #FFFFFF
- Body Text: #9CA3AF (gray)
- Border: #2D2B4A

### Typography
- Headings: uppercase, bold (800-900) — fun, loud, energetic
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#06B6D4
- Body text: size 16px, color=#9CA3AF, line-height 1.7

## IMAGE SOURCING — DO THIS FIRST
1. "bowling alley neon lights lanes" — hero
2. "bowling ball pins strike" — about
3. "bowling arcade entertainment center" — activities
4. "bowling shoes retro colorful" — fun
5. "bowling party celebration group" — events
6. "bowling alley food bar" — food
7. "bowling league team" — leagues
8. "laser tag arcade games neon" — entertainment

## SVG ICONS
Bold, neon-style icons: Bowling pin, Bowling ball, Trophy, Star, Pizza slice, Beer mug, Lightning bolt, Party hat, Joystick, Music note.

## PAGE STRUCTURE

### 1. HERO (full-screen neon)
- Background: sideloaded bowling neon, background_size='cover'
- Overlay: background_overlay_color='#0C0A1A', background_overlay_opacity={size:0.65,unit:'px'}
- Min-height: {size:680,unit:'px'}
- Centered:
  - "BOWL · EAT · PLAY · REPEAT" — color=#06B6D4, uppercase
  - "IT'S ALWAYS A GOOD TIME TO STRIKE" — color=#FFFFFF, size=50px, weight=900
  - "32 lanes, arcade games, full kitchen, craft beer bar. Fun for everyone." — color=#9CA3AF
  - "Book a Lane" + "View Specials" buttons — purple bg + cyan border

### 2. ACTIVITIES (4 cards)
- Background: background_color='#0C0A1A'
- "THINGS TO DO" subtitle + heading
- Row 4: image card + name
  - "Open Bowling" | "Cosmic Bowling" | "Arcade & Games" | "Laser Tag"
- Each: dark card bg (#1A1830), neon border on hover

### 3. PRICING (3 tiers)
- Background: background_color='#1A1830'
- "LANE RATES" subtitle (#06B6D4) + heading (#FFFFFF)
- Weekday ($25/hr) | Weekend ($35/hr — FEATURED, cyan border) | Cosmic Night ($30/hr + glow gear)
- Feature list: lane rental, shoe rental, etc.
- "Reserve Lane" buttons — purple bg

### 4. FOOD & DRINKS (2-column)
- Background: background_color='#0C0A1A'
- Left: "THE KITCHEN" subtitle, heading, menu highlights — loaded nachos, pizza, wings, burgers — #9CA3AF text
- Right: Food/bar image

### 5. EVENTS & PARTIES
- Background: background_color='#7C3AED'
- "Birthday Parties · Corporate Events · League Night" heading (#FFFFFF), subtext, "Plan Your Event" button (#FFFFFF bg, #7C3AED text)

### 6. LEAGUES (2-column)
- Background: background_color='#1A1830'
- Left: league team image
- Right: "JOIN A LEAGUE" subtitle, heading, details: "Monday Night Mixers" | "Wednesday Women's League" | "Saturday Youth League", "Sign Up" button

### 7. SPECIALS / PROMOS
- Background: background_color='#0C0A1A'
- Row 3 promo cards:
  - "Taco Tuesday — $2 Tacos + $20 Lanes" (#FBBF24 accent)
  - "College Night Thursday — $15/hr with Student ID" (#EC4899 accent)
  - "Family Sunday — Kids Bowl Free till 2PM" (#06B6D4 accent)

### 8. TESTIMONIALS (3 cards)
- Background: background_color='#1A1830'
- Stars (#FBBF24), quote (#9CA3AF), name (#FFFFFF)

### 9. LOCATION / HOURS
- Background: background_color='#0C0A1A'
- Left: Address, phone, hours (Mon-Thu 12PM-11PM, Fri-Sat 11AM-2AM, Sun 10AM-10PM)
- Right: Google Maps

### 10. FOOTER
- Background: background_color='#0C0A1A'
- Border top (#2D2B4A)
- 4 columns — color=#6B7280/#FFFFFF
- Copyright

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; text-transform: uppercase !important; }
.elementor-button:hover { transform: translateY(-3px) scale(1.02); box-shadow: 0 0 30px rgba(124, 58, 237, 0.4); }
.elementor-image img { transition: transform 0.5s ease; }
.elementor-image:hover img { transform: scale(1.05); }
::selection { background: #7C3AED; color: #FFFFFF; }
```

### Element-Level — Activity Cards:
```css
selector { transition: all 0.3s ease; border: 1px solid #2D2B4A; }
selector:hover { transform: translateY(-10px); border-color: #06B6D4; box-shadow: 0 0 40px rgba(6, 182, 212, 0.15); }
```

### Element-Level — Promo Cards:
```css
selector { transition: transform 0.3s ease; }
selector:hover { transform: scale(1.03); }
```

### Element-Level — Pricing Featured:
```css
selector { border: 2px solid #06B6D4; box-shadow: 0 0 30px rgba(6, 182, 212, 0.15); transform: scale(1.03); }
selector:hover { transform: scale(1.06); box-shadow: 0 0 50px rgba(6, 182, 212, 0.25); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-icon-box-wrapper').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(30px)'; el.style.transition = 'opacity 0.6s ease, transform 0.6s ease'; observer.observe(el);
});
// Neon glow pulse on hero heading
const heroH = document.querySelector('.elementor-heading-title');
if (heroH) {
  heroH.style.animation = 'neonPulse 3s ease-in-out infinite';
  const s = document.createElement('style');
  s.textContent = '@keyframes neonPulse { 0%,100% { text-shadow: 0 0 10px rgba(124,58,237,0.3); } 50% { text-shadow: 0 0 30px rgba(124,58,237,0.6), 0 0 60px rgba(6,182,212,0.3); } }';
  document.head.appendChild(s);
}
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Dark neon theme: purples, cyans, pinks, yellows on black — Lane pricing with hourly rates — Promo cards with themed specials — Neon glow effects — Publish as draft
