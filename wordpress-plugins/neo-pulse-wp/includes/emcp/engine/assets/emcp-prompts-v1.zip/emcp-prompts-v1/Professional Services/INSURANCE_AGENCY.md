Create a reliable, professional landing page for "ShieldPoint Insurance" — a local insurance agency offering home, auto, life, and business coverage.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #1565C0 (strong blue — trust/security)
- Primary Dark: #0D47A1 (deeper blue for hover)
- Accent: #FF8F00 (amber alert/action)
- Light BG: #F0F4FA (soft blue tint)
- Dark: #0D1B2A (navy dark)
- Dark Surface: #162D44
- Light Text: #FFFFFF
- Body Text: #4A5568 (slate)
- Muted: #7A8A9E
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — confident, protective
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#1565C0, weight=600
- Body text: size 16px, color=#4A5568, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Coverage cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- About text: _animation='fadeInRight', _animation_delay=200
- Testimonials: _animation='fadeInUp', stagger 100ms
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "family home protection insurance" — hero
2. "insurance agent office professional" — about
3. "car driving safe road" — auto insurance
4. "family happy home portrait" — home insurance
5. "business office team meeting" — business insurance
6. "couple planning financial future" — life insurance
7. "umbrella protection rain concept" — coverage
8. "handshake agreement professional" — trust

## SVG ICONS
- Shield icon (protection)
- Home icon (home insurance)
- Car icon (auto)
- Heart icon (life insurance)
- Building icon (business)
- Umbrella icon (coverage)
- Dollar icon (savings)
- Phone icon (quote)
- Star icon (reviews)
- Check icon (claims)

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded family/home, overlay #0D1B2A at 0.6
- Row: Left text + Right quote card
  - Label: "TRUSTED LOCAL INSURANCE SINCE 2005" — color=#FF8F00, _animation='fadeInDown'
  - Heading: "Protect What Matters Most" — color=#FFFFFF, size=48px, _animation='fadeInDown', _animation_delay=200
  - Subtext about comprehensive coverage, personal service — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Get Free Quote" (#1565C0) | "Call Us" (border #FF8F00)
  - Right: "Free Quote in Minutes" card with CTA

### 2. TRUST BAR
- Background: #1565C0
- 4 stats: "18+" years | "5,000+" policies | "A+ Rating" | "24/7 Claims"

### 3. COVERAGE TYPES (4 cards)
- Background: #F0F4FA
- Heading: "Coverage for Every Need" — _animation='fadeInUp'
- Row with 4 cards (_animation='fadeInUp', stagger):
  - Home Insurance | Auto Insurance | Life Insurance | Business Insurance
  - Each: icon, title, description, "Get Quote" button

### 4. WHY CHOOSE US (2-column)
- Background: #FFFFFF
- Image + text about local agency, personal relationships, claims advocacy

### 5. HOW IT WORKS (3 step cards on dark)
- Background: #0D1B2A
- Heading: "Simple as 1-2-3" — color=#FFFFFF
- 3 numbered cards (_animation='fadeInUp', stagger):
  - 1. Request a Quote → 2. Compare Options → 3. Get Covered
  - Dark surface cards, numbered with accent color

### 6. TESTIMONIALS (3 cards)
- Background: #F0F4FA
- 3 cards with quotes, star ratings

### 7. LOCATION
- Background: #FFFFFF
- Address, hours, Google Maps

### 8. CTA
- Background: #1565C0
- Heading: "Get Your Free Quote Today" — _animation='zoomIn'
- Buttons: "Start Quote" | "Call (555) 345-6789"

### 9. FOOTER
- Background: #0D1B2A
- 4 columns, divider, copyright

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(21, 101, 192, 0.3); }
::selection { background: #1565C0; color: #FFFFFF; }
```

### Element-Level CSS — Coverage Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(13, 27, 42, 0.1); }
```

## CUSTOM JAVASCRIPT
Counter animation for stats (same pattern as other prompts).

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page with _animation → 4. Apply CSS → 5. Inject JS

## FINAL CHECKLIST
- Professional, protective — strong blues, amber accents
- Free quote prominently featured in hero
- Trust elements: years, A+ rating, 24/7 claims
- Coverage cards with individual CTAs
- NO flex_wrap or _flex_size — Publish as draft
