Create a reliable, professional landing page for "PipePro Plumbing" — a licensed plumbing service for residential and commercial needs.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #1565C0 (pipe blue)
- Primary Dark: #0D47A1 (deeper blue for hover)
- Accent: #FF6F00 (urgent orange)
- Light BG: #F0F5FA (cool blue tint)
- Dark: #0D1B2A (dark navy)
- Dark Surface: #162D44
- Light Text: #FFFFFF
- Body Text: #4A5568 (slate)
- Muted: #7A8A9E
- Success: #43A047 (green for checks)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — strong, dependable
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#1565C0, weight=600
- Body text: size 16px, color=#4A5568, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Service cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "plumber professional working pipe" — hero
2. "bathroom plumbing modern faucet" — services
3. "plumber fixing kitchen sink" — residential
4. "water heater installation" — water heater
5. "plumbing tools professional" — about
6. "drain cleaning service" — drain
7. "commercial plumbing building" — commercial
8. "emergency plumbing water leak" — emergency

## SVG ICONS
- Wrench icon | Droplet icon | Pipe icon | Shield icon | Clock icon (24/7) | Phone icon | Truck icon | Check icon | Map pin icon | Thermometer icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded plumber working, overlay #0D1B2A at 0.6
- Min-height 650px
- Row: Left text + Right emergency card
  - Label: "LICENSED · INSURED · DEPENDABLE" — color=#FF6F00, _animation='fadeInDown'
  - Heading: "Plumbing Problems? Fixed Fast." — size=48px, _animation='fadeInDown', _animation_delay=200
  - Subtext — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Request Service" (#1565C0) | "Emergency? Call Now" (#FF6F00, text #FFFFFF)
  - Right: "24/7 Emergency Service" card — bold, urgent design

### 2. TRUST BAR
- Background: #1565C0
- "20+ Years" | "10,000+ Jobs" | "Licensed & Insured" | "Same-Day Service"

### 3. SERVICES (2 rows of 3)
- Background: #F0F5FA
- 6 cards: Leak Repair | Drain Cleaning | Water Heater | Bathroom Remodel | Sewer Line | Commercial Plumbing

### 4. WHY US (2-column)
- Background: #FFFFFF
- Image + experience, upfront pricing, licensed, satisfaction guaranteed

### 5. EMERGENCY SECTION (dark, urgent)
- Background: #0D1B2A
- Heading: "24/7 Emergency Plumbing" — color=#FF6F00
- Description + large phone number button
- "We arrive within 60 minutes — guaranteed."

### 6. PRICING TRANSPARENCY
- Background: #F0F5FA
- 3 cards: "Service Call" ($79) | "Drain Clearing" (from $149) | "Water Heater Install" (from $999)
- "No hidden fees — upfront pricing always."

### 7. TESTIMONIALS (3 cards)
- Background: #FFFFFF

### 8. SERVICE AREA + LOCATION
- Background: #F0F5FA
- Google Maps

### 9. CTA
- Background: #1565C0
- Heading: "Don't Wait — Call the Pros" — _animation='zoomIn'
- Buttons: "Schedule Service" | "Call (555) 123-4567"

### 10. FOOTER — Background: #0D1B2A

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(21, 101, 192, 0.3); }
::selection { background: #1565C0; color: #FFFFFF; }
```
### Element-Level CSS — Service Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(13, 27, 42, 0.1); }
```

## FINAL CHECKLIST
- Reliable, professional — blues, urgent orange for emergency
- 24/7 emergency prominently featured
- Upfront pricing transparency
- Trust: licensed, insured, years, job count
- NO flex_wrap or _flex_size — Publish as draft
