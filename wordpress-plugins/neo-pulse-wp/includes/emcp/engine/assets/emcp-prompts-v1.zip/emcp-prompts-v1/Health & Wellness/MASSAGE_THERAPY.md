Create a serene, calming landing page for "Tranquil Touch" — a massage therapy and bodywork studio.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #7B8F6B (sage green)
- Primary Dark: #637753 (deeper sage for hover)
- Accent: #C9B896 (warm sand)
- Light BG: #F7F5F0 (linen)
- Cream: #FFF9F0 (warm white)
- Dark: #2D2B28 (charcoal brown)
- Dark Surface: #3D3A36
- Light Text: #FFFFFF
- Body Text: #5A5652 (warm gray)
- Muted: #8A8680
- Lavender: #9B8FB5 (subtle purple accent)
- Card BG: #FFFFFF

### Typography
- Headings: weight 400-600, title case — calm, gentle, soothing
- Section subtitles: uppercase, letter-spacing=4px, size=11px, color=#7B8F6B, weight=500
- Body text: size 16px, color=#5A5652, line-height 1.9

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=300
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=500
- Hero buttons: _animation='fadeInUp', animation_duration='slow', _animation_delay=700
- Section headings: _animation='fadeIn', animation_duration='slow'
- Service cards: _animation='fadeIn', animation_duration='slow', stagger 200ms
- About image: _animation='fadeInLeft', animation_duration='slow'
- About text: _animation='fadeInRight', animation_duration='slow', _animation_delay=200
- Testimonials: _animation='fadeIn', animation_duration='slow', stagger 200ms
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "massage therapy spa relaxation candles" — hero background
2. "back massage professional therapist" — services
3. "hot stone massage spa" — services
4. "spa interior zen bamboo" — atmosphere
5. "aromatherapy essential oils spa" — products/services
6. "couple massage spa treatment" — couples
7. "facial massage relaxation woman" — facial
8. "meditation peaceful zen stones" — ambiance

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Soft, flowing line icons:
- Hands icon (massage)
- Leaf icon (natural/organic)
- Droplet icon (essential oils)
- Stone stack icon (hot stone)
- Heart icon (wellness)
- Clock icon (session duration)
- Star icon (reviews)
- Phone icon (booking)
- Map pin icon (location)
- Candle icon (ambiance)

## PAGE STRUCTURE

### 1. HERO SECTION
Full-width container:
- Background: sideloaded massage spa image, background_size='cover'
- Overlay: background_overlay_color='#2D2B28', background_overlay_opacity={size:0.5,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Padding: {top:'120',right:'0',bottom:'120',left:'0',unit:'px'}
- Centered content:
  - Small label: "MASSAGE THERAPY · BODYWORK · WELLNESS" — color=#C9B896, size=11px, letter-spacing=5px, _animation='fadeIn'
  - Main heading: "Restore. Relax. Renew." — color=#FFFFFF, size=52px, weight=400, _animation='fadeIn', _animation_delay=300
  - Subtext: "Licensed therapists specializing in deep tissue, Swedish, hot stone, and therapeutic massage. Your journey to wellness begins here." — color=#F7F5F0, size=17px, _animation='fadeIn', _animation_delay=500
  - Row with buttons (_animation='fadeInUp', _animation_delay=700):
    - "Book a Session" — background_color=#7B8F6B, text_color=#FFFFFF, border_radius={top:4,right:4,bottom:4,left:4,unit:'px'}
    - "View Services" — border_color='#C9B896', text_color=#C9B896

### 2. SERVICES (2 rows of 3)
- Background: background_background='classic', background_color='#F7F5F0'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "OUR SERVICES" — color=#7B8F6B, centered
- Heading: "Therapeutic Massage Services" — color=#2D2B28, weight=500, centered, _animation='fadeIn'
- Row 1: 3 cards (_animation='fadeIn', stagger 200ms)
- Row 2: 3 cards

  Each card: white bg, padding, border_radius={top:8,right:8,bottom:8,left:8,unit:'px'}, centered
  - SVG icon (color=#7B8F6B)
  - Service name: "Swedish Massage" — color=#2D2B28, size=18px, weight=600
  - Duration + Description — color=#5A5652, size=14px
  - Price: "60 min — $90" — color=#7B8F6B, size=16px, weight=500

  Services:
  - Row 1: Swedish Massage (60 min $90) | Deep Tissue (60 min $110) | Hot Stone (75 min $120)
  - Row 2: Sports Recovery (60 min $110) | Aromatherapy (60 min $100) | Couples Massage (60 min $180)

### 3. ABOUT (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left: Image (zen spa interior), _animation='fadeInLeft'
  - Right:
    - Subtitle: "OUR PHILOSOPHY" — color=#7B8F6B, _animation='fadeInRight'
    - Heading: "Healing Through Touch" — color=#2D2B28, weight=400, _animation='fadeInRight', _animation_delay=100
    - Text: Holistic approach, licensed therapists, customized sessions — _animation='fadeInRight', _animation_delay=200
    - Stats: "10+" / "Licensed Therapists" | "8+" / "Years Serving" | "5,000+" / "Sessions Given"

### 4. PACKAGES (3 cards on dark)
- Background: background_background='classic', background_color='#2D2B28'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "PACKAGES" — color=#C9B896, centered
- Heading: "Wellness Packages" — color=#FFFFFF, weight=400, centered, _animation='fadeIn'
- Row with 3 cards (_animation='fadeIn', stagger 200ms):
  - Each: background_color='#3D3A36', padding, border_radius
  - Package name: "Serenity" — color=#FFFFFF, size=20px
  - Description — color=#8A8680
  - Price: "$249" — color=#7B8F6B, size=36px
  - Includes list — color=#8A8680
  - Button: "Book Package" — background_color=#7B8F6B, text_color=#FFFFFF

  Packages:
  - Serenity ($249): 3 Swedish sessions
  - Restoration ($399 — FEATURED): 3 deep tissue + 1 hot stone — border accent #7B8F6B
  - Harmony ($599): 6 mixed sessions + aromatherapy upgrade

### 5. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#F7F5F0'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row with 3 cards (_animation='fadeIn', stagger 200ms):
  - White bg, border, padding
  - Star rating (color=#C9B896)
  - Quote — italic
  - Name

### 6. LOCATION
- Background: background_background='classic', background_color='#FFFFFF'
- Row:
  - Left (_animation='fadeInLeft'): Address, hours, phone
  - Right: Google Maps, _animation='fadeInRight'

### 7. CTA
- Background: sideloaded meditation/zen image, background_size='cover'
- Overlay: background_overlay_color='#2D2B28', background_overlay_opacity={size:0.7,unit:'px'}
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered:
  - Heading: "Your Relaxation Awaits" — color=#FFFFFF, size=40px, weight=400, _animation='fadeIn'
  - Subtext — color=#F7F5F0, _animation='fadeIn', _animation_delay=200
  - Row with buttons (_animation='fadeInUp', _animation_delay=400):
    - "Book Now" — background_color=#7B8F6B, text_color=#FFFFFF
    - "Gift Certificates" — border_color='#C9B896', text_color=#C9B896

### 8. FOOTER
- Background: background_background='classic', background_color='#2D2B28'
- Row with 4 columns (_animation='fadeIn', stagger)
- Divider + copyright

## CUSTOM CSS (minimal)

### Page-Level CSS:
```css
html { scroll-behavior: smooth; }

.elementor-button {
  transition: all 0.4s ease !important;
}
.elementor-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(123, 143, 107, 0.25);
}

::selection {
  background: #7B8F6B;
  color: #FFFFFF;
}
```

### Element-Level CSS — Service Cards:
```css
selector {
  transition: transform 0.5s ease, box-shadow 0.5s ease;
}
selector:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 40px rgba(0, 0, 0, 0.06);
}
```

## CUSTOM JAVASCRIPT
Use `add-custom-js` with wrap_dom_ready=true.

```javascript
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 40);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 40);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** with _animation settings
4. **Apply page-level CSS**
5. **Apply element-level CSS** for service cards
6. **Inject custom JS**

## FINAL CHECKLIST
- Serene, calming aesthetic — sage greens, warm sands, soft linens
- Slow animations (animation_duration='slow') — peaceful, zen-like feel
- Service cards with duration and pricing
- Wellness packages with tiered pricing
- NO flex_wrap or _flex_size
- Publish the page as draft
