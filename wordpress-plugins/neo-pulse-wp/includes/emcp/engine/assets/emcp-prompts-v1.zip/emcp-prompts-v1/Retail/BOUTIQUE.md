Create an elegant, fashion-forward landing page for "Maison Lune" — a curated women's fashion boutique.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #1C1C1C (charcoal black)
- Accent: #C4956A (warm rose gold)
- Accent Light: #E8D5C4 (soft blush)
- Dark: #0A0A0A (true near-black)
- Light Text: #FFFFFF
- Body Text: #6B6B6B (warm gray)
- Light BG: #FAF8F5 (warm ivory)
- Card BG: #FFFFFF
- Border: #E8E3DD (warm neutral)

### Typography
- Headings: weight 300-400 (light, editorial), title case, letter-spacing=1px
- Section subtitles: uppercase, letter-spacing=4px, size=11px, color=#C4956A, weight=600
- Body text: size 15-16px, color=#6B6B6B, line-height 1.8

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required
- For overlays: background_overlay_background='classic', background_overlay_color='#hex', background_overlay_opacity={size:0.4,unit:'px'}

## IMAGE SOURCING — DO THIS FIRST
1. "fashion boutique elegant interior" — hero background
2. "women fashion model editorial" — featured collection
3. "luxury handbag accessories display" — accessories
4. "fashion clothing rack boutique" — new arrivals
5. "women dress elegant summer" — collection 1
6. "minimalist jewelry gold" — collection 2
7. "fashion boutique storefront" — about/visit
8. "women fashion portrait editorial" — lookbook

## SVG ICONS
Thin, elegant line icons: Shopping bag, Heart, Hanger, Diamond, Gift, Shipping truck, Return arrow, Crown, Star, Mail.

## PAGE STRUCTURE

### 1. HERO SECTION (full-screen editorial)
- Background: sideloaded boutique interior, background_size='cover'
- Overlay: background_overlay_color='#0A0A0A', background_overlay_opacity={size:0.4,unit:'px'}
- Min-height: {size:700,unit:'px'}
- Centered:
  - "NEW SEASON" — color=#C4956A, size=12px, uppercase, letter-spacing=5px
  - "The Art of Effortless Style" — color=#FFFFFF, size=54px, weight=300
  - "Curated collections for the modern woman. Timeless pieces, contemporary edge." — color=#E8E3DD, size=17px
  - "Shop New Arrivals" button — background_color=#C4956A, text_color=#FFFFFF, border_radius=0 (sharp)

### 2. COLLECTION HIGHLIGHTS (3 cards)
- Background: background_color='#FAF8F5'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row with 3 children:
  - Each: image widget + overlay text container
  - "Ready-to-Wear" | "Accessories" | "Essentials"
  - Image with border_radius=0, heading overlay color=#FFFFFF

### 3. FEATURED PRODUCTS (2-column: image left, text right)
- Background: background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left: Large editorial image, border_radius=0
  - Right (align_items='flex-start'):
    - "EDITOR'S PICK" — color=#C4956A
    - "The Signature Silk Dress" — color=#1C1C1C, weight=300, size=34px
    - Description — color=#6B6B6B
    - "$285" — color=#1C1C1C, size=24px, weight=600
    - "Shop Now →" button — background_color=#1C1C1C, text_color=#FFFFFF

### 4. LOOKBOOK GRID (2x2 image mosaic)
- Background: background_color='#FAF8F5'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- "LOOKBOOK" subtitle + "Spring/Summer 2026" heading centered
- Row 1: 2 images side by side
- Row 2: 2 more images
- Each image: border_radius=0, overflow hidden

### 5. ABOUT / STORY (2-column: text left, image right)
- Background: background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left: "OUR STORY" subtitle, "Fashion with Purpose" heading (#1C1C1C, weight=300), bio text, "Visit Our Boutique" button
  - Right: Storefront image

### 6. PERKS RIBBON
- Background: background_color='#1C1C1C'
- Padding: {top:'35',right:'0',bottom:'35',left:'0',unit:'px'}
- Row 4 children: "Free Shipping Over $150" | "Easy Returns" | "Gift Wrapping" | "Personal Styling" — icon + text, color=#FFFFFF/#C4956A

### 7. TESTIMONIALS (3 cards)
- Background: background_color='#FAF8F5'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- 3 cards: white bg, border, quote text (#6B6B6B italic), name (#1C1C1C bold)

### 8. NEWSLETTER CTA
- Background: background_color='#C4956A'
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered: "Join the Inner Circle" heading (#FFFFFF), subtext, email form or button

### 9. FOOTER
- Background: background_color='#0A0A0A'
- 4 columns: Brand + tagline | Shop links | Customer Care | Contact — color=#6B6B6B/#FFFFFF
- Copyright — color=#4A4A4A

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; letter-spacing: 2px !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(196, 149, 106, 0.2); }
.elementor-image img { transition: transform 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94); }
.elementor-image:hover img { transform: scale(1.04); }
::selection { background: #C4956A; color: #FFFFFF; }
```

### Element-Level — Collection Cards:
```css
selector { overflow: hidden; transition: transform 0.5s ease; }
selector:hover { transform: translateY(-6px); }
```

### Element-Level — Lookbook Images:
```css
selector { overflow: hidden; }
selector img { transition: transform 0.8s ease; }
selector:hover img { transform: scale(1.06); }
```

## CUSTOM JAVASCRIPT
### Scroll Animations (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-widget-text-editor').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(30px)';
  el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
  observer.observe(el);
});
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS → 7. Site-wide snippet (optional)

## FINAL CHECKLIST
- background_background + background_color on every colored container
- All text colors explicit — NO flex_wrap or _flex_size
- Editorial/luxury feel: light font weights, sharp corners, generous whitespace, rose gold accents
- Publish as draft
