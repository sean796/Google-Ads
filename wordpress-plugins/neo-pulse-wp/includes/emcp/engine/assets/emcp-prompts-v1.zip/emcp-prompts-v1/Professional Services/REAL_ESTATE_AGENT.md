Create a premium landing page for "Olivia Hart — Luxury Real Estate" — a high-end real estate agent specializing in luxury properties.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM (use consistently across ALL sections)

### Color Palette
- Primary: #1A1A2E (deep midnight navy)
- Primary Light: #16213E (slightly lighter navy)
- Accent: #C9A96E (warm gold/champagne)
- Accent Dark: #B8944F (darker gold for hover)
- Dark: #0F0F1A (near-black)
- Light Text: #FFFFFF
- Body Text: #A0A0B0 (soft gray-blue)
- Warm White: #F5F0EB (warm off-white backgrounds)
- Card BG: #FFFFFF
- Border: #E8E0D5 (warm neutral border)

### Typography
- Headings: weight 300-400 (light/elegant), normal case or title case — NOT uppercase (luxury = understated)
- Section subtitles: uppercase, letter-spacing=4px, size=12px, color=accent (#C9A96E), weight=600
- Body text: size 16-17px, color=#6B6B7B, line-height 1.8
- Use serif/elegant feel — leverage heading tags and font-weight to convey luxury

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required
- For overlays: background_overlay_background='classic', background_overlay_color='#hex', background_overlay_opacity={size:0.6,unit:'px'}

## IMAGE SOURCING — DO THIS FIRST
Before building the page, use the search-images and sideload-image tools:
1. "luxury modern house exterior" — for hero background
2. "luxury home interior living room" — for featured listing 1
3. "modern luxury apartment penthouse" — for featured listing 2
4. "luxury villa pool ocean view" — for featured listing 3
5. "luxury kitchen marble modern" — for featured listing 4
6. "professional woman real estate agent portrait" — for about section
7. "luxury mansion exterior evening lights" — for CTA background
8. "modern home interior design elegant" — for gallery/listings

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use the upload-svg-icon tool. Do NOT use Elementor's default icon library. Simple, thin-line elegant icons for:
- Home/house icon (listings)
- Key icon (sold properties)
- Map pin icon (locations)
- Dollar sign icon (value)
- Shield icon (trust)
- Calendar icon (appointments)
- Phone icon (contact)
- Envelope icon (email)
- Star icon (reviews)
- Award/badge icon (achievements)

## PAGE STRUCTURE

### 1. HERO SECTION (full-screen with property showcase)
Full-width container:
- Background: sideloaded luxury house image, background_size='cover', background_position='center center'
- Dark overlay: background_overlay_color='#0F0F1A', background_overlay_opacity={size:0.5,unit:'px'}
- Min-height: {size:700,unit:'px'}
- Padding: {top:'120',right:'0',bottom:'120',left:'0',unit:'px'}
- Centered content (column direction, align_items='center'):
  - Small label: "LUXURY REAL ESTATE SPECIALIST" — color=#C9A96E, size=13px, uppercase, letter-spacing=4px
  - Main heading: "Find Your Dream Home" — color=#FFFFFF, size=56px, weight=300 (light/elegant)
  - Subtext: "Olivia Hart brings 12 years of experience in luxury properties across Manhattan, the Hamptons, and Miami. White-glove service for discerning buyers." — color=#E5E5EA, size=18px, centered, max-width
  - Row container with buttons:
    - "Browse Listings" — background_color=#C9A96E, text_color=#FFFFFF, border_radius={top:0,right:0,bottom:0,left:0,unit:'px'} (sharp corners = luxury), padding large
    - "Schedule Consultation" — background=transparent, border_border='solid', border_width={top:1,right:1,bottom:1,left:1,unit:'px'}, border_color='#C9A96E', text_color=#C9A96E

### 2. STATS RIBBON
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'40',right:'0',bottom:'40',left:'0',unit:'px'}
- Border bottom: border_border='solid', border_width={top:0,right:0,bottom:1,left:0,unit:'px'}, border_color='#E8E0D5'
- Row container with 4 children:
  - Each: centered column with counter/heading + label
  - "$250M+" / "Total Sales Volume" — heading color=#1A1A2E, label color=#6B6B7B
  - "180+" / "Homes Sold"
  - "98%" / "List-to-Sale Ratio"
  - "12" / "Years Experience"

### 3. FEATURED LISTINGS (4 property cards in 2x2 grid)
- Background: background_background='classic', background_color='#F5F0EB'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "EXCLUSIVE PROPERTIES" — color=#C9A96E, centered
- Heading: "Featured Listings" — color=#1A1A2E, size=40px, weight=300, centered
- Row 1: 2 property cards side by side
- Row 2: 2 more property cards

  Each property card (column container):
  - Image widget with listing photo, border_radius={top:8,right:8,bottom:8,left:8,unit:'px'} (top corners only via CSS)
  - Inner content container with background_color='#FFFFFF', padding={top:25,right:25,bottom:25,left:25,unit:'px'}
  - Small tag: "FOR SALE" — color=#C9A96E, size=11px, uppercase
  - Property name heading: e.g. "Penthouse at One57" — color=#1A1A2E, size=20px
  - Address text: "157 West 57th St, Manhattan" — color=#6B6B7B, size=14px
  - Row with details: "4 Bed · 3 Bath · 3,200 sqft" — color=#6B6B7B
  - Price heading: "$4,250,000" — color=#C9A96E, size=22px, weight=600
  - Listings:
    1. "Penthouse at One57" — Manhattan — 4 Bed 3 Bath 3,200 sqft — $4,250,000
    2. "Waterfront Villa" — Miami Beach — 5 Bed 4 Bath 4,800 sqft — $6,900,000
    3. "Modern Brownstone" — Brooklyn Heights — 3 Bed 2.5 Bath 2,400 sqft — $3,150,000
    4. "Ocean View Estate" — The Hamptons — 6 Bed 5 Bath 6,500 sqft — $12,500,000

### 4. ABOUT SECTION (2-column: text left, image right)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left (align_items='flex-start'):
    - Subtitle: "ABOUT OLIVIA" — color=#C9A96E
    - Heading: "A Personalized Approach to Luxury Real Estate" — color=#1A1A2E, weight=300
    - Bio: 2 paragraphs about experience, client focus, market expertise — color=#6B6B7B
    - Row with badges/icons: "Licensed Agent" | "Top 1% Nationwide" | "Certified Luxury Home Specialist"
  - Right: Image widget with professional portrait, border_radius

### 5. SERVICES SECTION (3 cards)
- Background: background_background='classic', background_color='#1A1A2E'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "SERVICES" — color=#C9A96E, centered
- Heading: "How I Can Help" — color=#FFFFFF, weight=300, centered
- Row with 3 children:
  - Each card: background_color='#16213E', border_border='solid', border_color='#2A2A4E', border_radius, padding
  - SVG icon (color=#C9A96E), heading (#FFFFFF), description (#A0A0B0)
  - Services: Buyer Representation | Seller Listing Services | Investment Consulting

### 6. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#F5F0EB'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle + heading centered
- Row with 3 cards:
  - Each: white background, padding, border_radius, subtle border
  - Large opening quote mark (HTML widget with styled ") — color=#C9A96E
  - Quote text — color=#6B6B7B, italic
  - Client name (#1A1A2E, bold) + "Purchased in Manhattan" or similar (#A0A0B0)

### 7. CTA SECTION (full-width background)
- Background: sideloaded mansion evening image, background_size='cover'
- Overlay: background_overlay_color='#0F0F1A', background_overlay_opacity={size:0.7,unit:'px'}
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Centered:
  - Heading: "Ready to Find Your Perfect Home?" — color=#FFFFFF, size=44px, weight=300
  - Subtext — color=#E5E5EA
  - Button: "Schedule a Private Consultation" — background_color=#C9A96E, text_color=#FFFFFF, padding large

### 8. CONTACT SECTION (2-column: form left, info right)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left: Form widget (if Pro) — Name, Email, Phone, Property Interest (select: Buying, Selling, Both, Investment), Budget Range (select), Message textarea, Submit "Get in Touch"
  - Right: Contact info column
    - Heading: "Get in Touch" — color=#1A1A2E
    - Phone, email, office address — color=#6B6B7B with SVG icons
    - Office hours text
    - Social icons row

### 9. FOOTER
- Background: background_background='classic', background_color='#0F0F1A'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row with 4 columns:
  - Col 1: "Olivia Hart" logo/name + tagline — color=#A0A0B0 / #FFFFFF
  - Col 2: "Quick Links" — color=#A0A0B0
  - Col 3: "Properties" — color=#A0A0B0
  - Col 4: "Contact" — color=#A0A0B0
- Divider (color=#2A2A4E)
- Copyright: "© 2026 Olivia Hart Real Estate. All rights reserved." — color=#6B6B7B

## CUSTOM CSS — APPLY AFTER PAGE IS BUILT

### Page-Level CSS (no element_id):
```css
html { scroll-behavior: smooth; }

/* Elegant button hover */
.elementor-button {
  transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94) !important;
  letter-spacing: 1px;
}
.elementor-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(201, 169, 110, 0.3);
}

/* Image reveal on hover */
.elementor-image img {
  transition: transform 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.elementor-image:hover img {
  transform: scale(1.04);
}

/* Gold underline on headings hover */
.elementor-heading-title {
  transition: color 0.3s ease;
}
```

### Element-Level CSS — Property Cards:
```css
selector {
  overflow: hidden;
  transition: transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94), box-shadow 0.5s ease;
}
selector:hover {
  transform: translateY(-8px);
  box-shadow: 0 25px 60px rgba(0,0,0,0.12);
}
```

### Element-Level CSS — Service Cards (dark section):
```css
selector {
  transition: border-color 0.4s ease, transform 0.4s ease;
}
selector:hover {
  border-color: #C9A96E;
  transform: translateY(-6px);
}
```

### Element-Level CSS — Testimonial Cards:
```css
selector {
  transition: transform 0.3s ease;
}
selector:hover {
  transform: translateY(-4px);
}
```

## CUSTOM JAVASCRIPT — APPLY AFTER PAGE IS BUILT
Use `add-custom-js` with wrap_dom_ready=true.

### Scroll Animations + Counter (add-custom-js, wrap_dom_ready=true):
```javascript
// Fade-in on scroll
const fadeObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
      fadeObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -80px 0px' });

document.querySelectorAll('.elementor-heading-title, .elementor-icon-box-wrapper, .elementor-image, .elementor-widget-text-editor').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(30px)';
  el.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
  fadeObserver.observe(el);
});

// Animate stat counters
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        const prefix = text.substring(0, text.indexOf(match[1]));
        let current = 0;
        const increment = Math.ceil(target / 40);
        const timer = setInterval(() => {
          current += increment;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = prefix + current + suffix;
        }, 35);
      }
      counterObserver.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/[\d$]/.test(el.textContent.trim().charAt(0)) || /^\$/.test(el.textContent.trim())) {
    counterObserver.observe(el);
  }
});

// Parallax hero background
let ticking = false;
window.addEventListener('scroll', () => {
  if (!ticking) {
    requestAnimationFrame(() => {
      const scrolled = window.scrollY;
      const hero = document.querySelector('.elementor-element[data-element_type="container"]');
      if (hero && scrolled < 900) {
        const bg = hero.querySelector('.elementor-background-overlay');
        if (bg) bg.style.opacity = Math.min(0.85, 0.5 + scrolled * 0.0004);
      }
      ticking = false;
    });
    ticking = true;
  }
});
```

## SITE-WIDE CODE SNIPPET (Optional — Pro only)
- Title: "Olivia Hart RE - Typography & Smoothing"
- Location: head
- Priority: 1
- Code:
```html
<style>
  html { scroll-behavior: smooth; }
  body { -webkit-font-smoothing: antialiased; }
  ::selection { background: #C9A96E; color: #FFFFFF; }
</style>
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** using build-page
4. **Apply page-level CSS** using add-custom-css (no element_id)
5. **Apply element-level CSS** for: property cards, service cards, testimonial cards
6. **Inject custom JS** using add-custom-js with wrap_dom_ready=true
7. **Create site-wide snippet** (optional, Pro only)

## FINAL CHECKLIST
- Every container with a background color MUST have both background_background='classic' AND background_color set
- All text colors must be explicitly set
- NO flex_wrap or _flex_size anywhere
- All images must be real sideloaded images
- Use SVG icons, not Elementor icon library
- Luxury aesthetic: light font weights, gold accents, generous whitespace, sharp corners on buttons
- Property cards with image + details + price
- Form has property-specific fields (budget, interest type)
- Publish the page as draft
