Create a professional, trustworthy landing page for "Summit CPA Group" — an accounting and tax advisory firm.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #1B5E20 (forest green — prosperity)
- Primary Dark: #145218 (deeper green for hover)
- Accent: #2E7D32 (lighter green)
- Gold: #C8A951 (subtle gold accent)
- Light BG: #F5F7F5 (soft green tint)
- Dark: #1A2218 (dark forest)
- Dark Surface: #243122
- Light Text: #FFFFFF
- Body Text: #4A5548 (green-gray)
- Muted: #7A8A78
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — authoritative and trustworthy
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#1B5E20, weight=600
- Body text: size 16px, color=#4A5548, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp', _animation_delay=0
- Service cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- About text: _animation='fadeInRight', _animation_delay=200
- Testimonials: _animation='fadeInUp', stagger 100ms
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "accounting office professional modern" — hero
2. "financial advisor meeting client" — about
3. "tax documents calculator desk" — services
4. "business team meeting conference" — team
5. "office building modern exterior" — credibility
6. "small business owner bookkeeping" — clients
7. "financial charts growth graph" — results
8. "handshake business professional" — trust

## SVG ICONS
Use upload-svg-icon. Professional, clean icons:
- Calculator icon (accounting)
- Chart/graph icon (financial growth)
- Shield icon (protection/audit)
- Building icon (business)
- Document icon (tax filing)
- Clock icon (deadlines)
- Dollar sign icon (savings)
- Users/people icon (team)
- Phone icon (contact)
- Check circle icon (compliance)

## PAGE STRUCTURE

### 1. HERO SECTION
- Background: sideloaded professional office, background_size='cover'
- Overlay: background_overlay_color='#1A2218', background_overlay_opacity={size:0.65,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Row with 2 children:
  - Left:
    - Label: "ACCOUNTING · TAX · ADVISORY" — color=#C8A951, _animation='fadeInDown'
    - Heading: "Your Numbers. Our Expertise." — color=#FFFFFF, size=48px, _animation='fadeInDown', _animation_delay=200
    - Subtext: "From tax planning to business advisory — trusted CPAs helping individuals and businesses grow with confidence." — color=#F5F7F5, _animation='fadeInUp', _animation_delay=400
    - Buttons (_animation='fadeInUp', _animation_delay=600):
      - "Free Consultation" — background_color=#1B5E20, text_color=#FFFFFF
      - "Our Services" — border_color='#C8A951', text_color=#C8A951
  - Right: Consultation card:
    - White bg, padding, shadow
    - "Free Tax Review" heading
    - "Get a complimentary analysis of your tax situation" text
    - Button: "Schedule Now" — background_color=#1B5E20

### 2. TRUST BAR
- Background: #1B5E20
- Row with 4 stats (_animation='fadeInUp', stagger):
  - "25+" / "Years Experience" | "2,000+" / "Clients Served" | "$15M+" / "Tax Savings" | "100%" / "Compliance Rate"

### 3. SERVICES (2 rows of 3)
- Background: #F5F7F5
- Subtitle: "SERVICES" — centered
- Heading: "How We Help You Succeed" — _animation='fadeInUp'
- 6 service cards (_animation='fadeInUp', stagger):
  - Tax Planning & Preparation | Business Accounting | Audit & Assurance | Payroll Services | Business Advisory | Estate & Trust Planning

### 4. ABOUT (2-column)
- Background: #FFFFFF
- Image (team meeting) + About text, credentials, firm history

### 5. CLIENT TYPES (who we serve — 4 icon boxes on dark)
- Background: #1A2218
- Heading: "Who We Serve" — color=#FFFFFF
- Row with 4 cards (_animation='fadeInUp', stagger):
  - Small Businesses | Startups | Individuals & Families | Non-Profits
  - Dark surface cards with icon, title, brief description

### 6. TESTIMONIALS (3 cards)
- Background: #F5F7F5
- 3 testimonial cards (_animation='fadeInUp', stagger)

### 7. LOCATION
- Background: #FFFFFF
- Address, hours (Mon-Fri 8AM-6PM, Sat by appointment), Google Maps

### 8. CTA
- Background: #1B5E20
- Heading: "Let's Talk About Your Financial Future" — _animation='zoomIn'
- Buttons: "Book Free Consultation" | "Call (555) 234-5678"

### 9. FOOTER
- Background: #1A2218
- 4 columns, divider, copyright

## CUSTOM CSS (minimal)

### Page-Level CSS:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(27, 94, 32, 0.3); }
::selection { background: #1B5E20; color: #FFFFFF; }
```

### Element-Level CSS — Service Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(26, 34, 24, 0.1); }
```

## CUSTOM JAVASCRIPT
Use `add-custom-js` with wrap_dom_ready=true. Counter animation for stats.

```javascript
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 35);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 35);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });
document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page with _animation → 4. Apply CSS → 5. Inject JS

## FINAL CHECKLIST
- Professional, trustworthy — forest greens, golds, whites
- Trust-building stats and credentials prominent
- Free consultation offer in hero
- Entrance animations: professional fadeIn, no bouncy effects
- NO flex_wrap or _flex_size — Publish as draft
