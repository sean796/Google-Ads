Create an edgy, artistic landing page for "Iron & Ink Tattoo" — a professional tattoo and body art studio.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #E53935 (bold red)
- Primary Dark: #C62828 (deeper red for hover)
- Accent: #FFD600 (gold/yellow)
- Dark: #0D0D0D (near-black)
- Dark Surface: #1A1A1A
- Dark Elevated: #252525
- Light Text: #FFFFFF
- Body Text: #A0A0A0 (gray on dark)
- Muted: #666666
- Card BG: #1A1A1A

### Typography
- Headings: weight 800-900, uppercase — bold, aggressive, artistic
- Section subtitles: uppercase, letter-spacing=4px, size=12px, color=#E53935, weight=700
- Body text: size 16px, color=#A0A0A0, line-height 1.7

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Portfolio cards: _animation='fadeIn', stagger 100ms
- Artist cards: _animation='fadeInUp', stagger 150ms
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "tattoo artist working studio" — hero
2. "tattoo close up detailed arm" — portfolio
3. "tattoo studio interior modern" — atmosphere
4. "tattoo machine equipment professional" — about
5. "tattoo design floral artistic" — portfolio
6. "tattoo sleeve colorful detailed" — portfolio
7. "piercing jewelry body art" — piercing
8. "tattoo aftercare healing" — info

## SVG ICONS
- Needle/tattoo machine icon | Skull icon | Rose/flower icon | Star icon | Shield icon | Clock icon | Phone icon | Map pin icon | Diamond icon | Lightning icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded tattoo artist, overlay #0D0D0D at 0.65
- Min-height 650px
- Left-aligned:
  - Label: "CUSTOM TATTOO · BODY ART" — color=#E53935, _animation='fadeInDown'
  - Heading: "YOUR STORY. OUR INK." — size=50px, weight=900, uppercase, _animation='fadeInDown', _animation_delay=200
  - Subtext — color=#A0A0A0, _animation='fadeInUp', _animation_delay=400
  - Buttons: "BOOK CONSULTATION" (#E53935, sharp corners) | "VIEW PORTFOLIO" (border #FFD600, text #FFD600)

### 2. STATS BAR
- Background: #E53935
- "10,000+ Tattoos" | "15+ Years" | "6 Artists" | "Walk-Ins Welcome"

### 3. PORTFOLIO (2 rows of 3)
- Background: #0D0D0D
- Heading: "OUR WORK" — _animation='fadeInUp'
- 6 portfolio cards (_animation='fadeIn', stagger):
  - Image-heavy, minimal text: style tags (Traditional, Realism, Japanese, Neo-Traditional, Blackwork, Watercolor)
  - Each: Full image, small style label overlay

### 4. ARTISTS (4 cards)
- Background: #1A1A1A
- Heading: "MEET THE CREW" — color=#FFFFFF
- 4 artist cards (_animation='fadeInUp', stagger 150ms):
  - Image, name, specialty, years experience
  - "Raven Cross — Blackwork & Geometric | 12 yrs" etc.

### 5. SERVICES
- Background: #0D0D0D
- Row with 3 service cards:
  - Custom Tattoos (from $150/hr) | Cover-Ups (from $200/hr) | Piercings (from $40)

### 6. PROCESS (3 steps)
- Background: #1A1A1A
- 1. Consultation (free) → 2. Custom Design → 3. Your Session
- Numbered, dark elevated cards

### 7. TESTIMONIALS (3 cards)
- Background: #0D0D0D
- Dark cards, star rating (#FFD600)

### 8. CTA
- Background: #E53935
- Heading: "READY TO GET INKED?" — weight=900, _animation='zoomIn'
- Buttons: "BOOK NOW" (#FFFFFF, text #E53935) | "CALL US" (border #FFFFFF)

### 9. FOOTER — Background: #0D0D0D

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.25s ease !important; text-transform: uppercase !important; letter-spacing: 2px !important; }
.elementor-button:hover { transform: translateY(-3px) scale(1.02); box-shadow: 0 10px 30px rgba(229, 57, 53, 0.4); }
::selection { background: #E53935; color: #FFFFFF; }
```
### Element-Level CSS — Portfolio Cards:
```css
selector { overflow: hidden; }
selector img { transition: transform 0.5s ease, filter 0.5s ease; }
selector:hover img { transform: scale(1.1); filter: brightness(1.1); }
```

## FINAL CHECKLIST
- Edgy, dark, artistic — blacks, reds, golds
- Bold uppercase typography — aggressive feel
- Image-heavy portfolio showcase
- Artist profiles with specialties
- Sharp corners on buttons (no border-radius)
- NO flex_wrap or _flex_size — Publish as draft
