Create a clean, modern landing page for "SparkleClean Co." — a professional residential and commercial cleaning service.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #00ACC1 (fresh cyan)
- Primary Dark: #00838F (deeper cyan for hover)
- Accent: #7CB342 (fresh green)
- Light BG: #F0FAFA (cool mint tint)
- Dark: #1A2A2A (dark teal)
- Dark Surface: #243434
- Light Text: #FFFFFF
- Body Text: #4A5A5A (cool gray)
- Muted: #7A8A8A
- Yellow: #FFB300 (sparkle/highlight)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — clean, fresh, trustworthy
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#00ACC1, weight=600
- Body text: size 16-17px, color=#4A5A5A, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Service cards: _animation='fadeInUp', stagger 100ms
- Pricing cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "professional cleaning service home" — hero
2. "clean modern living room bright" — results
3. "cleaning supplies organized" — about
4. "office cleaning professional night" — commercial
5. "kitchen clean sparkling modern" — residential
6. "cleaning team uniform professional" — team
7. "deep cleaning carpet vacuum" — deep clean
8. "window cleaning professional" — window

## SVG ICONS
- Sparkle icon | Spray bottle icon | Broom icon | Shield icon | Clock icon | Check icon | Home icon | Building icon | Phone icon | Star icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded clean home, overlay #1A2A2A at 0.55
- Min-height 650px
- Row: Left text + Right booking card
  - Label: "PROFESSIONAL CLEANING SERVICE" — color=#7CB342, _animation='fadeInDown'
  - Heading: "A Cleaner Home. A Happier You." — size=48px, _animation='fadeInDown', _animation_delay=200
  - Subtext — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Book Now" (#00ACC1) | "Get Free Estimate" (border #7CB342)
  - Right: "Book in 60 Seconds" card — quick booking CTA

### 2. TRUST BAR
- Background: #00ACC1
- "5,000+ Homes" | "Background Checked" | "Eco-Friendly" | "Satisfaction Guaranteed"

### 3. SERVICES (2 rows of 3)
- Background: #F0FAFA
- 6 cards: Regular Cleaning | Deep Clean | Move-In/Out | Office Cleaning | Carpet Cleaning | Window Cleaning

### 4. PRICING (3 tiers)
- Background: #FFFFFF
- Standard ($129 — 2BR/1BA) | Deep Clean ($199 — 2BR/1BA) | Move-In/Out ($249 — 2BR/1BA)
- "Prices based on 2BR/1BA. Get exact quote online."

### 5. HOW IT WORKS (3 steps)
- Background: #F0FAFA
- 1. Book Online → 2. We Clean → 3. You Relax

### 6. ABOUT (2-column)
- Background: #FFFFFF
- Team photo + about, bonded, insured, eco-friendly products

### 7. ECO-FRIENDLY (dark section)
- Background: #1A2A2A
- Heading: "Green Cleaning Promise" — color=#7CB342
- Benefits: plant-based products, no harsh chemicals, safe for kids & pets

### 8. TESTIMONIALS (3 cards)
- Background: #F0FAFA

### 9. CTA
- Background: #00ACC1
- Heading: "Book Your Clean Today" — _animation='zoomIn'
- Buttons: "Book Online" | "Call (555) 234-5678"

### 10. FOOTER — Background: #1A2A2A

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(0, 172, 193, 0.3); }
::selection { background: #00ACC1; color: #FFFFFF; }
```
### Element-Level CSS — Service Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(26, 42, 42, 0.1); }
```

## FINAL CHECKLIST
- Clean, fresh — cyans, greens, whites
- Pricing transparency with tier cards
- Quick booking prominently featured
- Eco-friendly messaging
- Trust: background checked, insured, satisfaction guaranteed
- NO flex_wrap or _flex_size — Publish as draft
