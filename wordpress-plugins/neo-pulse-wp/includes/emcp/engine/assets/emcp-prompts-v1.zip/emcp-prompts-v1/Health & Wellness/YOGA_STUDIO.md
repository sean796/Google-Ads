Create a serene, mindful landing page for "Lotus Flow Studio" — a yoga and wellness studio.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #7C6F5B (warm sage/earth)
- Accent: #C7956D (warm terracotta)
- Accent Light: #E8D5C4 (blush sand)
- Sage: #8B9F82 (muted sage green)
- Dark: #2D2A26 (warm charcoal)
- Light Text: #FFFFFF
- Body Text: #6B6560 (warm gray)
- Light BG: #FAF7F2 (warm linen)
- Card BG: #FFFFFF
- Border: #E8E0D5

### Typography
- Headings: weight 400-500 (light, flowing), title case — mindful, calm
- Section subtitles: uppercase, letter-spacing=4px, size=11px, color=#C7956D
- Body text: size 16px, color=#6B6560, line-height 1.9

## IMAGE SOURCING — DO THIS FIRST
1. "yoga studio peaceful interior" — hero
2. "yoga class group meditation" — classes
3. "woman yoga pose serene" — about
4. "yoga instructor teaching" — team
5. "meditation peaceful mindfulness" — wellness
6. "yoga props blocks mat" — studio
7. "sunrise yoga outdoor" — special classes
8. "yoga studio candles peaceful" — ambiance

## SVG ICONS
Minimal, peaceful icons: Lotus flower, Om symbol, Leaf, Moon, Sun, Mountain, Water drop, Heart, Clock, Feather.

## PAGE STRUCTURE

### 1. HERO (full-screen, centered, minimal)
- Background: sideloaded yoga studio, background_size='cover'
- Overlay: background_overlay_color='#2D2A26', background_overlay_opacity={size:0.5,unit:'px'}
- Min-height: {size:680,unit:'px'}
- Centered:
  - "BREATHE · MOVE · TRANSFORM" — color=#C7956D, letter-spacing=5px, size=12px
  - "Find Your Flow" — color=#FFFFFF, size=56px, weight=400
  - "A sanctuary for body and mind. Yoga, meditation, and wellness practices for every level." — color=#E8D5C4
  - "View Class Schedule" + "Try Your First Class Free" buttons — terracotta bg + earth tone border

### 2. CLASS TYPES (4 cards)
- Background: background_color='#FAF7F2'
- "CLASSES" subtitle + "Something for Every Body" heading
- Row 4 cards: icon, class name, brief desc, level tag
  - Vinyasa Flow (All Levels) | Yin & Restorative (Gentle) | Power Yoga (Intermediate) | Meditation & Breathwork (All Levels)

### 3. ABOUT (2-column: image left, text right)
- Background: background_color='#FFFFFF'
- Left: Yoga image, Right: "OUR STUDIO" subtitle, "Where Stillness Meets Strength" heading (#2D2A26, weight=400), story about founding, community, trained teachers

### 4. SCHEDULE HIGHLIGHTS
- Background: background_color='#FAF7F2'
- "THIS WEEK" subtitle + "Popular Classes" heading
- Row 3 cards: day/time, class name, instructor, "Reserve Spot" link
  - "Mon 7:00 AM — Sunrise Vinyasa with Maya" | "Wed 6:30 PM — Yin Restore with Sam" | "Sat 9:00 AM — Power Flow with Kai"

### 5. INSTRUCTORS (3 cards)
- Background: background_color='#FFFFFF'
- Row 3: portrait, name, specialty, certifications, bio
  - "Maya Sato — 500hr RYT, Vinyasa & Ashtanga" | "Sam Rivera — Yin & Restorative, Sound Healing" | "Kai Nguyen — Power Yoga, HIIT Yoga"

### 6. WELLNESS OFFERINGS (2-column)
- Background: background_color='#7C6F5B'
- "BEYOND THE MAT" subtitle (#C7956D) + heading (#FFFFFF)
- Left: text about workshops, retreats, teacher training — color=#E8D5C4
- Right: icon list: "Monthly Workshops" | "Weekend Retreats" | "Teacher Training 200hr" | "Private Sessions"

### 7. PRICING (3 cards)
- Background: background_color='#FAF7F2'
- Drop-In ($22) | Monthly Unlimited ($120 — FEATURED) | Annual Membership ($1,080)
- Featured: terracotta border

### 8. TESTIMONIALS (3 cards)
- Background: background_color='#FFFFFF'
- Stars (#C7956D), quote (italic), name + "Member since 2023"

### 9. CTA
- Background: sideloaded sunrise yoga, overlay
- "Your Journey Begins on the Mat" heading (#FFFFFF, weight=400), "First Class Free — No Experience Needed" subtext, "Reserve Your Spot" button

### 10. FOOTER
- Background: background_color='#2D2A26'
- 4 columns — color=#8B8580/#FFFFFF
- Copyright

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; letter-spacing: 1.5px !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(199, 149, 109, 0.2); }
.elementor-image img { transition: transform 0.7s ease; }
.elementor-image:hover img { transform: scale(1.03); }
::selection { background: #C7956D; color: #FFFFFF; }
```

### Element-Level — Class Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-6px); box-shadow: 0 15px 40px rgba(0,0,0,0.06); }
```

### Element-Level — Instructor Cards:
```css
selector { transition: transform 0.3s ease; }
selector:hover { transform: translateY(-5px); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
// Gentle fade-in — slower, more peaceful timing
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.08, rootMargin: '0px 0px -80px 0px' });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-widget-text-editor, .elementor-icon-box-wrapper').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(20px)'; el.style.transition = 'opacity 1s ease, transform 1s ease'; observer.observe(el);
});
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Serene/mindful: earth tones, light font weights, generous spacing, slow animations — Class schedule with times and instructors — Pricing tiers — Publish as draft
