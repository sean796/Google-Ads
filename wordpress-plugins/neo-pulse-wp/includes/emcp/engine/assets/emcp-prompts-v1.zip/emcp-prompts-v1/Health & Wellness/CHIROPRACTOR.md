Create a professional, trustworthy landing page for "AlignWell Chiropractic" — a modern chiropractic and spinal health clinic.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #1E88E5 (calm blue)
- Primary Dark: #1565C0 (deeper blue for hover)
- Accent: #00BFA5 (healing teal)
- Light BG: #F5F9FD (cool light blue)
- Dark: #1A2332 (navy dark)
- Dark Surface: #243447
- Light Text: #FFFFFF
- Body Text: #4A5568 (slate gray)
- Muted: #8A95A5
- Success: #43A047 (green for health)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — confident and professional
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#1E88E5, weight=600
- Body text: size 16-17px, color=#4A5568, line-height 1.8

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp', _animation_delay=0
- Service cards: _animation='fadeInUp', stagger by 100ms
- About image: _animation='fadeInLeft'
- About text: _animation='fadeInRight', _animation_delay=200
- Testimonials: _animation='fadeInUp', stagger 100ms
- Stats: _animation='fadeInUp', stagger 100ms
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "chiropractor adjustment spine professional" — hero background
2. "chiropractic clinic modern interior" — atmosphere
3. "spine anatomy model medical" — services
4. "physical therapy stretching patient" — treatment
5. "doctor patient consultation office" — about
6. "sports injury rehabilitation athlete" — sports chiro
7. "neck pain relief massage" — conditions
8. "happy patient smiling clinic" — testimonials

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Clean, medical-professional icons:
- Spine icon (chiropractic)
- Shield/cross icon (health)
- Person stretching icon (wellness)
- Clipboard icon (assessment)
- Clock icon (hours)
- Star icon (reviews)
- Phone icon (appointments)
- Map pin icon (location)
- Heart icon (care)
- Check circle icon (results)

## PAGE STRUCTURE

### 1. HERO SECTION
Full-width container:
- Background: sideloaded chiropractor image, background_size='cover'
- Overlay: background_overlay_color='#1A2332', background_overlay_opacity={size:0.6,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row with 2 children:
  - Left (60%):
    - Small label: "CHIROPRACTIC · WELLNESS · RELIEF" — color=#00BFA5, size=13px, letter-spacing=4px, _animation='fadeInDown'
    - Main heading: "Get Back to Living Pain-Free" — color=#FFFFFF, size=48px, weight=700, _animation='fadeInDown', _animation_delay=200
    - Subtext: "Expert spinal care backed by science. Our personalized treatment plans help you move better, feel better, and live better." — color=#F5F9FD, size=18px, _animation='fadeInUp', _animation_delay=400
    - Row with buttons (_animation='fadeInUp', _animation_delay=600):
      - "Book an Appointment" — background_color=#1E88E5, text_color=#FFFFFF, border_radius={top:6,right:6,bottom:6,left:6,unit:'px'}
      - "Call Now" — border_color='#00BFA5', text_color=#00BFA5
  - Right: Booking highlight card:
    - background_color='#FFFFFF', padding, border_radius, shadow
    - "New Patient Special" — color=#1E88E5, weight=700
    - "$49 First Visit" — color=#1A2332, size=36px, weight=700
    - "Includes consultation, exam & treatment plan" — color=#4A5568
    - Button: "Claim Offer" — background_color=#1E88E5, text_color=#FFFFFF

### 2. TRUST BAR (4 stats)
- Background: background_background='classic', background_color='#1E88E5'
- Padding: {top:'25',right:'0',bottom:'25',left:'0',unit:'px'}
- Row with 4 children (_animation='fadeInUp', stagger 100ms):
  - "15+" / "Years Experience" | "10,000+" / "Patients Treated" | "4.9★" / "Google Rating" | "Same Day" / "Appointments"

### 3. SERVICES (2 rows of 3)
- Background: background_background='classic', background_color='#F5F9FD'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "OUR SERVICES" — color=#1E88E5, centered
- Heading: "Comprehensive Chiropractic Care" — color=#1A2332, centered, _animation='fadeInUp'
- Row 1: 3 service cards (_animation='fadeInUp', stagger)
- Row 2: 3 service cards

  Each card: white bg, padding, border_radius, centered
  - SVG icon (color=#1E88E5, large)
  - Service name: "Spinal Adjustment" — color=#1A2332, size=18px, weight=700
  - Description — color=#4A5568, size=14px

  Services:
  - Row 1: Spinal Adjustment | Sports Injury Rehab | Posture Correction
  - Row 2: Neck & Back Pain | Sciatica Treatment | Prenatal Chiropractic

### 4. ABOUT (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left: Image (doctor consultation), _animation='fadeInLeft'
  - Right:
    - Subtitle: "ABOUT DR. ALLEN" — color=#1E88E5, _animation='fadeInRight'
    - Heading: "Your Partner in Wellness" — color=#1A2332, _animation='fadeInRight', _animation_delay=100
    - Text: Credentials, philosophy, personalized approach — _animation='fadeInRight', _animation_delay=200
    - Credentials list: "Doctor of Chiropractic (DC)" | "Board Certified" | "15+ Years Experience" | "Sports Medicine Specialist"

### 5. CONDITIONS TREATED (icon list on dark)
- Background: background_background='classic', background_color='#1A2332'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "CONDITIONS WE TREAT" — color=#00BFA5, centered
- Heading: "We Can Help With" — color=#FFFFFF, centered, _animation='fadeInUp'
- Row with 2 columns of icon lists (_animation='fadeInUp', stagger):
  - Left: Back Pain | Neck Pain | Headaches & Migraines | Sciatica
  - Right: Sports Injuries | Posture Issues | Joint Stiffness | Pregnancy Discomfort
  - Icon color=#00BFA5, text color=#FFFFFF

### 6. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#F5F9FD'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row with 3 cards (_animation='fadeInUp', stagger 100ms):
  - White bg, padding, border_radius, shadow
  - Star rating (color=#1E88E5)
  - Quote + Name + "Verified Patient"

### 7. LOCATION (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left (_animation='fadeInLeft'): Address, phone, hours (Mon-Fri 8AM-6PM, Sat 9AM-1PM)
  - Right: Google Maps, _animation='fadeInRight'

### 8. CTA
- Background: background_background='classic', background_color='#1E88E5'
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered:
  - Heading: "Ready to Feel Better?" — color=#FFFFFF, size=42px, _animation='zoomIn'
  - Subtext: "New patients receive a comprehensive exam for just $49. Book online or call today." — color=#FFFFFF, _animation='fadeInUp', _animation_delay=200
  - Row with buttons (_animation='fadeInUp', _animation_delay=400):
    - "Book Online" — background_color=#FFFFFF, text_color=#1E88E5
    - "Call (555) 123-4567" — border_color='#FFFFFF', text_color=#FFFFFF

### 9. FOOTER
- Background: background_background='classic', background_color='#1A2332'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row with 4 columns (_animation='fadeInUp', stagger)
- Divider + copyright

## CUSTOM CSS (minimal)

### Page-Level CSS:
```css
html { scroll-behavior: smooth; }

.elementor-button {
  transition: all 0.3s ease !important;
}
.elementor-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(30, 136, 229, 0.3);
}

::selection {
  background: #1E88E5;
  color: #FFFFFF;
}
```

### Element-Level CSS — Service Cards:
```css
selector {
  transition: transform 0.4s ease, box-shadow 0.4s ease;
}
selector:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 50px rgba(26, 35, 50, 0.1);
}
```

## CUSTOM JAVASCRIPT
Use `add-custom-js` with wrap_dom_ready=true.

```javascript
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 35);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 35);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** with _animation settings
4. **Apply page-level CSS**
5. **Apply element-level CSS** for service cards
6. **Inject custom JS**

## FINAL CHECKLIST
- Professional healthcare aesthetic — blues, teals, clean whites
- Trust-building elements: stats, credentials, Google rating
- New patient offer prominent in hero
- Entrance animations: professional fadeIn/fadeInUp, no bouncy effects
- NO flex_wrap or _flex_size
- Publish the page as draft
