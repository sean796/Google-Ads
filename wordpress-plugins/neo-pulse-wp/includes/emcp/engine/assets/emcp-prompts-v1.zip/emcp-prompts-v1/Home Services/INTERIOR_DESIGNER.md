Create a refined, stylish landing page for "Studio Noir Interiors" — a boutique interior design firm.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #2C2C2C (charcoal)
- Primary Dark: #1A1A1A (deep black for hover)
- Accent: #C9A96E (champagne gold)
- Blush: #E8D5C4 (warm blush)
- Light BG: #F8F5F0 (warm linen)
- Dark: #111111 (near-black)
- Dark Surface: #1E1E1E
- Light Text: #FFFFFF
- Body Text: #555555 (neutral gray)
- Muted: #8A8A8A
- Sage: #7B8B6B (accent green)
- Card BG: #FFFFFF

### Typography
- Headings: weight 300-500, elegant — minimal, refined
- Section subtitles: uppercase, letter-spacing=5px, size=11px, color=#C9A96E, weight=500
- Body text: size 16px, color=#555555, line-height 1.9

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=400
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=600
- Hero button: _animation='fadeInUp', _animation_delay=800
- Section headings: _animation='fadeIn', animation_duration='slow'
- Portfolio cards: _animation='fadeIn', animation_duration='slow', stagger 200ms
- About image: _animation='fadeInLeft', animation_duration='slow'
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "luxury interior design living room" — hero
2. "modern bedroom interior elegant" — portfolio
3. "kitchen design modern minimalist" — portfolio
4. "interior designer working mood board" — about
5. "bathroom luxury marble design" — portfolio
6. "office interior design modern" — commercial
7. "home staging furniture elegant" — staging
8. "interior design detail decor" — details

## SVG ICONS
- Palette/swatch icon | Sofa icon | Ruler icon | Lamp icon | Star icon | Camera icon | Phone icon | Map pin icon | Leaf icon | Compass icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded luxury interior, overlay #111111 at 0.4
- Min-height 700px, centered:
  - Label: "INTERIOR DESIGN · STYLING" — color=#C9A96E, _animation='fadeIn'
  - Heading: "Spaces That Tell Your Story" — size=54px, weight=300, _animation='fadeIn', _animation_delay=400
  - Subtext — _animation='fadeIn', _animation_delay=600
  - Button: "View Portfolio" — #C9A96E, text #111111, _animation='fadeInUp', _animation_delay=800

### 2. PORTFOLIO (2 rows of 3)
- Background: #F8F5F0
- Heading: "Selected Projects" — weight=300, _animation='fadeIn'
- 6 project cards (_animation='fadeIn', stagger 200ms):
  - Image-forward: Modern Minimalist | Coastal Retreat | Urban Loft | Classic Elegance | Scandinavian Warmth | Commercial Office
  - Each: full image, project name + style tag

### 3. SERVICES (3 cards)
- Background: #FFFFFF
- Full Design Service | Room Refresh | Virtual Consultation
- Pricing: from $5,000 | from $1,500 | from $350

### 4. ABOUT (2-column)
- Background: #F8F5F0
- Image (designer at mood board) + story, ASID certified, 12+ years, approach

### 5. PROCESS (4 steps on dark)
- Background: #111111
- 1. Discovery Call → 2. Concept Design → 3. Sourcing & Procurement → 4. Installation & Styling
- Elegant numbered cards

### 6. TESTIMONIALS (2 wide cards)
- Background: #F8F5F0

### 7. CTA
- Background: sideloaded interior detail, overlay
- Heading: "Let's Create Something Beautiful" — weight=300, _animation='fadeIn'
- Buttons: "Book Consultation" (#C9A96E) | "View Portfolio"

### 8. FOOTER — Background: #111111

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(201, 169, 110, 0.3); }
::selection { background: #C9A96E; color: #FFFFFF; }
```
### Element-Level CSS — Portfolio Cards:
```css
selector { overflow: hidden; transition: transform 0.5s ease; }
selector:hover { transform: scale(1.02); }
selector img { transition: transform 0.7s ease; }
selector:hover img { transform: scale(1.08); }
```

## FINAL CHECKLIST
- Refined, minimal — charcoals, champagne gold, warm linen
- Slow, elegant animations — animation_duration='slow'
- Image-forward portfolio
- Process timeline
- NO flex_wrap or _flex_size — Publish as draft
