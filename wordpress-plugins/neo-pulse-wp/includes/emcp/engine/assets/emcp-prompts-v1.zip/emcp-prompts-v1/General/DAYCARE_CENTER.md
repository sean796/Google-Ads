Create a warm, playful, trust-building landing page for "Little Explorers Academy" — a childcare and daycare center.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #FF7043 (warm coral/orange)
- Primary Dark: #E64A19 (deeper coral for hover)
- Accent: #42A5F5 (sky blue)
- Yellow: #FFD54F (sunny yellow)
- Light BG: #FFF8F0 (warm peach tint)
- Dark: #2C1E18 (warm dark)
- Dark Surface: #3E2E26
- Light Text: #FFFFFF
- Body Text: #5A4A42 (warm brown)
- Muted: #8A7A72
- Green: #66BB6A (nature/growth green)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — warm, friendly, trustworthy
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#FF7043, weight=600
- Body text: size 16-17px, color=#5A4A42, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Program cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- Feature icons: _animation='bounceIn', stagger 150ms
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "daycare children playing colorful" — hero
2. "children learning classroom preschool" — programs
3. "kids art painting creative" — creative
4. "daycare teacher reading children" — teacher
5. "playground outdoor kids playing" — outdoor
6. "children eating snack daycare" — nutrition
7. "daycare interior colorful safe" — facility
8. "parent child daycare pickup" — trust

## SVG ICONS
- Star icon | Heart icon | Book icon | Palette/paint icon | Sun icon | Shield icon | Clock icon | Phone icon | Map pin icon | Abc/blocks icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded kids playing, overlay #2C1E18 at 0.5
- Min-height 650px
- Row: Left text + Right tour card
  - Label: "NURTURING MINDS · GROWING HEARTS" — color=#FFD54F, _animation='fadeInDown'
  - Heading: "Where Little Ones Thrive" — size=48px, _animation='fadeInDown', _animation_delay=200
  - Subtext about safe, loving environment, certified teachers, ages 6wks-5yrs — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Schedule a Tour" (#FF7043) | "Call Us" (border #42A5F5)
  - Right: "Now Enrolling!" card with waitlist CTA

### 2. TRUST BAR
- Background: #FF7043
- "Licensed & Accredited" | "Low Teacher Ratios" | "Meals Included" | "Security Cameras"

### 3. PROGRAMS (2 rows of 3)
- Background: #FFF8F0
- 6 program cards (_animation='fadeInUp', stagger):
  - Infant Care (6wks-12mo) | Toddler Program (1-2yrs) | Preschool (3-4yrs) | Pre-K (4-5yrs) | Before/After School | Summer Camp

### 4. WHY CHOOSE US (4 icon boxes)
- Background: #FFFFFF
- Row with 4 features (_animation='bounceIn', stagger 150ms):
  - Low Ratios (1:4 infants, 1:8 preschool) | STEM Curriculum | Nutritious Meals | Safe & Secure

### 5. ABOUT (2-column)
- Background: #FFF8F0
- Image (teacher reading) + story, mission, credentials, 15+ years

### 6. DAILY SCHEDULE (dark section)
- Background: #2C1E18
- Heading: "A Day at Little Explorers" — color=#FFD54F
- Timeline: 7AM Arrival → 9AM Circle Time → 10AM Learning → 12PM Lunch → 1PM Nap → 3PM Activities → 5PM Pickup
- Colorful timeline cards

### 7. TESTIMONIALS (3 cards — parent quotes)
- Background: #FFF8F0

### 8. LOCATION
- Background: #FFFFFF
- Address, hours (Mon-Fri 6:30AM-6:30PM), Google Maps

### 9. CTA
- Background: #42A5F5
- Heading: "Enroll Your Little Explorer Today" — _animation='zoomIn'
- Buttons: "Schedule Tour" | "Call (555) 567-8901"

### 10. FOOTER — Background: #2C1E18

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(255, 112, 67, 0.3); }
::selection { background: #FF7043; color: #FFFFFF; }
```
### Element-Level CSS — Program Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(44, 30, 24, 0.1); }
```

## FINAL CHECKLIST
- Warm, playful, trust-building — corals, sky blues, sunny yellows, nature greens
- Bouncy animations for feature icons (fun, child-friendly energy)
- Programs organized by age group
- Daily schedule gives parents confidence
- Trust elements: licensed, ratios, security, meals
- Tour scheduling prominently featured
- NO flex_wrap or _flex_size — Publish as draft
