Create a warm, literary landing page for "Chapter & Verse" — an independent bookstore and café.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #6B4226 (leather brown)
- Primary Dark: #553318 (darker brown for hover)
- Accent: #D4A76A (parchment gold)
- Cream: #FBF7F0 (old paper)
- Dark: #1E1810 (dark leather)
- Dark Surface: #2E2518
- Light Text: #FFFFFF
- Body Text: #5A4E42 (warm sepia)
- Muted: #8A7E72
- Olive: #5C6B4A (literary green)
- Card BG: #FFFFFF

### Typography
- Headings: weight 600-700, title case with a literary elegance
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#6B4226, weight=600
- Body text: size 16-17px, color=#5A4E42, line-height 1.9

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=300
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=500
- Hero buttons: _animation='fadeInUp', _animation_delay=700
- Section headings: _animation='fadeInUp'
- Book/category cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- About text: _animation='fadeInRight', _animation_delay=200
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "bookstore interior cozy shelves" — hero
2. "stack of books vintage aesthetic" — featured
3. "person reading book coffee shop" — lifestyle
4. "bookstore window display inviting" — atmosphere
5. "children reading books colorful" — kids section
6. "book club discussion group" — events
7. "rare books antique collection" — special
8. "coffee latte book desk" — café

## SVG ICONS
- Book open icon | Bookmark icon | Coffee cup icon | Star icon | Calendar icon | Users icon | Gift icon | Phone icon | Map pin icon | Pen icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded bookstore interior, overlay #1E1810 at 0.5
- Min-height 650px, centered:
  - Label: "INDEPENDENT BOOKSTORE · EST. 2010" — color=#D4A76A, _animation='fadeIn'
  - Heading: "Where Stories Come Alive" — size=52px, weight=600, _animation='fadeIn', _animation_delay=300
  - Subtext about curated collections, cozy café, community — _animation='fadeIn', _animation_delay=500
  - Buttons: "Browse Books" (#6B4226) | "Upcoming Events" (border #D4A76A)

### 2. FEATURE STRIP
- Background: #6B4226
- "10,000+ Titles" | "Cozy Café Inside" | "Weekly Author Events" | "Kids Corner"

### 3. CATEGORIES (2 rows of 3)
- Background: #FBF7F0
- Heading: "Browse Our Shelves" — _animation='fadeInUp'
- 6 category cards: Fiction & Literature | Mystery & Thriller | Science & Nature | Children's | History & Biography | Art & Design
- Each with representative image and description

### 4. ABOUT (2-column)
- Background: #FFFFFF
- Image (reading with coffee) + story, independent spirit, curated selections

### 5. EVENTS & BOOK CLUB (dark section)
- Background: #1E1810
- Heading: "Community & Events" — color=#FFFFFF
- 3 event cards: Weekly Book Club | Author Readings | Children's Story Time

### 6. CAFÉ SECTION (2-column)
- Background: #FBF7F0
- Image (coffee/book) + café menu highlights, reading nooks, free WiFi

### 7. TESTIMONIALS (3 cards)
- Background: #FFFFFF

### 8. CTA
- Background: sideloaded book stack, overlay
- Heading: "Your Next Great Read Awaits" — _animation='zoomIn'
- Buttons: "Shop Online" | "Visit Us"

### 9. FOOTER — Background: #1E1810

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(107, 66, 38, 0.3); }
::selection { background: #6B4226; color: #FFFFFF; }
```
### Element-Level CSS — Category Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(30, 24, 16, 0.12); }
```

## FINAL CHECKLIST
- Warm, literary — leather browns, parchment golds, old paper
- Community events prominently featured
- Café section adds character
- NO flex_wrap or _flex_size — Publish as draft
