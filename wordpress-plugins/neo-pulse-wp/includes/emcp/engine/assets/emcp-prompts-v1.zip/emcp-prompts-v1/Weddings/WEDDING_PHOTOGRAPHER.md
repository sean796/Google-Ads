Create a stunning, photo-centric landing page for "Aria Lane Photography" — a fine art wedding and portrait photographer.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #2C2C2C (charcoal)
- Accent: #B8860B (dark gold/antique)
- Accent Light: #D4B896 (warm wheat)
- Blush: #D4A5A5 (dusty rose)
- Dark: #1A1A1A (near-black)
- Light Text: #FFFFFF
- Body Text: #6B6B6B (soft gray)
- Light BG: #FAFAF7 (warm off-white)
- Card BG: #FFFFFF
- Border: #E5E0DA

### Typography
- Headings: weight 300-400 (ultra-light, artistic), title case or lowercase — the photos speak louder
- Section subtitles: uppercase, letter-spacing=5px, size=11px, color=#B8860B
- Body text: size 16px, color=#6B6B6B, line-height 1.9

## IMAGE SOURCING — DO THIS FIRST
1. "wedding couple sunset golden hour" — hero
2. "bride portrait natural light beautiful" — portfolio
3. "wedding ceremony outdoor romantic" — portfolio
4. "wedding reception first dance" — portfolio
5. "engagement session couple park" — portfolio
6. "wedding details rings flowers flat lay" — portfolio
7. "photographer behind scenes wedding" — about
8. "wedding couple walking beach sunset" — CTA

## SVG ICONS
Ultra-minimal, thin icons: Camera, Heart, Film frame, Star, Calendar, Envelope, Instagram icon, Gallery/grid, Play button, Arrow.

## PAGE STRUCTURE

### 1. HERO (full-screen, photo-forward)
- Background: sideloaded sunset couple image, background_size='cover', background_position='center center'
- Overlay: background_overlay_color='#1A1A1A', background_overlay_opacity={size:0.3,unit:'px'} — keep it light, let the photo shine
- Min-height: {size:750,unit:'px'}
- Centered content (bottom-aligned via justify_content='flex-end', padding-bottom generous):
  - "ARIA LANE PHOTOGRAPHY" — color=#FFFFFF, letter-spacing=6px, size=12px
  - "Timeless Moments, Artfully Captured" — color=#FFFFFF, size=52px, weight=300
  - "View Portfolio" button — background=transparent, border_color='#FFFFFF', text_color=#FFFFFF, border_radius=0

### 2. INTRO TEXT (centered statement)
- Background: background_color='#FAFAF7'
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered: "I believe every love story deserves to be told with beauty, authenticity, and intention. Based in California, available worldwide." — color=#6B6B6B, size=20px, italic, max-width, line-height 2.0

### 3. PORTFOLIO GALLERY (masonry-style grid)
- Background: background_color='#FFFFFF'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- "PORTFOLIO" subtitle centered
- Row 1: 3 images (ceremony, portrait, reception) — various heights via different image crops
- Row 2: 3 images (details, engagement, couple)
- Each image: border_radius=0 (sharp, editorial), overflow hidden

### 4. ABOUT (2-column: image left, text right)
- Background: background_color='#FAFAF7'
- Left: Behind-the-scenes photographer image
- Right (align_items='flex-start'):
  - "HELLO, I'M ARIA" subtitle
  - "The Heart Behind the Lens" heading (#2C2C2C, weight=300)
  - Bio: passion for storytelling, film-inspired editing, 8 years, 300+ weddings, destination work — color=#6B6B6B
  - "Published in: Vogue, Martha Stewart Weddings, The Knot" — color=#B8860B, italic

### 5. EXPERIENCE (the wedding day timeline)
- Background: background_color='#FFFFFF'
- "YOUR EXPERIENCE" subtitle + "What to Expect" heading
- Row 4 steps (process):
  - 1. "Initial Consultation" — "We connect over coffee (or Zoom) to hear your vision."
  - 2. "Engagement Session" — "A relaxed portrait session to get comfortable together."
  - 3. "Wedding Day" — "I arrive early, stay late, and capture every fleeting moment."
  - 4. "Gallery Delivery" — "Your fully edited gallery in 6-8 weeks, with a cinematic film."

### 6. PACKAGES (3 tiers)
- Background: background_color='#FAFAF7'
- "INVESTMENT" subtitle + "Collections" heading
- Row 3 cards:
  - Essentials ($3,800): 8 hours, 1 photographer, online gallery, 400+ edited images
  - Signature ($5,500 — FEATURED): 10 hours, 2 photographers, engagement session, album credit, highlight film
  - Luxury ($8,200): Full day, 2 photographers, engagement, bridal session, album, cinematography, fine art prints
- Featured: subtle gold border (#B8860B)

### 7. TESTIMONIALS (3 cards, minimal)
- Background: background_color='#FFFFFF'
- Large opening quote mark (#B8860B), quote in italic (#6B6B6B), couple names + venue

### 8. FILM / VIDEO CTA
- Background: background_color='#2C2C2C'
- "WEDDING FILMS" subtitle (#B8860B) + "See the Motion" heading (#FFFFFF, weight=300)
- Subtext about cinematic highlight films
- "Watch Films" button — gold border, #B8860B text

### 9. CTA (full-screen photo)
- Background: sideloaded beach sunset couple, overlay light
- "Let's Tell Your Story" heading (#FFFFFF, weight=300, size=48px)
- "Inquire Now" button — #B8860B bg, #FFFFFF text

### 10. INQUIRY FORM (2-column)
- Background: background_color='#FAFAF7'
- Left: "SAY HELLO" subtitle, "I'd love to hear from you." heading, email, Instagram handle, "Based in Los Angeles, CA — available for travel worldwide"
- Right: Form — Names, Email, Phone, Wedding Date, Venue, "How did you find me?" [Instagram, Referral, Google, The Knot, Other], "Tell me about your day" textarea, "Send Inquiry" button

### 11. FOOTER (minimal)
- Background: background_color='#1A1A1A'
- Centered: "Aria Lane Photography" — #FFFFFF, letter-spacing
- Social icons: Instagram, Pinterest — color=#6B6B6B
- Copyright — color=#4A4A4A

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; letter-spacing: 2px !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(184, 134, 11, 0.2); }
.elementor-image img { transition: transform 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94), filter 0.5s ease; }
.elementor-image:hover img { transform: scale(1.03); }
::selection { background: #B8860B; color: #FFFFFF; }
```

### Element-Level — Gallery Images (important — photo showcase):
```css
selector { overflow: hidden; cursor: pointer; }
selector img { transition: transform 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94), filter 0.5s ease; filter: saturate(0.9); }
selector:hover img { transform: scale(1.05); filter: saturate(1.1); }
```

### Element-Level — Package Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-6px); box-shadow: 0 20px 50px rgba(0,0,0,0.06); }
```

### Element-Level — Featured Package:
```css
selector { border: 1px solid #B8860B; }
selector::before { content: 'MOST POPULAR'; position: absolute; top: -1px; left: 50%; transform: translateX(-50%); background: #B8860B; color: #FFFFFF; font-size: 10px; font-weight: 600; letter-spacing: 2px; padding: 5px 15px; }
```

### Element-Level — Process Steps:
```css
selector { transition: transform 0.3s ease; }
selector:hover { transform: translateY(-4px); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
// Slow, cinematic fade-in
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.06, rootMargin: '0px 0px -80px 0px' });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-widget-text-editor').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(20px)'; el.style.transition = 'opacity 1.2s ease, transform 1.2s ease'; observer.observe(el);
});

// Staggered gallery reveal
const galleryImages = document.querySelectorAll('.elementor-image');
galleryImages.forEach((img, i) => {
  img.style.transitionDelay = `${i * 0.15}s`;
});

// Parallax on hero
let ticking = false;
window.addEventListener('scroll', () => {
  if (!ticking) {
    requestAnimationFrame(() => {
      const scrolled = window.scrollY;
      const hero = document.querySelector('.elementor-element[data-element_type="container"]');
      if (hero && scrolled < 900) {
        hero.style.backgroundPositionY = `${50 + scrolled * 0.03}%`;
      }
      ticking = false;
    });
    ticking = true;
  }
});
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS (especially gallery) → 6. Custom JS → 7. Site-wide snippet (optional)

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Photo-first design: minimal text, photos as hero, light overlays — Ultra-light font weights, sharp image borders (editorial/magazine feel) — Gallery with hover saturation effect — Package pricing with tiers — Inquiry form with wedding-specific fields — Slow, cinematic scroll animations — Publish as draft
