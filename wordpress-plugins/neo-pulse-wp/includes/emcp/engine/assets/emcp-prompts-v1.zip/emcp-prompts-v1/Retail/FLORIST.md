Create a beautiful, romantic landing page for "Petal & Bloom" — a boutique florist and flower design studio.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #D4758B (dusty rose)
- Primary Dark: #B85E73 (deeper rose for hover)
- Accent: #6B8F71 (sage leaf green)
- Cream: #FDF7F4 (petal cream)
- Dark: #2D2226 (dark plum)
- Dark Surface: #3E3035
- Light Text: #FFFFFF
- Body Text: #5A4A50 (mauve gray)
- Muted: #8A7A80
- Gold: #C9A96E (ribbon gold)
- Card BG: #FFFFFF

### Typography
- Headings: weight 400-600, elegant title case — romantic, feminine
- Section subtitles: uppercase, letter-spacing=4px, size=11px, color=#D4758B, weight=500
- Body text: size 16px, color=#5A4A50, line-height 1.9

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=300
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=500
- Hero buttons: _animation='fadeInUp', _animation_delay=700
- Section headings: _animation='fadeIn', animation_duration='slow'
- Product cards: _animation='fadeIn', animation_duration='slow', stagger 150ms
- About image: _animation='fadeInLeft', animation_duration='slow'
- About text: _animation='fadeInRight', animation_duration='slow', _animation_delay=200
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "flower bouquet beautiful arrangement" — hero
2. "florist arranging flowers workshop" — about
3. "wedding bouquet bridal flowers" — weddings
4. "flower shop interior colorful" — atmosphere
5. "rose bouquet elegant wrapped" — products
6. "succulent terrarium plant gift" — plants
7. "dried flower arrangement modern" — modern line
8. "flower delivery box beautiful" — delivery

## SVG ICONS
- Flower icon | Leaf icon | Heart icon | Gift icon | Truck icon | Star icon | Calendar icon | Phone icon | Map pin icon | Scissors icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded bouquet, overlay #2D2226 at 0.45
- Min-height 650px, centered:
  - Label: "FLORIST & FLOWER DESIGN" — color=#C9A96E, _animation='fadeIn'
  - Heading: "Where Every Bloom Tells a Story" — color=#FFFFFF, size=52px, weight=400, _animation='fadeIn', _animation_delay=300
  - Subtext — color=#FDF7F4, _animation='fadeIn', _animation_delay=500
  - Buttons: "Shop Bouquets" (#D4758B) | "Wedding Flowers" (border #C9A96E)

### 2. FEATURE STRIP
- Background: #D4758B
- "Same-Day Delivery" | "Fresh Daily" | "Custom Arrangements" | "Wedding Specialists"

### 3. POPULAR ARRANGEMENTS (2 rows of 3)
- Background: #FDF7F4
- Heading: "Our Bestsellers" — _animation='fadeIn'
- 6 product cards (_animation='fadeIn', stagger 150ms):
  - Each: Image, name, description, price
  - Classic Rose Bouquet ($65) | Wildflower Mix ($55) | Elegant White Lily ($75) | Sunshine Daisy ($45) | Premium Orchid ($85) | Dried Bouquet ($60)

### 4. SERVICES (2-column: image + services list)
- Background: #FFFFFF
- Image (wedding bouquet) + Services: Wedding Flowers | Event Decor | Subscriptions | Corporate Floral | Sympathy Arrangements

### 5. ABOUT (2-column)
- Background: #FDF7F4
- Image (florist at work) + story, passion, sourcing from local farms

### 6. WEDDING FLOWERS (dark section)
- Background: #2D2226
- Heading: "Wedding & Event Florals" — color=#FFFFFF
- 3 cards: Bridal Package ($500+) | Full Wedding ($2,000+) | Consultation (Free)

### 7. TESTIMONIALS (3 cards)
- Background: #FDF7F4

### 8. CTA
- Background: sideloaded flower shop interior, overlay
- Heading: "Send Something Beautiful" — _animation='fadeIn'
- Buttons: "Order Now" | "Call (555) 567-8901"

### 9. FOOTER — Background: #2D2226

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(212, 117, 139, 0.3); }
::selection { background: #D4758B; color: #FFFFFF; }
```
### Element-Level CSS — Product Cards:
```css
selector { transition: transform 0.5s ease, box-shadow 0.5s ease; }
selector:hover { transform: translateY(-6px); box-shadow: 0 15px 40px rgba(0,0,0,0.08); }
selector img { transition: transform 0.6s ease; }
selector:hover img { transform: scale(1.05); }
```

## FINAL CHECKLIST
- Romantic, feminine — dusty roses, sage greens, creams
- Slow, graceful animations — elegant feel
- Product cards with pricing
- Wedding services highlighted
- NO flex_wrap or _flex_size — Publish as draft
