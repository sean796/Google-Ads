Create a playful, colorful landing page for "Scoops & Dreams" — a gourmet ice cream and gelato shop.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #E91E63 (strawberry pink)
- Primary Dark: #C2185B (deeper pink for hover)
- Accent: #7C4DFF (grape purple)
- Mint: #26C6DA (mint chip)
- Yellow: #FFD54F (vanilla/banana)
- Light BG: #FFF5F8 (blush pink)
- Dark: #2D1B33 (deep purple-black)
- Dark Surface: #3E2A45
- Light Text: #FFFFFF
- Body Text: #5D4A62 (warm mauve)
- Muted: #9A8A9E
- Card BG: #FFFFFF

### Typography
- Headings: weight 700-800, playful title case — fun and whimsical
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#E91E63, weight=600
- Body text: size 16-17px, color=#5D4A62, line-height 1.8

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required

## ENTRANCE ANIMATIONS
- Hero heading: _animation='bounceIn', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp', _animation_delay=0
- Flavor cards: _animation='zoomIn', stagger by 100ms
- About image: _animation='fadeInLeft'
- About text: _animation='fadeInRight', _animation_delay=200
- Testimonials: _animation='fadeInUp', stagger 100ms
- Party section: _animation='bounceIn', stagger 150ms
- CTA: _animation='bounceIn'

## IMAGE SOURCING — DO THIS FIRST
1. "ice cream shop colorful display" — hero background
2. "gelato scoops variety flavors" — menu
3. "ice cream cone waffle close up" — menu
4. "ice cream sundae dessert" — specials
5. "ice cream making artisan process" — story
6. "kids eating ice cream happy" — family vibe
7. "milkshake thick straw colorful" — drinks
8. "ice cream shop interior fun" — atmosphere

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Fun, rounded icons:
- Ice cream cone icon (general)
- Cherry icon (toppings)
- Star icon (favorites/reviews)
- Heart icon (love)
- Gift icon (party/events)
- Clock icon (hours)
- Truck icon (delivery)
- Sparkle icon (new flavors)
- Map pin icon (location)
- Cake icon (events)

## PAGE STRUCTURE

### 1. HERO SECTION
Full-width container:
- Background: sideloaded ice cream display, background_size='cover'
- Overlay: background_overlay_color='#2D1B33', background_overlay_opacity={size:0.5,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Centered content:
  - Small label: "HANDCRAFTED GELATO · SINCE 2019" — color=#FFD54F, size=13px, letter-spacing=4px, _animation='fadeInDown'
  - Main heading: "Life Is Better with Sprinkles" — color=#FFFFFF, size=52px, weight=800, _animation='bounceIn', _animation_delay=200
  - Subtext: "Over 40 artisan flavors, made fresh daily with real cream and local ingredients. Scoop into happiness!" — color=#FFF5F8, size=18px, _animation='fadeInUp', _animation_delay=400
  - Row with buttons (_animation='fadeInUp', _animation_delay=600):
    - "See All Flavors" — background_color=#E91E63, text_color=#FFFFFF, border_radius={top:30,right:30,bottom:30,left:30,unit:'px'}
    - "Order Delivery" — border_color='#FFD54F', text_color=#FFD54F, border_radius rounded
  - Small text: "Open daily until 10PM" — color=#FFF5F8, size=14px

### 2. FLAVOR STRIP (4 highlights)
- Background: background_background='classic', background_color='#E91E63'
- Padding: {top:'25',right:'0',bottom:'25',left:'0',unit:'px'}
- Row with 4 children:
  - "40+ Flavors" | "Made Fresh Daily" | "Vegan Options" | "Party Catering"
  - Icon + text, color=#FFFFFF

### 3. POPULAR FLAVORS (2 rows of 3)
- Background: background_background='classic', background_color='#FFF5F8'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "FAN FAVORITES" — color=#E91E63, centered
- Heading: "Our Most-Loved Flavors" — color=#2D1B33, centered, _animation='fadeInUp'
- Row 1: 3 flavor cards (_animation='zoomIn', stagger 100ms)
- Row 2: 3 flavor cards

  Each card (column container):
  - Image widget, border_radius={top:20,right:20,bottom:20,left:20,unit:'px'}
  - Content: padding, centered
  - Flavor name: "Salted Caramel Swirl" — color=#2D1B33, size=18px, weight=700
  - Description: "Rich caramel ribboned through vanilla bean gelato" — color=#5D4A62, size=14px
  - Price row: "$5.50 / scoop" — color=#E91E63, size=18px, weight=600

  Flavors:
  - Row 1: Salted Caramel Swirl ($5.50) | Double Chocolate Fudge ($5.50) | Strawberry Fields ($5.00)
  - Row 2: Pistachio Dream ($6.00) | Mango Sorbet ($5.00) | Cookie Dough Monster ($6.50)

### 4. ABOUT (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left: Image (artisan making ice cream), _animation='fadeInLeft'
  - Right:
    - Subtitle: "OUR STORY" — color=#E91E63, _animation='fadeInRight'
    - Heading: "Small Batch, Big Flavor" — color=#2D1B33, size=36px, _animation='fadeInRight', _animation_delay=100
    - Text: Founded by pastry chefs, every batch made in-house with real cream, fresh fruit, no artificial flavors — _animation='fadeInRight', _animation_delay=200
    - Stats (_animation='fadeInUp', _animation_delay=300):
      - "40+" / "Flavors" | "5K+" / "Scoops Daily" | "100%" / "Real Cream"

### 5. PARTY & EVENTS (dark section)
- Background: background_background='classic', background_color='#2D1B33'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "CELEBRATIONS" — color=#FFD54F, centered
- Heading: "Scoop Up the Fun" — color=#FFFFFF, centered, _animation='fadeInUp'
- Row with 3 cards (_animation='bounceIn', stagger 150ms):
  - Each: background_color='#3E2A45', padding, border_radius={top:16,right:16,bottom:16,left:16,unit:'px'}, centered
  - SVG icon (color=#E91E63, large)
  - Title: "Birthday Parties" — color=#FFFFFF, size=18px
  - Description — color=#9A8A9E, size=14px
  - Services: Birthday Parties | Catering & Events | Ice Cream Truck

### 6. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#FFF5F8'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row with 3 cards (_animation='fadeInUp', stagger):
  - White bg, padding, border_radius rounded, playful border (#E91E63 thin)
  - Star rating (color=#FFD54F)
  - Quote — italic
  - Name + "Ice Cream Lover"

### 7. LOCATION
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left (_animation='fadeInLeft'): Address, hours (daily 11AM-10PM), phone
  - Right: Google Maps, _animation='fadeInRight'

### 8. CTA
- Background: background_background='classic', background_color='#7C4DFF'
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered:
  - Heading: "Craving a Scoop?" — color=#FFFFFF, size=42px, _animation='bounceIn'
  - Subtext: "Order online for pickup or delivery. Don't forget the sprinkles!" — color=#FFFFFF, _animation='fadeInUp', _animation_delay=200
  - Row with buttons (_animation='fadeInUp', _animation_delay=400):
    - "Order Now" — background_color=#FFFFFF, text_color=#7C4DFF
    - "Gift Cards" — border_color='#FFD54F', text_color=#FFD54F

### 9. FOOTER
- Background: background_background='classic', background_color='#2D1B33'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row with 4 columns (_animation='fadeInUp', stagger)
- Divider + copyright

## CUSTOM CSS (minimal)

### Page-Level CSS:
```css
html { scroll-behavior: smooth; }

.elementor-button {
  transition: all 0.3s ease !important;
}
.elementor-button:hover {
  transform: translateY(-2px) scale(1.02);
  box-shadow: 0 8px 25px rgba(233, 30, 99, 0.3);
}

::selection {
  background: #E91E63;
  color: #FFFFFF;
}
```

### Element-Level CSS — Flavor Cards:
```css
selector {
  transition: transform 0.4s ease, box-shadow 0.4s ease;
}
selector:hover {
  transform: translateY(-10px) rotate(-1deg);
  box-shadow: 0 25px 50px rgba(45, 27, 51, 0.15);
}
```

## CUSTOM JAVASCRIPT
Use `add-custom-js` with wrap_dom_ready=true.

```javascript
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 35);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 35);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** with _animation settings
4. **Apply page-level CSS**
5. **Apply element-level CSS** for flavor cards
6. **Inject custom JS**

## FINAL CHECKLIST
- Entrance animations: bounceIn for hero heading, party cards, CTA; zoomIn for flavor cards
- Playful, colorful palette — pinks, purples, yellows, mint
- Rounded corners (16-30px) throughout
- Fun hover: slight rotation on flavor cards
- NO flex_wrap or _flex_size
- Publish the page as draft
