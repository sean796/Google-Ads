Create a visually striking, artistic landing page for "Lens & Light Studio" — a professional photography studio.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #212121 (deep charcoal)
- Primary Dark: #111111 (near-black for hover)
- Accent: #FF7043 (warm coral)
- Gold: #C9A96E (warm gold)
- Light BG: #F5F3F0 (warm gray)
- Dark: #0A0A0A (pitch black)
- Dark Surface: #1A1A1A
- Light Text: #FFFFFF
- Body Text: #555555 (neutral gray)
- Muted: #8A8A8A
- Card BG: #FFFFFF

### Typography
- Headings: weight 300-500, elegant — artistic, clean
- Section subtitles: uppercase, letter-spacing=5px, size=11px, color=#FF7043, weight=500
- Body text: size 16px, color=#555555, line-height 1.9

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=400
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=600
- Hero button: _animation='fadeInUp', _animation_delay=800
- Section headings: _animation='fadeIn', animation_duration='slow'
- Portfolio images: _animation='fadeIn', animation_duration='slow', stagger 150ms
- About image: _animation='fadeInLeft', animation_duration='slow'
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "photography studio professional lighting" — hero
2. "portrait photography professional woman" — portrait
3. "wedding photography couple outdoor" — wedding
4. "product photography studio setup" — commercial
5. "family portrait photography studio" — family
6. "event photography corporate" — events
7. "photographer camera close up" — about
8. "photo gallery exhibition prints" — gallery

## SVG ICONS
- Camera icon | Aperture icon | Image/photo icon | Star icon | Calendar icon | Film icon | Phone icon | Map pin icon | Heart icon | Light icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded studio, overlay #0A0A0A at 0.5
- Min-height 700px, centered:
  - Label: "PHOTOGRAPHY · VIDEOGRAPHY · ART" — color=#FF7043, _animation='fadeIn'
  - Heading: "Capturing Moments That Matter" — size=54px, weight=300, _animation='fadeIn', _animation_delay=400
  - Subtext — _animation='fadeIn', _animation_delay=600
  - Button: "View Portfolio" — #FF7043, _animation='fadeInUp', _animation_delay=800

### 2. PORTFOLIO GALLERY (2 rows of 3)
- Background: #F5F3F0
- Heading: "Selected Work" — weight=300, _animation='fadeIn'
- 6 image-forward cards (_animation='fadeIn', stagger 150ms):
  - Portrait | Wedding | Family | Commercial/Product | Event | Fine Art
  - Each: full image, genre label, minimal text

### 3. SERVICES (3 cards)
- Background: #FFFFFF
- Heading: "Photography Services"
- Portrait Sessions (from $250) | Wedding Photography (from $2,500) | Commercial (from $500)
- Each with description and what's included

### 4. ABOUT (2-column)
- Background: #F5F3F0
- Image (photographer) + story, 10+ years, published work, approach

### 5. THE EXPERIENCE (4 steps on dark)
- Background: #0A0A0A
- 1. Consultation → 2. Photo Session → 3. Editing & Curation → 4. Delivery
- Elegant numbered cards

### 6. PACKAGES (3 tiers)
- Background: #FFFFFF
- Essential ($250): 1hr session, 15 edited photos
- Premium ($500 — POPULAR): 2hr, 40 photos, prints
- Luxury ($900): Half-day, unlimited photos, album, prints

### 7. TESTIMONIALS (3 cards)
- Background: #F5F3F0

### 8. CTA
- Background: sideloaded gallery/exhibition, overlay
- Heading: "Let's Create Something Beautiful" — weight=300, _animation='fadeIn'
- Buttons: "Book a Session" (#FF7043) | "Contact Us"

### 9. FOOTER — Background: #0A0A0A

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(255, 112, 67, 0.3); }
::selection { background: #FF7043; color: #FFFFFF; }
```
### Element-Level CSS — Portfolio Cards:
```css
selector { overflow: hidden; transition: transform 0.5s ease; }
selector:hover { transform: scale(1.02); }
selector img { transition: transform 0.7s ease, filter 0.5s ease; }
selector:hover img { transform: scale(1.08); filter: brightness(1.05); }
```

## FINAL CHECKLIST
- Artistic, visual-first — charcoals, warm coral, gold
- Slow, deliberate animations
- Image-heavy portfolio (hero of the page)
- Tiered session packages
- Process/experience timeline
- NO flex_wrap or _flex_size — Publish as draft
