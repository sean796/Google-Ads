Create an inspiring, creative landing page for "Crescendo Music Academy" — a music school offering lessons for all ages and instruments.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #5C6BC0 (indigo blue)
- Primary Dark: #3F51B5 (deeper indigo for hover)
- Accent: #FF7043 (warm coral)
- Light BG: #F5F5FA (soft lavender tint)
- Dark: #1A1A2E (dark navy)
- Dark Surface: #252540
- Light Text: #FFFFFF
- Body Text: #4A4A5A (slate)
- Muted: #7A7A8A
- Gold: #FFB300 (achievement gold)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — inspiring and creative
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#5C6BC0, weight=600
- Body text: size 16-17px, color=#4A4A5A, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Instrument/lesson cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- About text: _animation='fadeInRight', _animation_delay=200
- Testimonials: _animation='fadeInUp', stagger 100ms
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "music school students instruments" — hero
2. "piano teacher lesson student" — lessons
3. "guitar lesson acoustic student" — lessons
4. "music studio recording equipment" — studio
5. "children music class singing" — kids
6. "violin practice student classical" — classical
7. "drum kit music lesson" — percussion
8. "music recital performance stage" — events

## SVG ICONS
- Music note icon | Piano icon | Guitar icon | Microphone icon | Star icon | Clock icon | Calendar icon | Users icon | Phone icon | Map pin icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded music school, overlay #1A1A2E at 0.6
- Min-height 650px
- Row: Left text + Right "Free Trial" card
  - Label: "MUSIC LESSONS FOR ALL AGES" — color=#FF7043, _animation='fadeInDown'
  - Heading: "Find Your Rhythm" — size=48px, _animation='fadeInDown', _animation_delay=200
  - Subtext about expert instructors, all instruments, beginner to advanced — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Book Free Trial" (#5C6BC0) | "View Programs" (border #FF7043)
  - Right: "First Lesson Free" card

### 2. TRUST BAR
- Background: #5C6BC0
- "500+ Students" | "20+ Instruments" | "15 Instructors" | "Annual Recital"

### 3. INSTRUMENT PROGRAMS (2 rows of 3)
- Background: #F5F5FA
- Heading: "Choose Your Instrument" — _animation='fadeInUp'
- 6 cards (_animation='fadeInUp', stagger):
  - Piano | Guitar | Voice | Violin | Drums | Bass & Ukulele
  - Each: icon, instrument name, age range, "from $35/lesson"

### 4. ABOUT (2-column)
- Background: #FFFFFF
- Image (teacher with student) + academy story, teaching philosophy, certified instructors

### 5. AGE GROUPS (3 cards on dark)
- Background: #1A1A2E
- Heading: "Programs for Every Age" — color=#FFFFFF
- 3 cards: Little Stars (4-7) | Young Musicians (8-14) | Teens & Adults (15+)
- Each with description and available instruments

### 6. WHY CHOOSE US (4 icon boxes)
- Background: #F5F5FA
- Row: Expert Teachers | Flexible Scheduling | Performance Opportunities | Free Trial Lesson

### 7. TESTIMONIALS (3 cards)
- Background: #FFFFFF

### 8. CTA
- Background: #5C6BC0
- Heading: "Start Your Musical Journey" — _animation='zoomIn'
- Buttons: "Book Free Trial" | "Call (555) 890-1234"

### 9. FOOTER — Background: #1A1A2E

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(92, 107, 192, 0.3); }
::selection { background: #5C6BC0; color: #FFFFFF; }
```
### Element-Level CSS — Program Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(26, 26, 46, 0.1); }
```

## FINAL CHECKLIST
- Inspiring, creative — indigo blues, warm corals, achievement gold
- Free trial lesson prominently featured
- Programs organized by instrument and age
- Trust: student count, instructor count
- NO flex_wrap or _flex_size — Publish as draft
