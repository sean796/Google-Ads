Create a breezy, relaxed landing page for "The Garden Table" — an outdoor garden cafe and brunch spot.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #2D6A4F (forest green)
- Primary Light: #40916C (sage green)
- Accent: #E07A5F (terracotta/coral)
- Accent Light: #F2CC8F (warm sand/wheat)
- Dark: #1B2A21 (deep forest)
- Light Text: #FFFFFF
- Body Text: #5C6B62 (muted green-gray)
- Light BG: #F7F5F0 (natural parchment)
- Card BG: #FFFFFF
- Border: #D4CFC4

### Typography
- Headings: weight 600-700, title case, warm and friendly
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#E07A5F
- Body text: size 16px, color=#5C6B62, line-height 1.8

## IMAGE SOURCING — DO THIS FIRST
1. "outdoor cafe garden terrace" — hero background
2. "brunch food avocado toast beautiful" — menu
3. "fresh salad outdoor dining" — menu
4. "cafe latte art garden setting" — menu/drinks
5. "outdoor patio string lights evening" — ambiance
6. "fresh juice smoothie colorful" — drinks
7. "pastry display cafe bakery" — menu
8. "herb garden fresh restaurant" — about

## SVG ICONS
Organic, nature-inspired line icons: Leaf, Sun, Coffee cup, Flower, Fork & knife, Umbrella, Bike, Heart, Clock, Map pin.

## PAGE STRUCTURE

### 1. HERO SECTION
- Background: sideloaded garden cafe, background_size='cover'
- Overlay: background_overlay_color='#1B2A21', background_overlay_opacity={size:0.45,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Centered:
  - "FARM-TO-TABLE · GARDEN DINING" — color=#F2CC8F, uppercase, letter-spacing
  - "Dine Under the Open Sky" — color=#FFFFFF, size=52px, weight=700
  - "Fresh, seasonal dishes served in our sunlit garden. Where every meal feels like a Sunday morning." — color=#F7F5F0
  - "Reserve a Table" + "View Menu" buttons — terracotta bg + green border

### 2. FEATURE STRIP
- Background: background_color='#2D6A4F'
- Row 3 children: "100% Organic Ingredients" | "Garden Seating for 80" | "Pet-Friendly Patio" — #FFFFFF

### 3. MENU HIGHLIGHTS (6 items)
- Background: background_color='#F7F5F0'
- "SEASONAL MENU" subtitle + "Garden Fresh Favorites" heading
- 3x2 grid: image + name + desc + price
  - Avocado Toast ($13) | Garden Salad Bowl ($15) | Eggs Benedict ($16) | Mushroom Risotto ($18) | Berry Smoothie Bowl ($12) | Lemon Lavender Cake ($9)

### 4. AMBIANCE SECTION (2-column: text left, image right)
- Background: background_color='#FFFFFF'
- "THE EXPERIENCE" subtitle, "More Than Just a Meal" heading, text about garden setting, live music weekends, farm partnerships

### 5. DRINKS (3 cards)
- Background: background_color='#2D6A4F'
- "FROM THE BAR" subtitle (#F2CC8F) + heading (#FFFFFF)
- Row 3 cards: Signature Botanical Gin & Tonic ($14) | Cold Press Green Juice ($8) | Honey Lavender Latte ($6)

### 6. EVENTS CTA
- Background: sideloaded string lights image, overlay
- "Host Your Next Event in the Garden" heading (#FFFFFF), "Private dining, birthdays, rehearsal dinners" subtext, "Inquire Now" button

### 7. TESTIMONIALS (3 cards)
- Background: background_color='#F7F5F0'
- Stars (#E07A5F), quote, name

### 8. LOCATION (2-column)
- Background: background_color='#FFFFFF'
- Left: Address, phone, hours (Tue-Sun 8AM-9PM, Closed Mon), "Reservations recommended for weekend brunch"
- Right: Google Maps

### 9. FOOTER
- Background: background_color='#1B2A21'
- 4 columns — color=#8FAF9A/#FFFFFF
- Copyright

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(45, 106, 79, 0.25); }
.elementor-image img { transition: transform 0.6s ease; }
.elementor-image:hover img { transform: scale(1.04); }
::selection { background: #2D6A4F; color: #FFFFFF; }
```

### Element-Level — Menu Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-7px); box-shadow: 0 15px 40px rgba(45, 106, 79, 0.1); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-widget-text-editor').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(25px)'; el.style.transition = 'opacity 0.7s ease, transform 0.7s ease'; observer.observe(el);
});
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Natural, organic palette: greens, terracotta, sand, parchment — Menu with seasonal items + prices — Publish as draft
