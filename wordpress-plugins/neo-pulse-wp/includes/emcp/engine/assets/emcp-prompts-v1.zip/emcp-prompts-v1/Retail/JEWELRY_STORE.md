Create a luxurious, elegant landing page for "Aurelius Fine Jewelry" — a high-end jewelry store.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #1A1A1A (onyx black)
- Accent: #C9A44E (rich gold)
- Accent Light: #DFC273 (lighter gold)
- Light BG: #FAF8F3 (champagne ivory)
- Dark: #0A0A0A (deep black)
- Dark Surface: #1A1A1A
- Light Text: #FFFFFF
- Body Text: #555555 (neutral gray)
- Muted: #8A8A8A
- Rose: #B76E79 (rose gold accent)
- Card BG: #FFFFFF

### Typography
- Headings: weight 300-500, elegant, serif feel — luxury, refined
- Section subtitles: uppercase, letter-spacing=6px, size=11px, color=#C9A44E, weight=500
- Body text: size 16px, color=#555555, line-height 1.9

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=400
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=600
- Hero buttons: _animation='fadeInUp', _animation_delay=800
- Section headings: _animation='fadeIn', animation_duration='slow'
- Collection cards: _animation='fadeIn', animation_duration='slow', stagger 200ms
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "luxury jewelry display diamond" — hero
2. "diamond ring engagement elegant" — engagement
3. "gold necklace elegant woman" — necklaces
4. "luxury watch collection display" — watches
5. "jeweler crafting gold workshop" — craftsmanship
6. "jewelry store interior luxury" — atmosphere
7. "pearl earrings elegant" — earrings
8. "wedding rings gold platinum" — wedding

## SVG ICONS
- Diamond icon | Ring icon | Star icon | Shield icon | Gift icon | Heart icon | Clock icon | Phone icon | Map pin icon | Sparkle icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded diamond jewelry, overlay #0A0A0A at 0.5
- Min-height 700px, centered:
  - Label: "FINE JEWELRY · SINCE 1985" — color=#C9A44E, letter-spacing=6px, _animation='fadeIn'
  - Heading: "Timeless Elegance" — color=#FFFFFF, size=58px, weight=300, _animation='fadeIn', _animation_delay=400
  - Subtext — color=#FAF8F3, _animation='fadeIn', _animation_delay=600
  - Buttons: "Shop Collections" (#C9A44E, text #0A0A0A) | "Book Appointment" (border #C9A44E)

### 2. COLLECTIONS (2 rows of 3)
- Background: #FAF8F3
- Heading: "Our Collections" — weight=300, _animation='fadeIn'
- 6 collection cards (_animation='fadeIn', stagger 200ms):
  - Engagement Rings (from $2,500) | Diamond Necklaces (from $1,200) | Fine Earrings (from $800) | Luxury Watches (from $3,000) | Wedding Bands (from $900) | Custom Designs (consultation)

### 3. CRAFTSMANSHIP (2-column on dark)
- Background: #0A0A0A
- Image (jeweler at work) + text about master craftsmen, 4 generations, ethically sourced stones

### 4. SERVICES (4 cards)
- Background: #FAF8F3
- Custom Design | Repair & Restoration | Appraisals | Engraving

### 5. ABOUT
- Background: #FFFFFF
- Story, heritage, GIA certified, conflict-free diamonds

### 6. TESTIMONIALS (3 cards)
- Background: #FAF8F3

### 7. CTA
- Background: #1A1A1A
- Heading: "Find Your Forever Piece" — weight=300, _animation='fadeIn'
- Buttons: "Visit Us" | "Book Private Appointment"

### 8. FOOTER — Background: #0A0A0A

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(201, 164, 78, 0.3); }
::selection { background: #C9A44E; color: #FFFFFF; }
```
### Element-Level CSS — Collection Cards:
```css
selector { transition: transform 0.5s ease, box-shadow 0.5s ease; }
selector:hover { transform: translateY(-6px); box-shadow: 0 15px 40px rgba(0,0,0,0.1); }
selector img { transition: transform 0.7s ease; }
selector:hover img { transform: scale(1.06); }
```

## FINAL CHECKLIST
- Luxury, refined — black, gold, champagne ivory
- Slow, deliberate animations — conveying exclusivity
- Collection cards with "from" pricing
- Services include custom design
- NO flex_wrap or _flex_size — Publish as draft
