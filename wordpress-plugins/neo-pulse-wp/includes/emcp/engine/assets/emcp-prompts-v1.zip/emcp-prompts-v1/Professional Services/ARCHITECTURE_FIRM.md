Create a sophisticated, visually striking landing page for "Atelier Grey Architecture" — a modern architecture and design firm.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #2C2C2C (architectural charcoal)
- Primary Dark: #1A1A1A (near black for hover)
- Accent: #D4A373 (warm terracotta/copper)
- Light BG: #F5F3F0 (warm concrete)
- Dark: #111111 (deep black)
- Dark Surface: #1E1E1E
- Light Text: #FFFFFF
- Body Text: #555555 (neutral gray)
- Muted: #888888
- Card BG: #FFFFFF
- Line: #E0DCD8 (subtle warm gray border)

### Typography
- Headings: weight 300-500, uppercase or title case — minimal, architectural
- Section subtitles: uppercase, letter-spacing=5px, size=11px, color=#D4A373, weight=500
- Body text: size 16px, color=#555555, line-height 1.9

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=400
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=600
- Hero button: _animation='fadeInUp', _animation_delay=800
- Section headings: _animation='fadeIn', animation_duration='slow'
- Project cards: _animation='fadeIn', animation_duration='slow', stagger 200ms
- About image: _animation='fadeInLeft', animation_duration='slow'
- About text: _animation='fadeInRight', animation_duration='slow'
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "modern architecture building minimal" — hero
2. "architectural interior design modern" — project
3. "modern house exterior design" — residential
4. "commercial building architecture glass" — commercial
5. "architect working blueprint model" — about
6. "architecture interior concrete wood" — project
7. "sustainable architecture green building" — sustainability
8. "architectural detail facade modern" — portfolio

## SVG ICONS
- Compass/ruler icon (design)
- Building icon (architecture)
- Blueprint icon (planning)
- Home icon (residential)
- Cube icon (3D modeling)
- Leaf icon (sustainability)
- Star icon (awards)
- Phone icon (contact)
- Map pin icon (location)
- Pencil icon (design)

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded modern architecture, background_size='cover'
- Overlay: #111111 at 0.45
- Min-height: 700px
- Centered:
  - Label: "ARCHITECTURE · DESIGN · VISION" — color=#D4A373, letter-spacing=6px, _animation='fadeIn'
  - Heading: "Design That Defines Space" — color=#FFFFFF, size=56px, weight=300, _animation='fadeIn', _animation_delay=400
  - Subtext: "Award-winning architecture firm creating spaces that inspire, function, and endure. Residential. Commercial. Sustainable." — color=#F5F3F0, _animation='fadeIn', _animation_delay=600
  - Button: "View Our Work" — background_color=#D4A373, text_color=#111111, _animation='fadeInUp', _animation_delay=800

### 2. STATS BAR
- Background: #2C2C2C
- 4 stats: "15+" years | "200+" projects completed | "12" design awards | "LEED" certified

### 3. FEATURED PROJECTS (2 rows of 3)
- Background: #F5F3F0
- Subtitle: "PORTFOLIO" — color=#D4A373
- Heading: "Selected Work" — weight=300, _animation='fadeIn'
- 6 project cards (_animation='fadeIn', stagger 200ms):
  - Image-heavy cards with minimal text overlay
  - Each: Image, project name, category tag (Residential/Commercial/Mixed-Use)
  - Projects: "The Ridge House" (Residential) | "Nova Tower" (Commercial) | "Elm Street Lofts" (Mixed-Use) | "Coastal Retreat" (Residential) | "Tech Campus HQ" (Commercial) | "Green Haven" (Sustainable)

### 4. ABOUT / PHILOSOPHY (2-column)
- Background: #FFFFFF
- Image (architect at work) + philosophy text
- "Design is not decoration — it's the fundamental structure of experience."
- Credentials and approach

### 5. SERVICES (4 cards on dark)
- Background: #111111
- Heading: "Services" — color=#FFFFFF, weight=300
- 4 cards (_animation='fadeIn', stagger 200ms):
  - Architectural Design | Interior Design | Urban Planning | Sustainable Design
  - Dark surface, icon, title, brief description

### 6. PROCESS (horizontal 4-step)
- Background: #F5F3F0
- Heading: "Our Process" — _animation='fadeIn'
- Row with 4 step containers (_animation='fadeInUp', stagger):
  - 01 Concept → 02 Design → 03 Develop → 04 Build
  - Each: number (color=#D4A373, size=40px, weight=300), title, short description
  - Connected by subtle divider lines

### 7. TESTIMONIALS (2 cards wide)
- Background: #FFFFFF
- 2 large testimonial cards side by side

### 8. CTA
- Background: sideloaded architecture detail, overlay
- Heading: "Let's Build Something Extraordinary" — weight=300, _animation='fadeIn'
- Button: "Start a Conversation" — #D4A373

### 9. FOOTER
- Background: #111111
- 4 columns, divider, copyright

## CUSTOM CSS (minimal)

### Page-Level CSS:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(212, 163, 115, 0.3); }
::selection { background: #D4A373; color: #FFFFFF; }
```

### Element-Level CSS — Project Cards:
```css
selector { transition: transform 0.5s ease; overflow: hidden; }
selector:hover { transform: scale(1.02); }
selector img { transition: transform 0.6s ease; }
selector:hover img { transform: scale(1.08); }
```

### Element-Level CSS — Service Cards:
```css
selector { transition: border-color 0.4s ease; border: 1px solid transparent; }
selector:hover { border-color: #D4A373; }
```

## CUSTOM JAVASCRIPT
Counter animation for stats.

## FINAL CHECKLIST
- Minimal, architectural aesthetic — charcoals, terracotta, warm concrete
- Slow, deliberate animations — weight=300 headings, animation_duration='slow'
- Image-heavy project showcase
- Process timeline with numbered steps
- NO flex_wrap or _flex_size — Publish as draft
