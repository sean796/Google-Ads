Create a natural, professional landing page for "Greenscape Landscaping" — a full-service landscaping and lawn care company.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #2E7D32 (lush green)
- Primary Dark: #1B5E20 (deeper green for hover)
- Accent: #8D6E42 (earthy brown)
- Light BG: #F5F9F2 (fresh green tint)
- Dark: #1A2816 (dark forest)
- Dark Surface: #243420
- Light Text: #FFFFFF
- Body Text: #4A5A42 (natural gray-green)
- Muted: #7A8A72
- Sky: #64B5F6 (sky blue accent)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — strong, outdoorsy
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#2E7D32, weight=600
- Body text: size 16-17px, color=#4A5A42, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Service cards: _animation='fadeInUp', stagger 100ms
- Portfolio images: _animation='fadeIn', stagger 150ms
- About image: _animation='fadeInLeft'
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "beautiful landscaped garden home" — hero
2. "landscaping workers professional lawn" — about
3. "garden design patio outdoor" — services
4. "lawn mowing green grass" — lawn care
5. "hardscape patio stone design" — hardscaping
6. "tree trimming arborist" — tree service
7. "flower garden colorful beds" — planting
8. "irrigation sprinkler system lawn" — irrigation

## SVG ICONS
- Leaf icon | Tree icon | Shovel icon | Sun icon | Droplet icon | Shield icon | Clock icon | Phone icon | Map pin icon | Scissors icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded landscaped garden, overlay #1A2816 at 0.5
- Min-height 650px
- Row: Left text + Right "Free Estimate" card
  - Label: "LANDSCAPING · LAWN CARE · DESIGN" — color=#64B5F6, _animation='fadeInDown'
  - Heading: "Transform Your Outdoor Space" — size=48px, _animation='fadeInDown', _animation_delay=200
  - Subtext — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Get Free Estimate" (#2E7D32) | "View Portfolio" (border #8D6E42)
  - Right: "Free Consultation" card with CTA

### 2. TRUST BAR
- Background: #2E7D32
- "15+ Years" | "1,000+ Properties" | "Licensed & Insured" | "Satisfaction Guaranteed"

### 3. SERVICES (2 rows of 3)
- Background: #F5F9F2
- 6 service cards (_animation='fadeInUp', stagger):
  - Lawn Maintenance | Landscape Design | Hardscaping & Patios | Tree & Shrub Care | Irrigation Systems | Seasonal Cleanup

### 4. PORTFOLIO (4 images)
- Background: #FFFFFF
- Heading: "Our Recent Work"
- Row of 4 before/after or project images (_animation='fadeIn', stagger 150ms)

### 5. ABOUT (2-column)
- Background: #F5F9F2
- Image + company story, team, commitment to quality

### 6. PROCESS (4 steps)
- Background: #1A2816
- 1. Consultation → 2. Design → 3. Installation → 4. Maintenance
- Numbered dark cards

### 7. TESTIMONIALS (3 cards)
- Background: #F5F9F2

### 8. SERVICE AREA + LOCATION
- Background: #FFFFFF
- Coverage map, Google Maps

### 9. CTA
- Background: #2E7D32
- Heading: "Ready for a Greener Tomorrow?" — _animation='zoomIn'
- Buttons: "Get Free Estimate" | "Call (555) 012-3456"

### 10. FOOTER — Background: #1A2816

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(46, 125, 50, 0.3); }
::selection { background: #2E7D32; color: #FFFFFF; }
```
### Element-Level CSS — Service Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(26, 40, 22, 0.1); }
```
### Element-Level CSS — Portfolio Images:
```css
selector { overflow: hidden; border-radius: 8px; }
selector img { transition: transform 0.6s ease; }
selector:hover img { transform: scale(1.08); }
```

## FINAL CHECKLIST
- Natural, outdoorsy — greens, earthy browns, sky blue
- Free estimate prominently featured
- Portfolio showcase with project images
- Process timeline
- NO flex_wrap or _flex_size — Publish as draft
