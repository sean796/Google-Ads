Create a sophisticated, authoritative landing page for "Meridian Wealth Partners" — a financial advisory and wealth management firm.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #1A3A5C (deep navy)
- Primary Dark: #122A44 (darker navy for hover)
- Accent: #B8860B (dark gold — wealth)
- Light Gold: #D4A843 (lighter gold)
- Light BG: #F5F3EF (warm parchment)
- Dark: #0F1923 (midnight)
- Dark Surface: #1C2B3C
- Light Text: #FFFFFF
- Body Text: #4A4A4A (neutral charcoal)
- Muted: #7A7A7A
- Card BG: #FFFFFF

### Typography
- Headings: weight 600-700, title case — authoritative, established
- Section subtitles: uppercase, letter-spacing=4px, size=11px, color=#B8860B, weight=600
- Body text: size 16px, color=#4A4A4A, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=300
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=500
- Hero buttons: _animation='fadeInUp', _animation_delay=700
- Section headings: _animation='fadeIn', animation_duration='slow'
- Service cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft', animation_duration='slow'
- About text: _animation='fadeInRight', animation_duration='slow', _animation_delay=200
- Testimonials: _animation='fadeIn', animation_duration='slow', stagger 150ms
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "financial advisor office luxury" — hero
2. "wealth management meeting professional" — about
3. "stock market chart growth" — services
4. "retirement couple happy planning" — retirement planning
5. "business meeting conference professional" — team
6. "modern office skyline city" — credibility
7. "estate planning family legacy" — estate
8. "investment portfolio document" — services

## SVG ICONS
- Chart line up icon (growth)
- Shield icon (protection)
- Compass icon (guidance)
- Building icon (estate)
- Briefcase icon (portfolio)
- Users icon (family planning)
- Star icon (reviews)
- Phone icon (consultation)
- Map pin icon (location)
- Target icon (goals)

## PAGE STRUCTURE

### 1. HERO
- Background: luxury office image, overlay #0F1923 at 0.55
- Min-height 700px
- Centered:
  - Label: "WEALTH MANAGEMENT · SINCE 1998" — color=#B8860B, _animation='fadeIn'
  - Heading: "Building Legacies, Growing Wealth" — color=#FFFFFF, size=50px, weight=600, _animation='fadeIn', _animation_delay=300
  - Subtext about personalized wealth strategies — _animation='fadeIn', _animation_delay=500
  - Buttons: "Schedule Consultation" (#1A3A5C) | "Our Approach" (border #B8860B)

### 2. TRUST BAR
- Background: #1A3A5C
- 4 stats: "25+" years | "$500M+" assets managed | "400+" families served | "Fiduciary" standard

### 3. SERVICES (2 rows of 3)
- Background: #F5F3EF
- Heading: "Comprehensive Wealth Solutions" — _animation='fadeIn'
- 6 cards (_animation='fadeInUp', stagger):
  - Retirement Planning | Investment Management | Tax Strategy | Estate Planning | Risk Management | College Funding
  - White bg, icon, title, description

### 4. ABOUT / APPROACH (2-column)
- Background: #FFFFFF
- Image + philosophy text, fiduciary commitment, personalized approach

### 5. PROCESS (3 steps on dark)
- Background: #0F1923
- Heading: "Our Process" — color=#FFFFFF
- 3 numbered cards (_animation='fadeIn', stagger):
  - 1. Discover — comprehensive assessment
  - 2. Strategize — custom financial plan
  - 3. Execute & Monitor — ongoing management

### 6. TESTIMONIALS (3 cards)
- Background: #F5F3EF
- 3 elegant testimonial cards

### 7. LOCATION
- Background: #FFFFFF
- Address, hours, Google Maps

### 8. CTA
- Background: sideloaded skyline image with overlay
- Heading: "Your Financial Future Starts Here" — _animation='fadeIn'
- Buttons: "Book Consultation" | "Call (555) 456-7890"

### 9. FOOTER
- Background: #0F1923
- 4 columns, divider, copyright

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(26, 58, 92, 0.3); }
::selection { background: #1A3A5C; color: #FFFFFF; }
```

### Element-Level CSS — Service Cards:
```css
selector { transition: transform 0.5s ease, box-shadow 0.5s ease; border: 1px solid #F5F3EF; }
selector:hover { transform: translateY(-6px); box-shadow: 0 15px 40px rgba(0,0,0,0.08); border-color: #B8860B; }
```

## CUSTOM JAVASCRIPT
Counter animation for stats.

## FINAL CHECKLIST
- Sophisticated, established — navy blues, dark golds, warm parchment
- Slow, refined animations — conveying stability
- Trust: fiduciary, years, assets managed
- NO flex_wrap or _flex_size — Publish as draft
