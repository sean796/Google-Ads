EMCP Tools — Premium Prompts, Version 1 (legacy)
================================================

These are the original v1 prompt blueprints, preserved for users who prefer them.
They prescribe an explicit section-by-section Elementor layout.

The current (v2) prompts take a different approach: they give the AI a style guide,
section intents, content facts, and hard standards (WCAG 2.1 AA, real photography,
consistent SVG icons, builder-native construction), and let it design the layout.
The v2 prompts are also builder-agnostic -- change the first line to Gutenberg,
Bricks, or plain HTML/CSS and the same prompt still works.

50 prompts across 10 categories. Paste a file's contents into your MCP-connected
AI client (Claude, Cursor, ...) with EMCP Tools active.

https://emcptools.com
