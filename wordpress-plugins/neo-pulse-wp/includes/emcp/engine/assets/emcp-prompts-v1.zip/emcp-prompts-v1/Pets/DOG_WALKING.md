Create a fun, energetic landing page for "Happy Trails Pet Services" — a dog walking, pet sitting, and pet care business.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #F57C00 (happy orange)
- Primary Dark: #E65100 (deeper orange for hover)
- Accent: #43A047 (grass green)
- Light BG: #FFF8F0 (warm peach tint)
- Dark: #2C1E10 (bark brown)
- Dark Surface: #3E2E1E
- Light Text: #FFFFFF
- Body Text: #5A4A3A (warm brown)
- Muted: #8A7A6A
- Sky: #42A5F5 (sky blue)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700-800, title case — friendly and energetic
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#F57C00, weight=600
- Body text: size 16-17px, color=#5A4A3A, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='bounceIn', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Service cards: _animation='zoomIn', stagger 100ms
- About image: _animation='fadeInLeft'
- Pricing cards: _animation='fadeInUp', stagger 100ms
- Testimonials: _animation='fadeInUp', stagger 100ms
- CTA: _animation='bounceIn'

## IMAGE SOURCING — DO THIS FIRST
1. "dog walking park happy dogs" — hero
2. "dog walker multiple dogs leash" — services
3. "happy dog running field" — about
4. "cat sitting home cozy pet" — pet sitting
5. "dog park playing fetch" — outdoor
6. "pet sitter feeding dog home" — home visits
7. "puppy training walking leash" — training
8. "group dog walk nature trail" — group walks

## SVG ICONS
- Paw print icon | Leash icon | Home icon | Heart icon | Sun icon | Clock icon | Shield icon | Star icon | Phone icon | Map pin icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded dog walking park, overlay #2C1E10 at 0.5
- Min-height 650px, centered:
  - Label: "DOG WALKING · PET SITTING · CARE" — color=#43A047, _animation='fadeInDown'
  - Heading: "Tails Wagging, Adventures Waiting!" — size=48px, weight=800, _animation='bounceIn', _animation_delay=200
  - Subtext — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Book a Walk" (#F57C00) | "See Services" (border #43A047)

### 2. TRUST BAR
- Background: #F57C00
- "500+ Happy Dogs" | "Fully Insured" | "GPS Tracked" | "Photo Updates"

### 3. SERVICES (2 rows of 3)
- Background: #FFF8F0
- 6 service cards (_animation='zoomIn', stagger):
  - Solo Dog Walk ($25) | Group Walk ($18) | Pet Sitting ($50/day) | Puppy Visits ($20) | Cat Care ($30) | Overnight Stay ($65)

### 4. HOW IT WORKS (3 steps)
- Background: #FFFFFF
- 3 numbered cards: 1. Book Online → 2. Meet & Greet → 3. Happy Adventures!

### 5. ABOUT (2-column)
- Background: #FFF8F0
- Image (happy dog) + about the team, certified, bonded, insured, passion for animals

### 6. PRICING PACKAGES (3 cards on dark)
- Background: #2C1E10
- 5 Walk Pack ($110) | 10 Walk Pack ($200 — SAVE 20%) | 20 Walk Pack ($360 — SAVE 28%)

### 7. TESTIMONIALS (3 cards)
- Background: #FFF8F0

### 8. LOCATION / SERVICE AREA
- Background: #FFFFFF
- Coverage map, neighborhoods served, Google Maps

### 9. CTA
- Background: #43A047
- Heading: "Ready for Your Dog's Best Day?" — _animation='bounceIn'
- Buttons: "Book Now" | "Call (555) 789-0123"

### 10. FOOTER — Background: #2C1E10

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px) scale(1.02); box-shadow: 0 8px 25px rgba(245, 124, 0, 0.3); }
::selection { background: #F57C00; color: #FFFFFF; }
```
### Element-Level CSS — Service Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px) rotate(-1deg); box-shadow: 0 20px 50px rgba(44, 30, 16, 0.1); }
```

## FINAL CHECKLIST
- Fun, energetic — oranges, greens, sky blues
- Bouncy animations for hero and CTA
- Service cards with individual pricing
- Multi-walk packages with savings highlighted
- GPS tracking and photo updates as trust signals
- NO flex_wrap or _flex_size — Publish as draft
