Create a professional, reliable landing page for "VoltPro Electric" — a licensed residential and commercial electrician service.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #2563EB (electric blue)
- Primary Dark: #1D4ED8 (darker blue)
- Accent: #FBBF24 (safety yellow/warning)
- Dark: #0F172A (slate-900)
- Light Text: #FFFFFF
- Body Text: #475569 (slate-600)
- Light BG: #F1F5F9 (slate-100)
- Card BG: #FFFFFF
- Border: #CBD5E1

### Typography
- Headings: uppercase, bold (700-800) — strong, dependable
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#FBBF24
- Body text: size 16px, color=#475569, line-height 1.7

## IMAGE SOURCING — DO THIS FIRST
1. "electrician working wiring professional" — hero
2. "electrical panel circuit breaker" — services
3. "electrician residential home" — about
4. "commercial electrical installation" — services
5. "led lighting installation modern" — services
6. "electrical safety inspection" — services
7. "electrician van service vehicle" — about
8. "smart home electrical installation" — services

## SVG ICONS
Clean, technical icons: Lightning bolt, Plug, Lightbulb, Shield/safety, Wrench, Home, Building, Clock/24-7, Phone, Certificate.

## PAGE STRUCTURE

### 1. HERO (2-column: text left, booking form right)
- Background: sideloaded electrician image, background_size='cover'
- Overlay: background_overlay_color='#0F172A', background_overlay_opacity={size:0.75,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Row:
  - Left: "LICENSED & INSURED · 24/7 EMERGENCY" label (#FBBF24), "Expert Electrical Solutions for Home & Business" heading (#FFFFFF, 46px, uppercase), subtext (#CBD5E1), "Call: (555) 456-7890" + "Get Free Quote" buttons
  - Right: Quote form — white bg, "Get a Free Estimate" heading, form (Name, Phone, Email, Service [Electrical Repair, Panel Upgrade, Wiring/Rewiring, Lighting Installation, EV Charger, Generator, Safety Inspection, Emergency], Property Type [Residential, Commercial], "Request Estimate" button — #2563EB bg)

### 2. TRUST BAR
- Background: background_color='#2563EB'
- Row 4: "20+ Years Licensed" | "5,000+ Jobs Done" | "24/7 Emergency" | "100% Satisfaction" — #FFFFFF

### 3. SERVICES (6 cards in 3x2)
- Background: background_color='#F1F5F9'
- "OUR SERVICES" subtitle + heading
- 6 cards: icon, name, description, "Learn More" link
  - Electrical Repair & Troubleshooting | Panel Upgrades & Installation | Residential Wiring & Rewiring | LED Lighting & Smart Home | EV Charger Installation | Generator Installation & Service

### 4. WHY US (2-column)
- Background: background_color='#FFFFFF'
- Left: subtitle, heading, text, icon list: "Licensed Master Electrician" | "Upfront Pricing — No Surprises" | "Same-Day Emergency Service" | "Lifetime Workmanship Warranty"
- Right: Electrician at work image

### 5. PRICING (3 tiers)
- Background: background_color='#F1F5F9'
- Diagnostic Visit ($89) | Standard Repair ($149-$299) | Panel Upgrade (from $1,200)
- Featured: Standard Repair with blue border

### 6. TESTIMONIALS (3 cards)
- Background: background_color='#FFFFFF'
- Stars (#FBBF24), quote, name + "Homeowner" or "Business Owner"

### 7. CTA
- Background: background_color='#0F172A'
- "Electrical Emergency? We're On Our Way." heading (#FFFFFF), "Call Now: (555) 456-7890" button (#FBBF24 bg, #0F172A text)

### 8. SERVICE AREA (2-column)
- Background: background_color='#FFFFFF'
- Left: Address, phone, emergency line, service area list
- Right: Google Maps

### 9. FOOTER
- Background: background_color='#0F172A'
- 4 columns — color=#94A3B8/#FFFFFF
- "License #EC-12345" in footer
- Copyright

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; text-transform: uppercase !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(37, 99, 235, 0.3); }
.elementor-image img { transition: transform 0.5s ease; }
.elementor-image:hover img { transform: scale(1.04); }
.elementor-field-group input:focus, .elementor-field-group select:focus { border-color: #2563EB !important; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15) !important; }
```

### Element-Level — Service Cards:
```css
selector { transition: transform 0.3s ease, box-shadow 0.3s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 15px 40px rgba(37, 99, 235, 0.1); }
```

### Element-Level — Quote Form:
```css
selector { box-shadow: 0 25px 60px rgba(0,0,0,0.25); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-icon-box-wrapper').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(25px)'; el.style.transition = 'opacity 0.6s ease, transform 0.6s ease'; observer.observe(el);
});
// Counter animation
const cObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target; const text = el.textContent.trim(); const match = text.match(/(\d+)/);
      if (match) { const target = parseInt(match[1]); const suffix = text.replace(/\d+/,''); let c=0; const inc=Math.ceil(target/35);
        const t=setInterval(()=>{c+=inc;if(c>=target){c=target;clearInterval(t);}el.textContent=c+suffix;},30);
      } cObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });
document.querySelectorAll('.elementor-heading-title').forEach(el => { if(/^\d/.test(el.textContent.trim())) cObs.observe(el); });
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Professional/trade: blues, yellows, strong uppercase — Quote form in hero — Emergency emphasis — License number in footer — Publish as draft
