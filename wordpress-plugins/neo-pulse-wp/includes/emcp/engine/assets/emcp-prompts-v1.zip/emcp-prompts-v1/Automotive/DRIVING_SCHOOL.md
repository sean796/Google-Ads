Create a friendly, professional landing page for "GreenLight Driving Academy" — a driving school for teens and adults.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #43A047 (traffic green)
- Primary Dark: #2E7D32 (deeper green for hover)
- Accent: #FFB300 (amber/caution yellow)
- Light BG: #F5FAF5 (soft green tint)
- Dark: #1A2A1A (dark green)
- Dark Surface: #243424
- Light Text: #FFFFFF
- Body Text: #4A5A4A (sage gray)
- Muted: #7A8A7A
- Blue: #42A5F5 (sky blue accent)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — friendly, confident
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#43A047, weight=600
- Body text: size 16-17px, color=#4A5A4A, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Program cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- Process steps: _animation='fadeInUp', stagger 100ms
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "driving school student instructor car" — hero
2. "teen driver learning car" — teen program
3. "driving instructor teaching lesson" — about
4. "car dashboard driving practice" — lessons
5. "parallel parking driving test" — skills
6. "happy student passed driving test" — success
7. "defensive driving course" — defensive
8. "driving school car branded" — fleet

## SVG ICONS
- Car icon | Traffic light icon | Shield icon | Star icon | Clock icon | Steering wheel icon | Map icon | Phone icon | Users icon | Check/license icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded driving lesson, overlay #1A2A1A at 0.55
- Min-height 650px
- Row: Left text + Right enrollment card
  - Label: "STATE-LICENSED DRIVING SCHOOL" — color=#FFB300, _animation='fadeInDown'
  - Heading: "Drive with Confidence" — size=48px, _animation='fadeInDown', _animation_delay=200
  - Subtext about certified instructors, modern vehicles, 98% pass rate — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Enroll Now" (#43A047) | "View Programs" (border #FFB300)
  - Right: "$50 Off" first-time student card

### 2. TRUST BAR
- Background: #43A047
- "98% Pass Rate" | "Certified Instructors" | "Modern Fleet" | "5,000+ Graduates"

### 3. PROGRAMS (3 cards)
- Background: #F5FAF5
- Heading: "Our Programs" — _animation='fadeInUp'
- 3 program cards (_animation='fadeInUp', stagger):
  - Teen Driver Course ($399): 30hr classroom + 6hr behind-wheel
  - Adult Driver Course ($299): 6hr behind-wheel + road test prep
  - Defensive Driving ($149): Certificate course, insurance discount
  - Featured card: Teen Driver (most popular)

### 4. HOW IT WORKS (4 steps)
- Background: #FFFFFF
- 1. Enroll Online → 2. Classroom/Online Training → 3. Behind-the-Wheel → 4. Pass Your Test!
- Numbered, colorful step cards

### 5. ABOUT (2-column)
- Background: #F5FAF5
- Image (instructor) + school story, state licensed, patient instructors, dual-control vehicles

### 6. WHAT YOU'LL LEARN (icon boxes on dark)
- Background: #1A2A1A
- Row with 4 skills: Highway Driving | Parallel Parking | Defensive Techniques | Night Driving
- Each with icon, skill name, brief description

### 7. TESTIMONIALS (3 cards)
- Background: #F5FAF5
- Focus on teen/parent quotes

### 8. FAQ Section
- Background: #FFFFFF
- Accordion: "How long is the teen program?" | "Do you provide the car for the test?" | "Is online training available?" | "What areas do you cover?"

### 9. CTA
- Background: #43A047
- Heading: "Ready to Get Behind the Wheel?" — _animation='zoomIn'
- Buttons: "Enroll Today" | "Call (555) 456-7890"

### 10. FOOTER — Background: #1A2A1A

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(67, 160, 71, 0.3); }
::selection { background: #43A047; color: #FFFFFF; }
```
### Element-Level CSS — Program Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(26, 42, 26, 0.1); }
```

## FINAL CHECKLIST
- Friendly, professional — traffic green, amber, sky blue
- 98% pass rate prominently featured
- Clear program pricing and details
- Process steps showing student journey
- FAQ section for common questions
- NO flex_wrap or _flex_size — Publish as draft
