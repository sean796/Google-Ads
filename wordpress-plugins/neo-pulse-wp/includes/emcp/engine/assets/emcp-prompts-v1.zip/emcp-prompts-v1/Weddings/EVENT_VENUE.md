Create an elegant, aspirational landing page for "The Grand Oak Estate" — a premier event venue for weddings, galas, and celebrations.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #8B7355 (warm bronze)
- Primary Dark: #6B5A42 (deeper bronze for hover)
- Accent: #C9A96E (champagne gold)
- Blush: #F0E0D6 (soft blush)
- Light BG: #FAF7F3 (warm linen)
- Dark: #1C1815 (dark walnut)
- Dark Surface: #2C2520
- Light Text: #FFFFFF
- Body Text: #5A524A (warm charcoal)
- Muted: #8A8278
- Sage: #7B8B6B (garden sage)
- Card BG: #FFFFFF

### Typography
- Headings: weight 300-500, elegant serif feel — grand, aspirational
- Section subtitles: uppercase, letter-spacing=5px, size=11px, color=#C9A96E, weight=500
- Body text: size 16px, color=#5A524A, line-height 1.9

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=400
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=600
- Hero buttons: _animation='fadeInUp', _animation_delay=800
- Section headings: _animation='fadeIn', animation_duration='slow'
- Space/venue cards: _animation='fadeIn', animation_duration='slow', stagger 200ms
- Gallery images: _animation='fadeIn', stagger 150ms
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "luxury event venue ballroom elegant" — hero
2. "wedding ceremony outdoor garden" — outdoor
3. "banquet hall decorated table setting" — indoor
4. "wedding reception dance floor" — reception
5. "garden estate grounds beautiful" — grounds
6. "cocktail hour elegant appetizers" — events
7. "bride groom venue staircase" — couple
8. "corporate gala dinner event" — corporate

## SVG ICONS
- Crown icon | Heart icon | Champagne icon | Star icon | Calendar icon | Camera icon | Music note icon | Map pin icon | Phone icon | Users icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded ballroom, overlay #1C1815 at 0.4
- Min-height 700px, centered:
  - Label: "WEDDINGS · GALAS · CELEBRATIONS" — color=#C9A96E, letter-spacing=6px, _animation='fadeIn'
  - Heading: "Your Unforgettable Begins Here" — size=56px, weight=300, _animation='fadeIn', _animation_delay=400
  - Subtext about historic estate, stunning grounds, bespoke events — _animation='fadeIn', _animation_delay=600
  - Buttons: "Schedule a Tour" (#8B7355, text #FFFFFF) | "View Spaces" (border #C9A96E)

### 2. FEATURE STRIP
- Background: #1C1815
- "300 Guest Capacity" | "10-Acre Estate" | "Award-Winning Catering" | "Full-Service Planning"

### 3. EVENT SPACES (3 large cards)
- Background: #FAF7F3
- Heading: "Our Spaces" — weight=300, _animation='fadeIn'
- 3 venue cards (_animation='fadeIn', stagger 200ms):
  - The Grand Ballroom (up to 300 guests, indoor) — Image, description, capacity
  - The Garden Pavilion (up to 200 guests, outdoor/covered) — Image, description
  - The Oak Room (up to 80 guests, intimate) — Image, description, perfect for rehearsals

### 4. EVENTS WE HOST (icon boxes)
- Background: #FFFFFF
- Row with 4 event types: Weddings | Corporate Events | Galas & Fundraisers | Private Parties
- Each with icon, title, brief description

### 5. GALLERY (image showcase)
- Background: #FAF7F3
- Heading: "Moments at The Grand Oak"
- Row of 4 images showcasing different events (_animation='fadeIn', stagger 150ms)

### 6. PACKAGES (3 cards on dark)
- Background: #1C1815
- Heading: "Celebration Packages" — color=#FFFFFF
- 3 cards:
  - Intimate ($5,000 — up to 50 guests): venue, basic decor, 4-hour rental
  - Classic ($12,000 — up to 150 guests): full decor, catering, 8-hour, coordinator
  - Grand ($25,000+ — up to 300 guests): everything, premium bar, live music, photography
  - Featured card border #C9A96E

### 7. TESTIMONIALS (3 cards)
- Background: #FAF7F3

### 8. TOUR CTA (2-column)
- Background: #FFFFFF
- Image (grounds) + "Schedule Your Personal Tour" heading, description, contact form mention
- Button: "Book a Tour" — #8B7355

### 9. LOCATION
- Background: #FAF7F3
- Address, Google Maps

### 10. FOOTER — Background: #1C1815

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 30px rgba(139, 115, 85, 0.3); }
::selection { background: #8B7355; color: #FFFFFF; }
```
### Element-Level CSS — Venue Cards:
```css
selector { transition: transform 0.5s ease, box-shadow 0.5s ease; overflow: hidden; }
selector:hover { transform: translateY(-6px); box-shadow: 0 20px 50px rgba(0,0,0,0.1); }
selector img { transition: transform 0.7s ease; }
selector:hover img { transform: scale(1.05); }
```

## FINAL CHECKLIST
- Elegant, aspirational — bronze, champagne gold, blush, sage
- Slow, graceful animations — wedding-worthy refinement
- Venue spaces with guest capacities
- Tiered packages with pricing
- Tour booking prominently featured
- NO flex_wrap or _flex_size — Publish as draft
