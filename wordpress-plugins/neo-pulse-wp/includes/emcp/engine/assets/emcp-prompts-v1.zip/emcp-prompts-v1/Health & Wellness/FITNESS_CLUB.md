Create a high-energy, bold landing page for "IRONCORE Fitness" — a modern fitness club and gym.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM (use consistently across ALL sections)

### Color Palette
- Primary: #FF3B30 (electric red)
- Primary Dark: #CC2F26 (darker red for hover)
- Accent: #FFD60A (neon yellow)
- Dark: #0D0D0D (pure near-black)
- Dark Surface: #1A1A1A (card background)
- Dark Elevated: #252525 (elevated surfaces)
- Light Text: #FFFFFF
- Body Text: #A0A0A0 (neutral gray)
- Muted: #666666
- Border: #333333

### Typography
- Headings: uppercase, bold/black (800-900 weight), tight letter-spacing — aggressive, powerful
- Section subtitles: uppercase, letter-spacing=4px, size=12px, color=#FF3B30 or #FFD60A, weight=700
- Body text: size 16px, color=#A0A0A0, line-height 1.7
- Numbers/stats: extra bold, large sizes for impact

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required
- For overlays: background_overlay_background='classic', background_overlay_color='#hex', background_overlay_opacity={size:0.7,unit:'px'}

## IMAGE SOURCING — DO THIS FIRST
Before building the page, use the search-images and sideload-image tools:
1. "gym fitness training intense dark" — for hero background
2. "personal trainer coaching gym" — for about/trainers
3. "weightlifting barbell gym dark" — for classes
4. "crossfit functional training group" — for classes
5. "yoga class fitness studio" — for classes
6. "boxing kickboxing gym training" — for classes
7. "modern gym interior equipment" — for facilities
8. "fitness transformation before after" — for results

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Do NOT use Elementor's icon library. Bold, angular icons:
- Dumbbell icon (general fitness)
- Lightning bolt icon (energy/power)
- Flame icon (calories/intensity)
- Clock icon (hours/schedule)
- Trophy icon (achievements)
- Heart pulse icon (cardio)
- Shield icon (guarantee)
- Person running icon (cardio)
- Map pin icon (location)
- Arrow icon (CTAs)

## PAGE STRUCTURE

### 1. HERO SECTION (full-screen with angled overlay)
Full-width container:
- Background: sideloaded gym training image, background_size='cover', background_position='center center'
- Overlay: background_overlay_color='#0D0D0D', background_overlay_opacity={size:0.7,unit:'px'}
- Min-height: {size:700,unit:'px'}
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- **Row container** with 2 children:

  **Left column** (align_items='flex-start'):
  - Small label: "NO LIMITS. NO EXCUSES." — color=#FF3B30, size=14px, uppercase, letter-spacing=3px, weight=700
  - Main heading: "TRANSFORM YOUR BODY. TRANSFORM YOUR LIFE." — color=#FFFFFF, size=50px, weight=900, uppercase
  - Subtext: "State-of-the-art equipment, expert trainers, and 50+ classes weekly. Your fitness journey starts here." — color=#A0A0A0, size=18px
  - Row with buttons:
    - "START FREE TRIAL" — background_color=#FF3B30, text_color=#FFFFFF, border_radius={top:0,right:0,bottom:0,left:0,unit:'px'} (sharp/angular), padding large, uppercase
    - "VIEW CLASSES" — background=transparent, border_color='#FFFFFF', text_color=#FFFFFF, sharp corners

  **Right column**:
  - Inner container styled as a pricing highlight card:
    - background_color='#1A1A1A', border_border='solid', border_width={top:2,right:2,bottom:2,left:2,unit:'px'}, border_color='#FF3B30', padding
    - "LIMITED OFFER" badge — color=#FFD60A, uppercase, small
    - Heading: "$29/mo" — color=#FFFFFF, size=48px, weight=900
    - Text: "First 3 months — normally $59/mo" — color=#A0A0A0
    - List: "Unlimited classes · Full gym access · Personal assessment" — color=#A0A0A0
    - Button: "CLAIM OFFER" — background_color=#FF3B30, text_color=#FFFFFF, full-width

### 2. STATS BAR (impact numbers)
- Background: background_background='classic', background_color='#FF3B30'
- Padding: {top:'25',right:'0',bottom:'25',left:'0',unit:'px'}
- Row container with 4 children:
  - "10,000+" / "ACTIVE MEMBERS" — heading color=#FFFFFF size=32px weight=900, label #FFFFFF size=12px uppercase
  - "50+" / "WEEKLY CLASSES"
  - "25+" / "EXPERT TRAINERS"
  - "15K sqft" / "TRAINING SPACE"

### 3. CLASSES SECTION (6 cards in 3x2 grid)
- Background: background_background='classic', background_color='#0D0D0D'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "OUR CLASSES" — color=#FF3B30, centered, uppercase
- Heading: "FIND YOUR FIRE" — color=#FFFFFF, size=40px, centered, weight=900
- Row 1: 3 class cards
- Row 2: 3 more class cards

  Each class card (column container):
  - Image widget (class photo), full-width, border_radius top
  - Content container: background_color='#1A1A1A', padding
  - Class name: "HIIT REVOLUTION" — color=#FFFFFF, size=18px, weight=800, uppercase
  - Description: "45-min high-intensity interval training..." — color=#A0A0A0, size=14px
  - Row: intensity level tag + duration
    - Intensity pill: "HIGH INTENSITY" — styled as badge with background=#FF3B30, color=#FFFFFF
    - Duration: "45 MIN" — color=#666666

  Classes:
  - Row 1: HIIT Revolution (45 min, High) | Power Lifting (60 min, High) | Yoga Flow (50 min, Low)
  - Row 2: Boxing Basics (45 min, Medium) | CrossFit WOD (60 min, High) | Spin Cycle (40 min, Medium)

### 4. ABOUT / WHY US (2-column)
- Background: background_background='classic', background_color='#1A1A1A'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left (align_items='flex-start'):
    - Subtitle: "WHY IRONCORE" — color=#FF3B30
    - Heading: "MORE THAN A GYM" — color=#FFFFFF, size=36px, weight=900
    - Text: About the philosophy, community, results-driven approach — color=#A0A0A0
    - Icon list with 4 items:
      - "24/7 Access — Train on your schedule"
      - "Personal Training — 1-on-1 coaching included"
      - "Nutrition Guidance — Custom meal plans"
      - "Community Events — Monthly challenges & socials"
      Each with SVG icon, text color=#A0A0A0
  - Right: Image widget (gym interior), border_radius

### 5. PRICING SECTION (3 cards)
- Background: background_background='classic', background_color='#0D0D0D'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "MEMBERSHIP PLANS" — color=#FF3B30, centered
- Heading: "CHOOSE YOUR PLAN" — color=#FFFFFF, centered, weight=900
- Row with 3 cards:

  Each card: background_color='#1A1A1A', border_border='solid', border_color='#333333', padding={top:40,right:30,bottom:40,left:30,unit:'px'}
  - Plan name: "STARTER" — color=#A0A0A0, uppercase, letter-spacing
  - Price: "$39" — color=#FFFFFF, size=48px, weight=900
  - "/month" — color=#666666
  - Feature list with icon-list: gym access, classes, etc. — color=#A0A0A0
  - Button: "JOIN NOW" — background_color=#FF3B30, text_color=#FFFFFF, sharp corners

  Plans:
  - Starter ($39/mo): Gym access, 5 classes/week, Locker room — border_color='#333333'
  - Pro ($59/mo — FEATURED): Unlimited everything, personal trainer session, nutrition plan — border_color='#FF3B30', scale(1.03)
  - Elite ($99/mo): Everything in Pro + unlimited PT, recovery suite, priority booking — border_color='#333333'

### 6. TRAINERS SECTION (4 trainer cards)
- Background: background_background='classic', background_color='#1A1A1A'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle + heading centered
- Row with 4 children:
  - Each: image widget (trainer photo — reuse gym/training images), name heading (#FFFFFF), specialty text (#FF3B30, small), bio text (#A0A0A0)
  - Trainers: "Marcus Steel — Strength & Conditioning" | "Jade Park — Yoga & Mobility" | "Rico Diaz — Boxing & MMA" | "Sam Torres — HIIT & CrossFit"

### 7. CTA SECTION (full-width intense)
- Background: background_background='classic', background_color='#FF3B30'
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered:
  - Heading: "YOUR FIRST CLASS IS FREE" — color=#FFFFFF, size=44px, weight=900
  - Subtext: "No commitment. No credit card. Just show up and sweat." — color=#FFFFFF
  - Button: "BOOK FREE CLASS NOW" — background_color=#FFFFFF, text_color=#FF3B30, sharp corners, large

### 8. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#0D0D0D'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle + heading centered
- Row with 3 cards:
  - Each: background_color='#1A1A1A', border_color='#333333', padding, border_radius={top:0,right:0,bottom:0,left:0,unit:'px'} (sharp)
  - Star rating (color=#FFD60A)
  - Quote — color=#A0A0A0, italic
  - Name (#FFFFFF, bold) + transformation note (#666666)

### 9. SCHEDULE / HOURS (simple)
- Background: background_background='classic', background_color='#1A1A1A'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row container:
  - Left: Heading "HOURS & LOCATION" color=#FFFFFF + address, phone — color=#A0A0A0
  - Center: Hours table — "Mon-Fri: 5AM-11PM | Sat-Sun: 6AM-10PM | Holidays: 8AM-6PM" — color=#A0A0A0
  - Right: Google Maps widget

### 10. FOOTER
- Background: background_background='classic', background_color='#0D0D0D'
- Border top: border_color='#333333'
- Padding: {top:'50',right:'0',bottom:'50',left:'0',unit:'px'}
- Row with 4 columns:
  - Col 1: "IRONCORE" heading + tagline — color=#A0A0A0 / #FFFFFF
  - Col 2: "Quick Links" — color=#A0A0A0
  - Col 3: "Classes" — color=#A0A0A0
  - Col 4: "Contact" — color=#A0A0A0
- Divider (color=#333333)
- Copyright: "© 2026 IRONCORE Fitness. All rights reserved." — color=#666666

## CUSTOM CSS — APPLY AFTER PAGE IS BUILT

### Page-Level CSS (no element_id):
```css
html { scroll-behavior: smooth; }

/* Aggressive button hover */
.elementor-button {
  transition: all 0.25s ease !important;
  text-transform: uppercase !important;
  letter-spacing: 2px !important;
}
.elementor-button:hover {
  transform: translateY(-3px) scale(1.02);
  box-shadow: 0 10px 30px rgba(255, 59, 48, 0.4);
}

/* Image hover zoom */
.elementor-image img {
  transition: transform 0.5s ease;
}
.elementor-image:hover img {
  transform: scale(1.05);
}

/* Red glow for headings on dark */
.elementor-widget-heading .elementor-heading-title {
  text-shadow: none;
  transition: text-shadow 0.3s ease;
}
```

### Element-Level CSS — Class Cards:
```css
selector {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  overflow: hidden;
}
selector:hover {
  transform: translateY(-10px);
  box-shadow: 0 20px 50px rgba(255, 59, 48, 0.15);
}
selector:hover img {
  transform: scale(1.08);
}
```

### Element-Level CSS — Pricing Featured Card (Pro plan):
```css
selector {
  border-color: #FF3B30 !important;
  transform: scale(1.03);
  box-shadow: 0 15px 50px rgba(255, 59, 48, 0.2);
}
selector:hover {
  transform: scale(1.06);
  box-shadow: 0 25px 60px rgba(255, 59, 48, 0.3);
}
```

### Element-Level CSS — Hero Pricing Card:
```css
selector {
  box-shadow: 0 20px 60px rgba(0,0,0,0.5);
  transition: transform 0.3s ease;
}
selector:hover {
  transform: scale(1.02);
}
```

### Element-Level CSS — Trainer Cards:
```css
selector {
  transition: transform 0.3s ease;
}
selector:hover {
  transform: translateY(-5px);
}
selector:hover img {
  filter: brightness(1.1);
}
```

## CUSTOM JAVASCRIPT — APPLY AFTER PAGE IS BUILT
Use `add-custom-js` with wrap_dom_ready=true.

### Scroll Animations + Counters (add-custom-js, wrap_dom_ready=true):
```javascript
// Aggressive fade-in on scroll
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0) scale(1)';
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-icon-box-wrapper, .elementor-widget-text-editor').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(35px) scale(0.98)';
  el.style.transition = 'opacity 0.6s ease, transform 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
  observer.observe(el);
});

// Counter animation with easing
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(/\d+/, '');
        let current = 0;
        const duration = 1500;
        const startTime = performance.now();
        function animate(currentTime) {
          const elapsed = currentTime - startTime;
          const progress = Math.min(elapsed / duration, 1);
          const eased = 1 - Math.pow(1 - progress, 3);
          current = Math.round(target * eased);
          el.textContent = current + suffix;
          if (progress < 1) requestAnimationFrame(animate);
        }
        requestAnimationFrame(animate);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim()) || /\d+K/.test(el.textContent.trim())) {
    counterObs.observe(el);
  }
});

// Pulsing CTA section
const ctaSection = document.querySelectorAll('.elementor-element[data-element_type="container"]');
ctaSection.forEach(section => {
  const bg = getComputedStyle(section).backgroundColor;
  if (bg.includes('255, 59, 48') || bg.includes('ff3b30')) {
    section.style.animation = 'subtlePulse 3s ease-in-out infinite';
  }
});

const style = document.createElement('style');
style.textContent = `
  @keyframes subtlePulse {
    0%, 100% { box-shadow: inset 0 0 0 rgba(255,214,10,0); }
    50% { box-shadow: inset 0 0 100px rgba(255,214,10,0.05); }
  }
`;
document.head.appendChild(style);
```

## SITE-WIDE CODE SNIPPET (Optional — Pro only)
- Title: "IRONCORE - Global Styles"
- Location: head
- Priority: 1
- Code:
```html
<style>
  html { scroll-behavior: smooth; }
  body { -webkit-font-smoothing: antialiased; }
  ::selection { background: #FF3B30; color: #FFFFFF; }
</style>
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** using build-page
4. **Apply page-level CSS** (no element_id)
5. **Apply element-level CSS** for: class cards, pricing featured, hero pricing card, trainer cards
6. **Inject custom JS** with wrap_dom_ready=true
7. **Create site-wide snippet** (optional, Pro only)

## FINAL CHECKLIST
- Every container with a background color MUST have both background_background='classic' AND background_color set
- All text colors explicitly set
- NO flex_wrap or _flex_size anywhere
- All images real sideloaded images
- Use SVG icons, not Elementor icon library
- Dark, high-energy theme — blacks, reds, yellows
- Sharp corners on buttons (no border-radius = aggressive feel)
- Class cards with image, intensity badge, and duration
- 3-tier pricing with featured card highlighted in red
- Hero has pricing offer card on the right
- Publish the page as draft
