Create a sleek, minimalist landing page for "Kaze Sushi" — a modern Japanese sushi bar and omakase restaurant.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #C41E3A (deep crimson/sake red)
- Primary Dark: #9B1730 (darker red for hover)
- Accent: #D4AF37 (gold/wasabi accent)
- Cream: #FAF7F2 (warm rice white)
- Dark: #1A1A1A (sumi ink black)
- Dark Surface: #2A2A2A (dark slate)
- Light Text: #FFFFFF
- Body Text: #5A5A5A (neutral gray)
- Muted: #8A8A8A
- Sage: #7B8B6F (wasabi/bamboo green)
- Card BG: #FFFFFF

### Typography
- Headings: weight 300-600, elegant and minimal — Japanese-inspired refinement
- Section subtitles: uppercase, letter-spacing=5px, size=11px, color=#C41E3A, weight=500
- Body text: size 16px, color=#5A5A5A, line-height 1.9

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required
- For overlays: background_overlay_background='classic', background_overlay_color='#hex', background_overlay_opacity={size:0.55,unit:'px'}

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=300
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=500
- Hero buttons: _animation='fadeInUp', animation_duration='', _animation_delay=700
- Section headings: _animation='fadeIn', animation_duration='slow', _animation_delay=0
- Menu cards: _animation='fadeIn', animation_duration='slow', _animation_delay staggered by 150ms
- About image: _animation='fadeInLeft', animation_duration='slow', _animation_delay=0
- About text: _animation='fadeInRight', animation_duration='slow', _animation_delay=200
- Testimonials: _animation='fadeIn', animation_duration='slow', stagger 150ms
- CTA: _animation='fadeIn', animation_duration='slow', _animation_delay=0

## IMAGE SOURCING — DO THIS FIRST
1. "sushi chef preparing fish japanese" — hero background
2. "sushi platter assorted nigiri" — menu section
3. "sashimi fresh fish close up" — menu
4. "japanese restaurant interior minimal" — atmosphere
5. "maki roll sushi beautiful plating" — menu
6. "sake pouring traditional japanese" — drinks
7. "ramen bowl japanese noodle" — hot dishes
8. "japanese zen garden bamboo" — ambiance

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Clean, minimal line icons:
- Chopsticks icon (dining)
- Fish icon (sushi/sashimi)
- Sake cup icon (drinks)
- Leaf/bamboo icon (fresh)
- Star icon (reviews)
- Clock icon (hours)
- Map pin icon (location)
- Phone icon (reservations)
- Flame icon (kitchen)
- Wave icon (ocean fresh)

## PAGE STRUCTURE

### 1. HERO SECTION
Full-width container:
- Background: sideloaded sushi chef image, background_size='cover', background_position='center center'
- Overlay: background_overlay_color='#1A1A1A', background_overlay_opacity={size:0.55,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Padding: {top:'120',right:'0',bottom:'120',left:'0',unit:'px'}
- Centered content:
  - Small label: "OMAKASE · SUSHI · SAKE" — color=#D4AF37, size=12px, uppercase, letter-spacing=6px, weight=500, _animation='fadeIn', _animation_delay=0
  - Main heading: "The Art of Sushi" — color=#FFFFFF, size=56px, weight=300, _animation='fadeIn', _animation_delay=300
  - Subtext: "Experience the precision and elegance of traditional Japanese cuisine — each piece crafted by master hands with the freshest seasonal ingredients." — color=#FAF7F2, size=17px, _animation='fadeIn', _animation_delay=500
  - Row with buttons (_animation='fadeInUp', _animation_delay=700):
    - "Reserve a Seat" — background_color=#C41E3A, text_color=#FFFFFF, border_radius={top:2,right:2,bottom:2,left:2,unit:'px'}
    - "View Menu" — background=transparent, border_color='#D4AF37', text_color=#D4AF37

### 2. FEATURE STRIP
- Background: background_background='classic', background_color='#1A1A1A'
- Padding: {top:'30',right:'0',bottom:'30',left:'0',unit:'px'}
- Row with 3 children:
  - "Daily Fish Market Sourced" | "Omakase from $85" | "Sake Bar · 40+ Labels"
  - Icon color=#D4AF37, text color=#FFFFFF, size=13px

### 3. MENU HIGHLIGHTS (2 rows of 3)
- Background: background_background='classic', background_color='#FAF7F2'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "THE MENU" — color=#C41E3A, centered
- Heading: "Signature Selections" — color=#1A1A1A, centered, weight=400, size=38px, _animation='fadeIn'
- Row 1: 3 cards (_animation='fadeIn', stagger by 150ms)
- Row 2: 3 cards

  Each card (column container):
  - Image widget, border_radius={top:4,right:4,bottom:4,left:4,unit:'px'}
  - Content: padding, text-align center
  - Item name: "Omakase Experience" — color=#1A1A1A, size=18px, weight=600
  - Description: elegant 1-line — color=#5A5A5A, size=14px
  - Price: "$85" — color=#C41E3A, size=20px, weight=500

  Items:
  - Row 1: Omakase 12-piece ($85) | Chef's Sashimi Platter ($42) | Dragon Roll ($22)
  - Row 2: Wagyu Nigiri ($28) | Sake Flight ($35) | Matcha Crème Brûlée ($14)

### 4. ABOUT / PHILOSOPHY (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left: Image (zen/restaurant interior), _animation='fadeInLeft'
  - Right:
    - Subtitle: "OUR PHILOSOPHY" — color=#C41E3A, _animation='fadeInRight'
    - Heading: "Simplicity. Precision. Respect." — color=#1A1A1A, weight=400, size=34px, _animation='fadeInRight', _animation_delay=100
    - Text: Philosophy of letting ingredients speak, seasonal sourcing (shun), the omakase tradition — color=#5A5A5A, _animation='fadeInRight', _animation_delay=200
    - Stats row (_animation='fadeInUp', _animation_delay=300):
      - "15+" / "Years Mastery" | "Daily" / "Fish Market" | "40+" / "Sake Labels"

### 5. OMAKASE EXPERIENCE (full-width dark section)
- Background: background_background='classic', background_color='#1A1A1A'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Centered:
  - Subtitle: "THE EXPERIENCE" — color=#D4AF37, _animation='fadeIn'
  - Heading: "Omakase — Trust the Chef" — color=#FFFFFF, weight=300, size=38px, _animation='fadeIn', _animation_delay=200
  - Text description of the omakase journey — color=#8A8A8A, max-width feel, _animation='fadeIn', _animation_delay=300
- Row with 3 step cards (_animation='fadeIn', stagger 150ms):
  - Each: background_color='#2A2A2A', padding, border_radius, centered
  - Step number: "01" — color=#D4AF37, size=32px, weight=300
  - Title: "Seasonal Appetizer" — color=#FFFFFF, size=16px
  - Description — color=#8A8A8A, size=14px
  - Steps: Seasonal Appetizer → 12 Nigiri Courses → Chef's Dessert

### 6. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#FAF7F2'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle + heading centered
- Row with 3 cards (_animation='fadeIn', stagger 150ms):
  - White bg, subtle border, padding, minimal border_radius
  - Star rating (color=#D4AF37)
  - Quote — color=#5A5A5A, italic
  - Name + "via Yelp" — color=#1A1A1A / #8A8A8A

### 7. LOCATION (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left (_animation='fadeInLeft'):
    - Subtitle: "VISIT" — color=#C41E3A
    - Heading: "Find Kaze Sushi" — color=#1A1A1A, weight=400
    - Address, phone — color=#5A5A5A
    - Hours: "Tue-Sun: 5PM-11PM | Mon: Closed | Omakase: Reservation Only"
    - Note: "Counter seating limited to 12 guests" — color=#8A8A8A, italic
  - Right: Google Maps widget, _animation='fadeInRight'

### 8. CTA SECTION
- Background: background_background='classic', background_color='#1A1A1A'
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered:
  - Heading: "Reserve Your Experience" — color=#FFFFFF, size=40px, weight=300, _animation='fadeIn'
  - Subtext: "Counter seats fill quickly. Book your omakase experience or table today." — color=#8A8A8A, _animation='fadeIn', _animation_delay=200
  - Row with buttons (_animation='fadeInUp', _animation_delay=400):
    - "Book Omakase" — background_color=#C41E3A, text_color=#FFFFFF
    - "Call to Reserve" — border_color='#D4AF37', text_color=#D4AF37

### 9. FOOTER
- Background: background_background='classic', background_color='#111111'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row with 4 columns (_animation='fadeIn', stagger):
  - Col 1: "Kaze" heading + tagline
  - Col 2: "Menu" — color=#8A8A8A
  - Col 3: "Experience" — color=#8A8A8A
  - Col 4: "Contact" — color=#8A8A8A
- Divider (color=#2A2A2A)
- Copyright — color=#5A5A5A

## CUSTOM CSS — APPLY AFTER PAGE IS BUILT (minimal)

### Page-Level CSS (no element_id):
```css
html { scroll-behavior: smooth; }

.elementor-button {
  transition: all 0.4s ease !important;
}
.elementor-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(196, 30, 58, 0.25);
}

::selection {
  background: #C41E3A;
  color: #FFFFFF;
}
```

### Element-Level CSS — Menu Cards:
```css
selector {
  transition: transform 0.5s ease, box-shadow 0.5s ease;
}
selector:hover {
  transform: translateY(-6px);
  box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
}
```

### Element-Level CSS — Omakase Step Cards:
```css
selector {
  transition: border-color 0.4s ease;
  border: 1px solid transparent;
}
selector:hover {
  border-color: #D4AF37;
}
```

## CUSTOM JAVASCRIPT — APPLY AFTER PAGE IS BUILT
Use `add-custom-js` with wrap_dom_ready=true.

```javascript
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 40);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 40);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** with _animation settings
4. **Apply page-level CSS**
5. **Apply element-level CSS** for menu cards, omakase cards
6. **Inject custom JS**

## FINAL CHECKLIST
- Every container with a background color MUST have both background_background='classic' AND background_color set
- All text colors explicitly set
- NO flex_wrap or _flex_size anywhere
- Entrance animations: slow, elegant fadeIn for the refined Japanese aesthetic
- Minimal custom CSS — leverage built-in animations
- Clean, refined, minimal design — whites, blacks, crimson, gold
- Publish the page as draft
