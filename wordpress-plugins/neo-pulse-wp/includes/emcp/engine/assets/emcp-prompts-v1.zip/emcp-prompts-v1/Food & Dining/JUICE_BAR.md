Create a vibrant, energetic landing page for "PureBlend" — a modern juice and smoothie bar.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #2ECC71 (fresh green)
- Primary Dark: #27AE60 (deeper green for hover)
- Accent: #FF6B35 (tangerine orange)
- Yellow: #F1C40F (citrus yellow)
- Light BG: #F0FFF4 (mint tint)
- Dark: #1A2E1A (deep forest)
- Dark Surface: #2D4A2D
- Light Text: #FFFFFF
- Body Text: #4A5A4A (sage text)
- Muted: #7A8A7A
- Pink: #E91E8C (berry accent)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700-800, title case, energetic and fresh
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#2ECC71, weight=600
- Body text: size 16-17px, color=#4A5A4A, line-height 1.8

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp', _animation_delay=0
- Menu cards: _animation='zoomIn', _animation_delay staggered by 100ms
- About image: _animation='fadeInLeft'
- About text: _animation='fadeInRight', _animation_delay=200
- Testimonials: _animation='fadeInUp', stagger 100ms
- Benefits icons: _animation='bounceIn', stagger by 150ms
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "smoothie colorful healthy drinks fruit" — hero background
2. "green juice fresh ingredients kale" — menu item
3. "acai bowl berry toppings" — menu
4. "juice bar interior modern bright" — atmosphere
5. "fresh fruit assortment colorful" — ingredients
6. "protein smoothie fitness gym" — energy line
7. "detox juice cleanse bottles" — cleanse packages
8. "tropical smoothie mango pineapple" — menu

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Playful, rounded line icons:
- Blender icon (smoothies)
- Leaf icon (natural)
- Fruit icon (ingredients)
- Lightning bolt icon (energy)
- Heart icon (health)
- Droplet icon (juice)
- Clock icon (hours)
- Star icon (reviews)
- Truck icon (delivery)
- Sun icon (vitality)

## PAGE STRUCTURE

### 1. HERO SECTION
Full-width container:
- Background: sideloaded colorful smoothies image, background_size='cover'
- Overlay: background_overlay_color='#1A2E1A', background_overlay_opacity={size:0.6,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Centered content:
  - Small label: "100% NATURAL · COLD-PRESSED · FRESH DAILY" — color=#2ECC71, size=13px, letter-spacing=4px, _animation='fadeInDown'
  - Main heading: "Fuel Your Day the Fresh Way" — color=#FFFFFF, size=52px, weight=700, _animation='fadeInDown', _animation_delay=200
  - Subtext: "Cold-pressed juices, superfood smoothies, and açaí bowls made from 100% organic ingredients. No sugar added, just pure goodness." — color=#F0FFF4, size=18px, _animation='fadeInUp', _animation_delay=400
  - Row with buttons (_animation='fadeInUp', _animation_delay=600):
    - "Order Now" — background_color=#2ECC71, text_color=#FFFFFF, border_radius={top:30,right:30,bottom:30,left:30,unit:'px'}
    - "See Menu" — border_color='#F1C40F', text_color=#F1C40F, border_radius rounded
  - Small text: "Pickup in 5 min · Free delivery over $25" — color=#F0FFF4, size=14px

### 2. BENEFITS BAR (4 icons)
- Background: background_background='classic', background_color='#2ECC71'
- Padding: {top:'30',right:'0',bottom:'30',left:'0',unit:'px'}
- Row with 4 children (_animation='bounceIn', stagger 150ms):
  - "100% Organic" | "Cold-Pressed" | "No Sugar Added" | "Fresh Daily"
  - Icon + text, color=#FFFFFF

### 3. MENU — SMOOTHIES & JUICES (2 rows of 3)
- Background: background_background='classic', background_color='#F0FFF4'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "THE MENU" — color=#2ECC71, centered
- Heading: "Our Best Blends" — color=#1A2E1A, centered, _animation='fadeInUp'
- Row 1: 3 cards (_animation='zoomIn', stagger 100ms)
- Row 2: 3 cards

  Each card (column container):
  - Image widget, border_radius={top:16,right:16,bottom:16,left:16,unit:'px'}
  - Content: padding, centered
  - Drink name: "Green Machine" — color=#1A2E1A, size=18px, weight=700
  - Ingredients: "Kale, spinach, apple, ginger, lemon" — color=#4A5A4A, size=14px
  - Row: Price + calorie tag
    - "$9.50" — color=#2ECC71, size=22px, weight=700
    - "180 cal" — color=#7A8A7A, size=12px

  Items:
  - Row 1: Green Machine ($9.50) | Tropical Sunrise ($10) | Berry Blast ($9)
  - Row 2: Protein Power ($11) | Detox Glow ($9.50) | Açaí Supreme Bowl ($13)

### 4. ABOUT (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left: Image (fresh fruit), border_radius, _animation='fadeInLeft'
  - Right:
    - Subtitle: "WHY PUREBLEND" — color=#2ECC71, _animation='fadeInRight'
    - Heading: "Real Ingredients. Real Energy." — color=#1A2E1A, size=36px, _animation='fadeInRight', _animation_delay=100
    - Text: Story about using only organic, locally sourced produce, no preservatives, cold-pressed to retain nutrients — color=#4A5A4A, _animation='fadeInRight', _animation_delay=200
    - Icon list: "Organic certified" | "Cold-pressed daily" | "Zero preservatives" | "Locally sourced produce"

### 5. CLEANSE PACKAGES (3 cards on dark)
- Background: background_background='classic', background_color='#1A2E1A'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "JUICE CLEANSES" — color=#F1C40F, centered
- Heading: "Reset & Recharge" — color=#FFFFFF, centered, _animation='fadeInUp'
- Row with 3 cards (_animation='fadeInUp', stagger 100ms):
  - Each: background_color='#2D4A2D', padding, border_radius
  - Package name: "1-Day Reset" — color=#FFFFFF, size=20px
  - Description — color=#7A8A7A, size=14px
  - Price: "$49" — color=#2ECC71, size=36px, weight=800
  - Feature list — color=#7A8A7A
  - Button: "Order Cleanse" — background_color=#2ECC71, text_color=#FFFFFF

  Packages:
  - 1-Day Reset ($49): 6 juices, starter guide
  - 3-Day Detox ($129): 18 juices, meal plan, support
  - 5-Day Transform ($199 — FEATURED): 30 juices, full guide, follow-up — border accent #2ECC71

### 6. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#F0FFF4'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row with 3 cards (_animation='fadeInUp', stagger 100ms):
  - White bg, border, padding, rounded
  - Star rating (color=#F1C40F)
  - Quote — color=#4A5A4A
  - Name + source

### 7. LOCATION
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left (_animation='fadeInLeft'): Address, hours, phone
  - Right: Google Maps, _animation='fadeInRight'

### 8. CTA
- Background: background_background='classic', background_color='#2ECC71'
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered:
  - Heading: "Blend It Your Way" — color=#FFFFFF, size=42px, _animation='zoomIn'
  - Subtext: "Build your own smoothie or grab a classic. Order for pickup or delivery." — color=#FFFFFF, _animation='fadeInUp', _animation_delay=200
  - Button: "Order Now" — background_color=#FFFFFF, text_color=#2ECC71, border_radius rounded, _animation='fadeInUp', _animation_delay=400

### 9. FOOTER
- Background: background_background='classic', background_color='#1A2E1A'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row with 4 columns (_animation='fadeInUp', stagger)
- Divider + copyright

## CUSTOM CSS (minimal)

### Page-Level CSS:
```css
html { scroll-behavior: smooth; }

.elementor-button {
  transition: all 0.3s ease !important;
}
.elementor-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(46, 204, 113, 0.3);
}

::selection {
  background: #2ECC71;
  color: #FFFFFF;
}
```

### Element-Level CSS — Menu Cards:
```css
selector {
  transition: transform 0.4s ease, box-shadow 0.4s ease;
}
selector:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 50px rgba(26, 46, 26, 0.1);
}
```

## CUSTOM JAVASCRIPT
Use `add-custom-js` with wrap_dom_ready=true.

```javascript
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 35);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 35);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** with _animation settings
4. **Apply page-level CSS**
5. **Apply element-level CSS** for menu cards
6. **Inject custom JS**

## FINAL CHECKLIST
- Entrance animations: bounceIn for benefits bar, zoomIn for menu cards, fadeIn for text
- Fresh, vibrant palette — greens, oranges, yellows
- Rounded corners throughout (border_radius 16-30px)
- NO flex_wrap or _flex_size
- Publish the page as draft
