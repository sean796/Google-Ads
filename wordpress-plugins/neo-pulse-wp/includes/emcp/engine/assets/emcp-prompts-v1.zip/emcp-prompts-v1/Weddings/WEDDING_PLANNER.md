Create a romantic, elegant landing page for "Ever After Events" — a luxury wedding planning and coordination company.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #3D3229 (warm espresso)
- Accent: #C9A87C (soft gold)
- Accent Light: #E8D5BB (champagne)
- Blush: #E8C4C4 (dusty rose/blush pink)
- Sage: #9CAF88 (muted sage green)
- Dark: #1A1614 (deep warm black)
- Light Text: #FFFFFF
- Body Text: #6B6560 (warm gray)
- Light BG: #FBF8F4 (warm ivory)
- Card BG: #FFFFFF
- Border: #E8E0D5

### Typography
- Headings: weight 300-400 (light, romantic, editorial), title case, optional italic for emphasis
- Section subtitles: uppercase, letter-spacing=5px, size=11px, color=#C9A87C
- Body text: size 16px, color=#6B6560, line-height 1.9

## IMAGE SOURCING — DO THIS FIRST
1. "elegant wedding reception table decoration" — hero
2. "bride and groom ceremony outdoor" — about
3. "wedding flower arrangement elegant" — services
4. "wedding venue ballroom luxury" — venues
5. "wedding cake elegant white gold" — gallery
6. "wedding planner working bride" — about
7. "rustic outdoor wedding ceremony" — gallery
8. "wedding reception string lights evening" — CTA

## SVG ICONS
Delicate, romantic icons: Ring/diamond, Heart, Flower, Champagne glass, Calendar, Envelope, Music note, Camera, Star, Ribbon/bow.

## PAGE STRUCTURE

### 1. HERO (full-screen romantic)
- Background: sideloaded reception image, background_size='cover'
- Overlay: background_overlay_color='#1A1614', background_overlay_opacity={size:0.45,unit:'px'}
- Min-height: {size:700,unit:'px'}
- Centered:
  - "LUXURY WEDDING PLANNING" — color=#C9A87C, letter-spacing=5px
  - "Your Dream Wedding, Perfectly Planned" — color=#FFFFFF, size=54px, weight=300, italic option
  - "From intimate elopements to grand celebrations — Ever After Events creates weddings as unique as your love story." — color=#E8D5BB
  - "Start Planning" + "View Portfolio" buttons — gold bg + ivory border

### 2. SERVICES (3 cards)
- Background: background_color='#FBF8F4'
- "OUR SERVICES" subtitle + "Tailored to Your Vision" heading
- Row 3:
  - Full Planning & Design (from $8,000): concept to execution, vendor management, timeline
  - Partial Planning (from $4,500): vendor recommendations, design direction, month-of coordination
  - Day-of Coordination (from $2,500): rehearsal management, timeline execution, vendor liaison
- Each: icon, name, starting price (#C9A87C), description, "Learn More" link

### 3. ABOUT (2-column: image left, text right)
- Background: background_color='#FFFFFF'
- Left: Planner with bride image, Right: "ABOUT US" subtitle, "Where Love Stories Come to Life" heading (weight=300), story, "250+ Weddings Planned" | "12 Years Experience" | "Featured in Vogue"

### 4. PORTFOLIO GALLERY (3x2)
- Background: background_color='#FBF8F4'
- "PORTFOLIO" subtitle + "Love in Every Detail" heading
- 6 images: ceremonies, receptions, details, cakes

### 5. PROCESS (4 steps)
- Background: background_color='#FFFFFF'
- "HOW IT WORKS" subtitle + heading
- Row 4 children: step number (1-4), title, description
  - 1. "Discovery Call" | 2. "Design & Planning" | 3. "Vendor Curation" | 4. "Your Perfect Day"

### 6. TESTIMONIALS (3 cards)
- Background: background_color='#FBF8F4'
- Large quotation mark (#C9A87C), quote (italic, #6B6560), couple name + venue/date

### 7. FEATURED IN (logos ribbon)
- Background: background_color='#FFFFFF'
- "AS SEEN IN" subtitle centered
- Row of publication names: "Vogue Weddings · Martha Stewart · The Knot · Brides Magazine"

### 8. CTA
- Background: sideloaded string lights image, overlay
- "Let's Create Something Beautiful" heading (#FFFFFF, weight=300), "Schedule Your Complimentary Consultation" button (#C9A87C bg)

### 9. INQUIRY FORM (2-column)
- Background: background_color='#FBF8F4'
- Left: "GET IN TOUCH" subtitle, heading, phone, email, Instagram handle
- Right: Form — Names, Email, Phone, Wedding Date, Venue (if known), Guest Count [Under 50, 50-100, 100-200, 200+], Service Interest, "How did you hear about us?", "Send Inquiry" button

### 10. FOOTER
- Background: background_color='#1A1614'
- 4 columns — color=#8B8580/#FFFFFF
- Social: Instagram, Pinterest — important for wedding planners
- Copyright

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; letter-spacing: 2px !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(201, 168, 124, 0.25); }
.elementor-image img { transition: transform 0.7s cubic-bezier(0.25, 0.46, 0.45, 0.94); }
.elementor-image:hover img { transform: scale(1.04); }
::selection { background: #C9A87C; color: #FFFFFF; }
```

### Element-Level — Service Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-6px); box-shadow: 0 20px 50px rgba(0,0,0,0.06); }
```

### Element-Level — Gallery Images:
```css
selector { overflow: hidden; }
selector img { transition: transform 0.7s ease; }
selector:hover img { transform: scale(1.06); }
```

### Element-Level — Process Steps:
```css
selector { transition: transform 0.3s ease; }
selector:hover { transform: translateY(-4px); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.08, rootMargin: '0px 0px -60px 0px' });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-widget-text-editor, .elementor-icon-box-wrapper').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(25px)'; el.style.transition = 'opacity 0.9s ease, transform 0.9s ease'; observer.observe(el);
});
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Romantic/luxury: golds, blush, sage, light weights, editorial feel — Service tiers with starting prices — Portfolio gallery — Process timeline — Inquiry form with wedding-specific fields — Publish as draft
