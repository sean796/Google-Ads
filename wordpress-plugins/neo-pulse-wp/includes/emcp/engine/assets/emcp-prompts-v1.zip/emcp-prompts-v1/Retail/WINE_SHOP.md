Create a sophisticated, elegant landing page for "Vino & Vine" — a curated wine shop and tasting room.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #722F37 (burgundy/wine red)
- Primary Dark: #5A252C (deeper burgundy for hover)
- Accent: #C9A96E (champagne gold)
- Cream: #FAF5EF (warm parchment)
- Dark: #1A1216 (wine-dark)
- Dark Surface: #2C2024
- Light Text: #FFFFFF
- Body Text: #5A4E48 (warm charcoal)
- Muted: #8A7E78
- Olive: #6B7B5A (vineyard green)
- Card BG: #FFFFFF

### Typography
- Headings: weight 400-600, elegant — refined, sommelier feel
- Section subtitles: uppercase, letter-spacing=5px, size=11px, color=#722F37, weight=500
- Body text: size 16px, color=#5A4E48, line-height 1.9

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeIn', animation_duration='slow', _animation_delay=300
- Hero subtext: _animation='fadeIn', animation_duration='slow', _animation_delay=500
- Hero buttons: _animation='fadeInUp', _animation_delay=700
- Section headings: _animation='fadeIn', animation_duration='slow'
- Wine cards: _animation='fadeIn', animation_duration='slow', stagger 150ms
- About image: _animation='fadeInLeft', animation_duration='slow'
- CTA: _animation='fadeIn', animation_duration='slow'

## IMAGE SOURCING — DO THIS FIRST
1. "wine cellar barrels elegant" — hero
2. "wine bottles collection display" — shop
3. "wine tasting glass sommelier" — tasting
4. "vineyard landscape beautiful" — story
5. "cheese wine pairing board" — events
6. "red wine pouring glass close" — menu
7. "wine shop interior modern" — atmosphere
8. "champagne celebration toast" — sparkling

## SVG ICONS
- Wine glass icon | Grape icon | Barrel icon | Star icon | Calendar icon | Gift icon | Thermometer icon | Map pin icon | Phone icon | Cork icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded wine cellar, overlay #1A1216 at 0.5
- Min-height 650px, centered:
  - Label: "WINE SHOP & TASTING ROOM" — color=#C9A96E, _animation='fadeIn'
  - Heading: "Discover. Taste. Savor." — size=54px, weight=400, _animation='fadeIn', _animation_delay=300
  - Subtext about curated selection, 500+ labels, expert sommeliers — _animation='fadeIn', _animation_delay=500
  - Buttons: "Shop Wines" (#722F37) | "Book Tasting" (border #C9A96E)

### 2. FEATURE STRIP
- Background: #722F37
- "500+ Labels" | "Weekly Tastings" | "Expert Sommeliers" | "Gift Boxes Available"

### 3. COLLECTIONS (3 featured cards)
- Background: #FAF5EF
- Heading: "Curated Collections" — _animation='fadeIn'
- Row with 3 cards: Reds | Whites & Rosé | Sparkling & Champagne
- Each: Image, collection name, description, "From $18/bottle" pricing

### 4. ABOUT (2-column)
- Background: #FFFFFF
- Vineyard image + story, sourcing from small-batch vineyards worldwide

### 5. TASTING EVENTS (dark section)
- Background: #1A1216
- Heading: "Tasting Experiences" — color=#FFFFFF
- 3 cards: Weekly Wine Flight ($25) | Private Tasting Party ($150) | Wine & Cheese Pairing ($45)

### 6. WINE CLUB (feature section)
- Background: #FAF5EF
- Heading: "Join the Wine Club"
- Benefits: Monthly curated bottle | Exclusive tastings | 15% store discount | Members-only events
- Pricing: "$49/month" — featured card with CTA

### 7. TESTIMONIALS (3 cards)
- Background: #FFFFFF

### 8. CTA
- Background: sideloaded vineyard, overlay
- Heading: "Find Your New Favorite Bottle" — _animation='fadeIn'
- Buttons: "Shop Now" | "Visit Us"

### 9. FOOTER — Background: #1A1216

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(114, 47, 55, 0.3); }
::selection { background: #722F37; color: #FFFFFF; }
```
### Element-Level CSS — Wine Cards:
```css
selector { transition: transform 0.5s ease, box-shadow 0.5s ease; }
selector:hover { transform: translateY(-6px); box-shadow: 0 15px 40px rgba(0,0,0,0.08); }
```

## FINAL CHECKLIST
- Sophisticated, wine-themed — burgundy, champagne gold, vineyard greens
- Slow elegant animations
- Tasting events and wine club prominently featured
- NO flex_wrap or _flex_size — Publish as draft
