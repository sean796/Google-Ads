Create a warm, charming landing page for "Golden Crumb Bakery" — an artisan bakery and patisserie.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #C4956A (warm caramel/crust)
- Primary Dark: #A67B52 (darker crust for hover)
- Accent: #E8B88A (golden wheat)
- Cream: #FDF6EE (warm cream background)
- Dark: #3B2416 (dark chocolate brown)
- Dark Surface: #4E3224 (medium chocolate)
- Light Text: #FFFFFF
- Body Text: #6B5A4E (warm taupe)
- Muted: #9A8A7E
- Soft Pink: #F4E0D4 (pastry blush)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case, warm and elegant
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#C4956A, weight=600
- Body text: size 16-17px, color=#6B5A4E, line-height 1.8

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required
- For overlays: background_overlay_background='classic', background_overlay_color='#hex', background_overlay_opacity={size:0.6,unit:'px'}

## ENTRANCE ANIMATIONS (use on key elements)
Use Elementor's built-in entrance animations via the _animation setting on containers and widgets:
- Hero heading: _animation='fadeInDown', animation_duration='', _animation_delay=200
- Hero subtext: _animation='fadeInUp', animation_duration='', _animation_delay=400
- Hero buttons: _animation='fadeInUp', animation_duration='', _animation_delay=600
- Section headings: _animation='fadeInUp', animation_duration='', _animation_delay=0
- Product/menu cards: _animation='fadeInUp', animation_duration='', _animation_delay=100 (stagger by 100ms per card)
- About section image: _animation='fadeInLeft', animation_duration='', _animation_delay=0
- About section text: _animation='fadeInRight', animation_duration='', _animation_delay=200
- Testimonial cards: _animation='fadeInUp', animation_duration='', _animation_delay=100 (stagger)
- CTA heading: _animation='zoomIn', animation_duration='', _animation_delay=0
- Footer columns: _animation='fadeInUp', animation_duration='', _animation_delay=100 (stagger)

## IMAGE SOURCING — DO THIS FIRST
Before building the page, use the search-images and sideload-image tools:
1. "bakery fresh bread display warm" — for hero background
2. "artisan croissant pastry golden" — for about section
3. "baker kneading dough professional" — for story section
4. "wedding cake elegant tiered" — for custom orders
5. "sourdough bread loaf artisan" — for products
6. "pastry display case bakery" — for menu
7. "bakery interior rustic warm" — for atmosphere
8. "cupcakes decorated colorful" — for sweets section

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Do NOT use Elementor's icon library. Warm, elegant line icons:
- Wheat/grain icon (bakery general)
- Croissant icon (pastries)
- Cake icon (custom cakes)
- Clock icon (hours/fresh daily)
- Star icon (reviews)
- Heart icon (favorites)
- Truck icon (delivery)
- Phone icon (orders)
- Map pin icon (location)
- Gift icon (special orders)

## PAGE STRUCTURE

### 1. HERO SECTION
Full-width container:
- Background: sideloaded bakery bread display, background_size='cover', background_position='center center'
- Overlay: background_overlay_color='#3B2416', background_overlay_opacity={size:0.55,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Centered content:
  - Small label: "ARTISAN BAKERY · EST. 2018" — color=#C4956A, size=13px, uppercase, letter-spacing=4px, _animation='fadeInDown', _animation_delay=0
  - Main heading: "Baked Fresh Every Morning" — color=#FFFFFF, size=52px, weight=700, _animation='fadeInDown', _animation_delay=200
  - Subtext: "From golden sourdough to delicate French pastries — handcrafted with love using time-honored recipes and the finest ingredients." — color=#F4E0D4, size=18px, _animation='fadeInUp', _animation_delay=400
  - Row with buttons (_animation='fadeInUp', _animation_delay=600):
    - "Order Online" — background_color=#C4956A, text_color=#FFFFFF, border_radius={top:30,right:30,bottom:30,left:30,unit:'px'}
    - "View Our Menu" — background=transparent, border_color='#C4956A', text_color=#C4956A, border_radius rounded
  - Small text: "Fresh bakes ready by 7AM daily" — color=#F4E0D4, size=14px

### 2. FEATURE STRIP (3 highlights)
- Background: background_background='classic', background_color='#C4956A'
- Padding: {top:'25',right:'0',bottom:'25',left:'0',unit:'px'}
- Row container with 3 children:
  - Each: centered row with SVG icon + text
  - "Baked Fresh Daily" | "100% Natural Ingredients" | "Same-Day Delivery"
  - Icon color=#FFFFFF, text color=#FFFFFF, size=14px

### 3. ABOUT / STORY SECTION (2-column)
- Background: background_background='classic', background_color='#FDF6EE'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left: Image widget (baker kneading dough), border_radius={top:12,right:12,bottom:12,left:12,unit:'px'}, _animation='fadeInLeft'
  - Right (align_items='flex-start'):
    - Subtitle: "OUR STORY" — color=#C4956A, _animation='fadeInRight', _animation_delay=0
    - Heading: "Three Generations of Baking" — color=#3B2416, size=36px, _animation='fadeInRight', _animation_delay=100
    - Text: 2 paragraphs about family tradition, early morning bakes, using traditional techniques with modern flair — color=#6B5A4E, _animation='fadeInRight', _animation_delay=200
    - Row with stats (_animation='fadeInUp', _animation_delay=300):
      - "25+" / "Years Baking" — heading color=#3B2416, text color=#6B5A4E
      - "50+" / "Daily Varieties"
      - "100%" / "Handcrafted"

### 4. POPULAR ITEMS (2 rows of 3 cards)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "FRESH FROM THE OVEN" — color=#C4956A, centered
- Heading: "Our Best Sellers" — color=#3B2416, centered, _animation='fadeInUp'
- Row 1: 3 product cards (_animation='fadeInUp', stagger _animation_delay by 100ms)
- Row 2: 3 more product cards

  Each product card (column container):
  - Image widget (product photo), border_radius top corners
  - Content area: padding, text-align center
  - Item name: "Classic Sourdough" — color=#3B2416, size=18px, weight=600
  - Description: short line — color=#6B5A4E, size=14px
  - Price: "$6.50" — color=#C4956A, size=20px, weight=700

  Items:
  - Row 1: Classic Sourdough ($6.50) | Butter Croissant ($4.25) | Chocolate Éclair ($5.75)
  - Row 2: Blueberry Muffin ($3.50) | Cinnamon Roll ($4.75) | French Baguette ($5.00)

### 5. CUSTOM ORDERS (2-column: text left, image right)
- Background: background_background='classic', background_color='#3B2416'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left (align_items='flex-start'):
    - Subtitle: "CUSTOM ORDERS" — color=#C4956A, _animation='fadeInLeft'
    - Heading: "Made Just for You" — color=#FFFFFF, size=36px, _animation='fadeInLeft', _animation_delay=100
    - Text: Wedding cakes, birthday cakes, corporate catering, seasonal specialties — color=#F4E0D4, _animation='fadeInLeft', _animation_delay=200
    - Icon list: "Wedding & Celebration Cakes" | "Corporate Catering" | "Seasonal Specials" | "Gift Boxes & Hampers" — color=#F4E0D4
    - Button: "Request a Quote" — background_color=#C4956A, text_color=#FFFFFF, _animation='fadeInUp', _animation_delay=400
  - Right: Image (wedding cake), border_radius, _animation='fadeInRight'

### 6. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#FDF6EE'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle + heading centered, _animation='fadeInUp'
- Row with 3 cards (_animation='fadeInUp', stagger by 100ms):
  - Each: white background, padding, border_radius={top:12,right:12,bottom:12,left:12,unit:'px'}, border (#F4E0D4)
  - Star rating (5 stars, color=#C4956A)
  - Quote — color=#6B5A4E, italic
  - Name (#3B2416, bold) + "Regular Customer" (#9A8A7E)

### 7. VISIT US (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left (_animation='fadeInLeft'):
    - Subtitle: "VISIT US" — color=#C4956A
    - Heading: "Find Our Bakery" — color=#3B2416
    - Address, phone, email — color=#6B5A4E with SVG icons
    - Hours: "Mon-Sat: 7AM-7PM | Sunday: 8AM-3PM"
  - Right: Google Maps widget, _animation='fadeInRight'

### 8. CTA SECTION
- Background: sideloaded bakery interior image, background_size='cover'
- Overlay: background_overlay_color='#3B2416', background_overlay_opacity={size:0.7,unit:'px'}
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered:
  - Heading: "Order Your Favorites Today" — color=#FFFFFF, size=40px, _animation='zoomIn'
  - Subtext: "Skip the queue — order online for pickup or same-day delivery." — color=#F4E0D4, _animation='fadeInUp', _animation_delay=200
  - Row with buttons (_animation='fadeInUp', _animation_delay=400):
    - "Order Now" — background_color=#C4956A, text_color=#FFFFFF
    - "Call Us" — border_color='#C4956A', text_color=#C4956A

### 9. FOOTER
- Background: background_background='classic', background_color='#3B2416'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row with 4 columns (_animation='fadeInUp', stagger by 100ms):
  - Col 1: "Golden Crumb" heading + tagline — color=#FFFFFF / #F4E0D4
  - Col 2: "Products" links — color=#9A8A7E
  - Col 3: "Info" links — color=#9A8A7E
  - Col 4: "Contact" info — color=#9A8A7E
- Divider (color=#4E3224)
- Copyright: "© 2026 Golden Crumb Bakery. All rights reserved." — color=#6B5A4E

## CUSTOM CSS — APPLY AFTER PAGE IS BUILT (minimal — entrance animations handle most motion)

### Page-Level CSS (no element_id):
```css
html { scroll-behavior: smooth; }

/* Button hover lift */
.elementor-button {
  transition: all 0.3s ease !important;
}
.elementor-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(196, 149, 106, 0.3);
}

/* Warm selection */
::selection {
  background: #C4956A;
  color: #FFFFFF;
}
```

### Element-Level CSS — Product Cards:
```css
selector {
  transition: transform 0.4s ease, box-shadow 0.4s ease;
  overflow: hidden;
}
selector:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 50px rgba(59, 36, 22, 0.12);
}
```

### Element-Level CSS — Product Card Images:
```css
selector img {
  transition: transform 0.6s ease;
}
selector:hover img {
  transform: scale(1.05);
}
```

## CUSTOM JAVASCRIPT — APPLY AFTER PAGE IS BUILT
Use `add-custom-js` with wrap_dom_ready=true.

### Counter Animation (add-custom-js, wrap_dom_ready=true):
```javascript
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 35);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 35);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** using build-page (include _animation settings on elements)
4. **Apply page-level CSS** (no element_id)
5. **Apply element-level CSS** for product cards
6. **Inject custom JS** with wrap_dom_ready=true

## FINAL CHECKLIST
- Every container with a background color MUST have both background_background='classic' AND background_color set
- All text colors explicitly set
- NO flex_wrap or _flex_size anywhere
- All images real sideloaded images
- Use SVG icons, not Elementor icon library
- Entrance animations (_animation) applied to hero elements, section headings, cards, and CTA
- Staggered delays on repeating elements (cards, columns)
- Custom CSS only for hover effects not achievable via built-in animations
- Warm, inviting bakery atmosphere — creams, caramels, soft pinks
- Publish the page as draft
