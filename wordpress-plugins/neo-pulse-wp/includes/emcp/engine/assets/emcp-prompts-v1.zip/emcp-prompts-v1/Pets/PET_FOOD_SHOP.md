Create a warm, trustworthy landing page for "Healthy Paws Market" — a premium natural pet food and supplies shop.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #16A34A (natural green)
- Primary Dark: #15803D (darker green)
- Accent: #F59E0B (warm amber/gold)
- Warm: #92400E (earthy brown)
- Dark: #14532D (deep forest)
- Light Text: #FFFFFF
- Body Text: #4B5563 (gray)
- Light BG: #F0FDF4 (mint tint)
- Card BG: #FFFFFF
- Border: #D1FAE5

### Typography
- Headings: weight 700, title case — friendly and trustworthy
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#16A34A
- Body text: size 16px, color=#4B5563, line-height 1.7

## IMAGE SOURCING — DO THIS FIRST
1. "pet food store interior display" — hero
2. "premium dog food natural organic" — products
3. "happy dog eating healthy food" — about
4. "cat food natural premium" — products
5. "pet treats natural handmade" — products
6. "pet store staff helping customer" — about
7. "dog and cat together happy" — general
8. "pet supplements vitamins display" — products

## SVG ICONS
Friendly icons: Paw print, Leaf/organic, Shield/checkmark, Bone, Fish, Heart, Shopping cart, Delivery truck, Star, Ribbon.

## PAGE STRUCTURE

### 1. HERO (2-column: text left, promo right)
- Background: sideloaded pet store, background_size='cover'
- Overlay: background_overlay_color='#14532D', background_overlay_opacity={size:0.7,unit:'px'}
- Row:
  - Left: "NATURALLY BETTER PET NUTRITION" label (#F59E0B), "Real Food for Real Pets" heading (#FFFFFF, 48px), subtext, "Shop Now" + "Nutrition Guide" buttons
  - Right: Promo card — white bg, "First Order Special" heading, "20% OFF + Free Delivery" (#16A34A, large), features list, "Claim Offer" button

### 2. CATEGORY CARDS (4 in a row)
- Background: background_color='#F0FDF4'
- Row 4: image + category name
  - "Dog Food" | "Cat Food" | "Treats & Chews" | "Supplements"

### 3. WHY NATURAL (2-column)
- Background: background_color='#FFFFFF'
- Left: "WHY HEALTHY PAWS" subtitle, heading, text about real ingredients, no fillers, vet-approved
- Icon list: "100% Natural Ingredients" | "No Artificial Preservatives" | "Vet Nutritionist Approved" | "Locally Sourced"
- Right: Happy dog image

### 4. BESTSELLERS (3 product cards)
- Background: background_color='#F0FDF4'
- "BESTSELLERS" subtitle + heading
- Row 3 cards: product image, name, size/weight, price (#16A34A bold), star rating, "Add to Cart" button
  - Grass-Fed Beef Recipe ($54.99/25lb) | Wild-Caught Salmon Formula ($48.99/20lb) | Organic Chicken Bites ($12.99/8oz)

### 5. SUBSCRIPTION CTA
- Background: background_color='#16A34A'
- "Subscribe & Save 15%" heading (#FFFFFF), "Auto-delivery every 2, 4, or 6 weeks. Cancel anytime." subtext, "Start Subscription" button (#FFFFFF bg, #16A34A text)

### 6. TESTIMONIALS (3 cards)
- Background: background_color='#FFFFFF'
- Stars (#F59E0B), quote, name + pet name

### 7. STORE INFO (2-column)
- Background: background_color='#F0FDF4'
- Left: Address, phone, hours, "Free delivery on orders over $50"
- Right: Google Maps

### 8. FOOTER
- Background: background_color='#14532D'
- 4 columns — color=#86EFAC/#FFFFFF
- Copyright

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(22, 163, 74, 0.3); }
.elementor-image img { transition: transform 0.5s ease; }
.elementor-image:hover img { transform: scale(1.04); }
```

### Element-Level — Product Cards:
```css
selector { transition: transform 0.3s ease, box-shadow 0.3s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 15px 40px rgba(0,0,0,0.1); }
```

### Element-Level — Category Cards:
```css
selector { overflow: hidden; transition: transform 0.4s ease; }
selector:hover { transform: translateY(-6px); }
selector:hover img { transform: scale(1.06); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-icon-box-wrapper').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(25px)'; el.style.transition = 'opacity 0.6s ease, transform 0.6s ease'; observer.observe(el);
});
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Natural/organic feel: greens, ambers, mint tints — Product cards with prices and ratings — Subscription CTA — Publish as draft
