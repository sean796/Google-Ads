Create a caring, professional landing page for "PawCare Veterinary Clinic" — a full-service animal hospital and wellness center.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #2E7D32 (nature green)
- Primary Dark: #1B5E20 (deeper green for hover)
- Accent: #42A5F5 (sky blue)
- Light BG: #F0F7F0 (soft green tint)
- Dark: #1A2A1A (forest dark)
- Dark Surface: #243424
- Light Text: #FFFFFF
- Body Text: #4A5A4A (sage gray)
- Muted: #7A8A7A
- Warm: #FF8A65 (warm coral for accents)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700, title case — caring and trustworthy
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#2E7D32, weight=600
- Body text: size 16-17px, color=#4A5A4A, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Service cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- About text: _animation='fadeInRight', _animation_delay=200
- Testimonials: _animation='fadeInUp', stagger 100ms
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "veterinarian examining dog clinic" — hero
2. "happy dog golden retriever vet" — services
3. "cat veterinary checkup" — services
4. "veterinary clinic modern interior" — atmosphere
5. "vet team staff professional" — team
6. "puppy vaccination vet office" — wellness
7. "pet surgery veterinary" — surgical
8. "dog owner happy pet clinic" — testimonials

## SVG ICONS
- Paw print icon | Heart icon | Stethoscope icon | Syringe icon | Shield icon | Clock icon | Phone icon | Map pin icon | Star icon | Cross/medical icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded vet with dog, overlay #1A2A1A at 0.55
- Min-height 650px
- Row: Left text + Right appointment card
  - Label: "FULL-SERVICE VETERINARY CARE" — color=#42A5F5, _animation='fadeInDown'
  - Heading: "Compassionate Care for Your Best Friend" — size=48px, _animation='fadeInDown', _animation_delay=200
  - Subtext — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Book Appointment" (#2E7D32) | "Emergency Line" (border #FF8A65)
  - Right: "New Patient" card — free first exam offer

### 2. TRUST BAR
- Background: #2E7D32
- "20+ Years" | "15,000+ Pets" | "24/7 Emergency" | "Fear-Free Certified"

### 3. SERVICES (2 rows of 3)
- Background: #F0F7F0
- 6 cards: Wellness Exams | Vaccinations | Surgery | Dental Care | Emergency Care | Grooming
- Each with icon, title, description

### 4. ABOUT (2-column)
- Background: #FFFFFF
- Team photo + about the clinic, credentials, philosophy of fear-free care

### 5. PET TYPES (dark section)
- Background: #1A2A1A
- Heading: "We Treat All Family Members"
- Row with icons: Dogs | Cats | Birds | Exotic Pets
- Brief text about comprehensive species care

### 6. TESTIMONIALS (3 cards)
- Background: #F0F7F0

### 7. LOCATION
- Background: #FFFFFF
- Address, hours (Mon-Fri 8AM-7PM, Sat 9AM-3PM, Emergency 24/7), Google Maps

### 8. CTA
- Background: #2E7D32
- Heading: "Your Pet Deserves the Best" — _animation='zoomIn'
- Buttons: "Book Online" | "Call (555) 678-9012"

### 9. FOOTER — Background: #1A2A1A

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(46, 125, 50, 0.3); }
::selection { background: #2E7D32; color: #FFFFFF; }
```
### Element-Level CSS — Service Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(26, 42, 26, 0.1); }
```

## FINAL CHECKLIST
- Caring, professional — nature greens, sky blues, warm corals
- Trust elements: years, pets treated, certifications
- Emergency care prominently highlighted
- New patient offer in hero
- NO flex_wrap or _flex_size — Publish as draft
