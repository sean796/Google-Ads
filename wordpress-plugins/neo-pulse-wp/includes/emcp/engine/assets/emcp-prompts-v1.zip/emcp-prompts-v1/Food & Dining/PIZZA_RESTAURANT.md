Create a bold, appetizing landing page for "Napoli Fire Pizza" — an authentic wood-fired pizza restaurant.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #D32F2F (tomato red)
- Primary Dark: #B71C1C (darker red for hover)
- Accent: #F9A825 (golden cheese/crust)
- Cream: #FFF8E1 (warm cream)
- Dark: #1B1210 (charcoal/oven dark)
- Dark Surface: #2C2018 (dark wood)
- Light Text: #FFFFFF
- Body Text: #5D4E42 (warm brown-gray)
- Muted: #8B7A6E
- Olive: #558B2F (basil green)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700-800, mix of uppercase and title case — bold, Italian-inspired feel
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#D32F2F, weight=600
- Body text: size 16-17px, color=#5D4E42, line-height 1.8

### Background Colors on Containers
- Set background_background='classic' AND background_color='#hex' — both are required
- For overlays: background_overlay_background='classic', background_overlay_color='#hex', background_overlay_opacity={size:0.65,unit:'px'}

## ENTRANCE ANIMATIONS
Use Elementor's built-in entrance animations via _animation setting:
- Hero heading: _animation='fadeInDown', animation_duration='', _animation_delay=200
- Hero subtext: _animation='fadeInUp', animation_duration='', _animation_delay=400
- Hero buttons: _animation='fadeInUp', animation_duration='', _animation_delay=600
- Section headings: _animation='fadeInUp', animation_duration='', _animation_delay=0
- Menu cards: _animation='fadeInUp', _animation_delay staggered by 100ms per card
- About image: _animation='fadeInLeft', _animation_delay=0
- About text block: _animation='fadeInRight', _animation_delay=200
- Testimonial cards: _animation='fadeInUp', stagger by 100ms
- CTA heading: _animation='zoomIn', _animation_delay=0
- Footer columns: _animation='fadeInUp', stagger by 100ms

## IMAGE SOURCING — DO THIS FIRST
1. "pizza wood fired oven flame" — hero background
2. "margherita pizza fresh basil" — menu item
3. "pizza chef tossing dough" — about section
4. "italian restaurant interior rustic" — atmosphere
5. "pepperoni pizza close up" — menu
6. "pizza oven brick traditional" — story section
7. "italian antipasti appetizers" — starters
8. "tiramisu italian dessert" — desserts

Use the actual sideloaded image IDs and URLs. Do NOT use placeholder URLs.

## SVG ICONS
Use upload-svg-icon. Bold, warm line icons:
- Pizza slice icon (general)
- Flame icon (wood-fired)
- Leaf/basil icon (fresh ingredients)
- Clock icon (hours)
- Star icon (reviews)
- Truck icon (delivery)
- Phone icon (reservations)
- Map pin icon (location)
- Wine glass icon (drinks)
- Chef hat icon (kitchen)

## PAGE STRUCTURE

### 1. HERO SECTION
Full-width container:
- Background: sideloaded wood-fired oven image, background_size='cover', background_position='center center'
- Overlay: background_overlay_color='#1B1210', background_overlay_opacity={size:0.6,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Centered content:
  - Small label: "WOOD-FIRED · AUTHENTIC ITALIAN" — color=#F9A825, size=13px, uppercase, letter-spacing=4px, _animation='fadeInDown'
  - Main heading: "Pizza the Way It Was Meant to Be" — color=#FFFFFF, size=52px, weight=800, _animation='fadeInDown', _animation_delay=200
  - Subtext: "Hand-stretched dough, San Marzano tomatoes, and 900°F wood-fired perfection. Taste the tradition of Naples in every bite." — color=#FFF8E1, size=18px, _animation='fadeInUp', _animation_delay=400
  - Row with buttons (_animation='fadeInUp', _animation_delay=600):
    - "Order Now" — background_color=#D32F2F, text_color=#FFFFFF, border_radius={top:4,right:4,bottom:4,left:4,unit:'px'}
    - "View Menu" — background=transparent, border_color='#F9A825', text_color=#F9A825
  - Small text: "Dine In · Takeout · Delivery" — color=#FFF8E1, size=14px

### 2. FEATURE STRIP
- Background: background_background='classic', background_color='#D32F2F'
- Padding: {top:'25',right:'0',bottom:'25',left:'0',unit:'px'}
- Row with 3 children:
  - "Wood-Fired at 900°F" | "Imported Italian Ingredients" | "Free Delivery Over $30"
  - Icon color=#FFFFFF, text color=#FFFFFF

### 3. MENU HIGHLIGHTS (2 rows of 3)
- Background: background_background='classic', background_color='#FFF8E1'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "OUR MENU" — color=#D32F2F, centered
- Heading: "Signature Pizzas" — color=#1B1210, centered, _animation='fadeInUp'
- Row 1: 3 pizza cards (_animation='fadeInUp', stagger delays)
- Row 2: 3 more pizza cards

  Each card (column container):
  - Image widget (pizza photo), border_radius top corners
  - Content area: background_color='#FFFFFF', padding, border (#FFF8E1)
  - Pizza name: "Margherita Classica" — color=#1B1210, size=18px, weight=700
  - Description: "San Marzano tomatoes, fior di latte, fresh basil, EVOO" — color=#5D4E42, size=14px
  - Row: Price + size tag
    - "$14" — color=#D32F2F, size=22px, weight=700
    - "12 inch" — color=#8B7A6E, size=13px

  Pizzas:
  - Row 1: Margherita Classica ($14) | Diavola ($16) | Quattro Formaggi ($17)
  - Row 2: Prosciutto e Rucola ($18) | Napoli Special ($19) | Vegetariana ($15)

### 4. ABOUT / STORY (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row container:
  - Left: Image (pizza chef), border_radius, _animation='fadeInLeft'
  - Right (align_items='flex-start'):
    - Subtitle: "OUR STORY" — color=#D32F2F, _animation='fadeInRight'
    - Heading: "From Naples to Your Table" — color=#1B1210, size=36px, _animation='fadeInRight', _animation_delay=100
    - Text: Story of bringing authentic Neapolitan pizza-making traditions, imported ingredients, hand-built brick oven — color=#5D4E42, _animation='fadeInRight', _animation_delay=200
    - Stats row (_animation='fadeInUp', _animation_delay=300):
      - "900°F" / "Oven Temp" | "72hr" / "Dough Ferment" | "100%" / "Imported"

### 5. SPECIALS SECTION (appetizers + desserts — 2 cards side by side)
- Background: background_background='classic', background_color='#1B1210'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle: "BEYOND PIZZA" — color=#F9A825, centered
- Heading: "Starters & Dolci" — color=#FFFFFF, centered, _animation='fadeInUp'
- Row with 2 large cards (_animation='fadeInUp', stagger):
  - Antipasti card: image + list of items (Bruschetta, Arancini, Caprese) — dark surface card
  - Desserts card: image + list (Tiramisu, Panna Cotta, Cannoli) — dark surface card
  - Card background_color='#2C2018', text color=#FFFFFF

### 6. TESTIMONIALS (3 cards)
- Background: background_background='classic', background_color='#FFF8E1'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Subtitle + heading centered
- Row with 3 cards (_animation='fadeInUp', stagger by 100ms):
  - Each: white bg, padding, border_radius, border
  - Star rating (color=#F9A825)
  - Quote — color=#5D4E42, italic
  - Name (#1B1210, bold) + "via Google Reviews" (#8B7A6E)

### 7. LOCATION & HOURS (2-column)
- Background: background_background='classic', background_color='#FFFFFF'
- Padding: {top:'100',right:'0',bottom:'100',left:'0',unit:'px'}
- Row:
  - Left (_animation='fadeInLeft'):
    - Subtitle: "FIND US" — color=#D32F2F
    - Heading: "Visit Napoli Fire" — color=#1B1210
    - Address, phone — color=#5D4E42
    - Hours: "Tue-Thu: 11AM-10PM | Fri-Sat: 11AM-11PM | Sun: 12PM-9PM | Mon: Closed"
  - Right: Google Maps widget, _animation='fadeInRight'

### 8. CTA SECTION
- Background: sideloaded restaurant interior, background_size='cover'
- Overlay: background_overlay_color='#1B1210', background_overlay_opacity={size:0.75,unit:'px'}
- Padding: {top:'80',right:'0',bottom:'80',left:'0',unit:'px'}
- Centered:
  - Heading: "Hungry Yet?" — color=#FFFFFF, size=44px, _animation='zoomIn'
  - Subtext: "Order online for pickup or delivery. Reserve a table for the full Napoli Fire experience." — color=#FFF8E1, _animation='fadeInUp', _animation_delay=200
  - Row with buttons (_animation='fadeInUp', _animation_delay=400):
    - "Order Online" — background_color=#D32F2F, text_color=#FFFFFF
    - "Reserve a Table" — border_color='#F9A825', text_color=#F9A825

### 9. FOOTER
- Background: background_background='classic', background_color='#1B1210'
- Padding: {top:'60',right:'0',bottom:'60',left:'0',unit:'px'}
- Row with 4 columns (_animation='fadeInUp', stagger):
  - Col 1: "Napoli Fire" heading + tagline
  - Col 2: "Menu" links — color=#8B7A6E
  - Col 3: "About" links — color=#8B7A6E
  - Col 4: "Contact" — color=#8B7A6E
- Divider (color=#2C2018)
- Copyright: "© 2026 Napoli Fire Pizza. All rights reserved." — color=#5D4E42

## CUSTOM CSS — APPLY AFTER PAGE IS BUILT (minimal)

### Page-Level CSS (no element_id):
```css
html { scroll-behavior: smooth; }

.elementor-button {
  transition: all 0.3s ease !important;
}
.elementor-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(211, 47, 47, 0.3);
}

::selection {
  background: #D32F2F;
  color: #FFFFFF;
}
```

### Element-Level CSS — Menu Cards:
```css
selector {
  transition: transform 0.4s ease, box-shadow 0.4s ease;
  overflow: hidden;
}
selector:hover {
  transform: translateY(-8px);
  box-shadow: 0 20px 50px rgba(27, 18, 16, 0.12);
}
selector:hover img {
  transform: scale(1.05);
}
```

## CUSTOM JAVASCRIPT — APPLY AFTER PAGE IS BUILT
Use `add-custom-js` with wrap_dom_ready=true.

```javascript
// Counter animation for stats
const counterObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent.trim();
      const match = text.match(/(\d+)/);
      if (match) {
        const target = parseInt(match[1]);
        const suffix = text.replace(match[1], '');
        let current = 0;
        const inc = Math.ceil(target / 35);
        const timer = setInterval(() => {
          current += inc;
          if (current >= target) { current = target; clearInterval(timer); }
          el.textContent = current + suffix;
        }, 35);
      }
      counterObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.elementor-heading-title').forEach(el => {
  if (/^\d/.test(el.textContent.trim())) counterObs.observe(el);
});
```

## EXECUTION ORDER
1. **Search & sideload** all 8 images
2. **Upload SVG icons**
3. **Build the page** using build-page (include _animation settings)
4. **Apply page-level CSS** (no element_id)
5. **Apply element-level CSS** for menu cards
6. **Inject custom JS** with wrap_dom_ready=true

## FINAL CHECKLIST
- Every container with a background color MUST have both background_background='classic' AND background_color set
- All text colors explicitly set
- NO flex_wrap or _flex_size anywhere
- All images real sideloaded images
- Use SVG icons, not Elementor icon library
- Entrance animations on hero, headings, cards (staggered), CTA
- Bold Italian feel — reds, golds, warm creams
- Publish the page as draft
