Create a commanding, authoritative landing page for "Sterling & Associates" — a full-service law firm specializing in personal injury and business litigation.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #1E293B (slate-800 — authoritative navy)
- Primary Light: #334155 (slate-700)
- Accent: #B45309 (deep gold/amber)
- Accent Light: #D4A06A (lighter gold)
- Dark: #0F172A (near-black)
- Light Text: #FFFFFF
- Body Text: #475569 (slate-600)
- Light BG: #F8FAFC (slate-50)
- Card BG: #FFFFFF
- Border: #CBD5E1

### Typography
- Headings: weight 700, title case — confident, serif-inspired feel
- Section subtitles: uppercase, letter-spacing=4px, size=11px, color=#B45309
- Body text: size 16px, color=#475569, line-height 1.8

## IMAGE SOURCING — DO THIS FIRST
1. "law firm office modern interior" — hero
2. "lawyer professional portrait" — attorneys
3. "courtroom legal justice" — about
4. "business meeting conference room" — services
5. "lawyer team professional group" — team
6. "law books legal library" — about
7. "city skyline office building" — CTA background
8. "handshake business agreement" — results

## SVG ICONS
Sophisticated, minimal icons: Scale of justice, Gavel, Shield, Document/brief, Handshake, Clock, Phone, Building, Certificate, Award.

## PAGE STRUCTURE

### 1. HERO (2-column: text left, consultation form right)
- Background: sideloaded law office, background_size='cover'
- Overlay: background_overlay_color='#0F172A', background_overlay_opacity={size:0.8,unit:'px'}
- Min-height: {size:650,unit:'px'}
- Row:
  - Left: "EXPERIENCED LEGAL ADVOCATES" label (#B45309), "When the Stakes Are High, Experience Matters" heading (#FFFFFF, 46px), "Over $150 million recovered for our clients. Sterling & Associates fights for the compensation and justice you deserve." (#CBD5E1), "Free Case Review" + "Call: (555) 321-9876" buttons
  - Right: Form — white bg, "Free Confidential Consultation" heading, form (Full Name, Phone, Email, Case Type [Personal Injury, Car Accident, Medical Malpractice, Business Litigation, Employment Law, Workers' Comp, Criminal Defense, Other], Brief Description textarea, "Submit for Review" button — #B45309 bg). Trust text: "Confidential. No obligation. We don't get paid unless you win."

### 2. RESULTS BAR
- Background: background_color='#1E293B'
- Row 4: "$150M+" / "Recovered" | "2,500+" / "Cases Won" | "35+" / "Years Combined" | "98%" / "Success Rate" — #FFFFFF headings, #CBD5E1 labels

### 3. PRACTICE AREAS (6 cards in 3x2)
- Background: background_color='#F8FAFC'
- "PRACTICE AREAS" subtitle + heading
- 6 cards: icon, area name, description
  - Personal Injury | Car & Truck Accidents | Medical Malpractice | Business Litigation | Employment Law | Workers' Compensation

### 4. WHY US (2-column)
- Background: background_color='#FFFFFF'
- Left: subtitle, "Why Clients Choose Sterling" heading, text, points: "No Fee Unless We Win" | "24/7 Availability" | "Personalized Attention" | "Proven Track Record"
- Right: Handshake/team image

### 5. ATTORNEYS (3 cards)
- Background: background_color='#F8FAFC'
- "OUR ATTORNEYS" subtitle + heading
- Row 3: portrait image, name, title, bar admission, brief bio
  - "Michael Sterling — Founding Partner" | "Diana Torres — Senior Litigator" | "James Whitfield — Trial Attorney"

### 6. NOTABLE RESULTS (3 cards)
- Background: background_color='#1E293B'
- "CASE RESULTS" subtitle (#B45309) + heading (#FFFFFF)
- Row 3: large dollar amount (#B45309, big), case type (#FFFFFF), brief description (#CBD5E1)
  - "$12.5 Million — Truck Accident Settlement" | "$8.2 Million — Medical Malpractice" | "$4.7 Million — Workplace Injury"

### 7. TESTIMONIALS (3 cards)
- Background: background_color='#FFFFFF'
- Stars (#B45309), quote, name + case type

### 8. CTA
- Background: sideloaded skyline image, overlay
- "Your Fight is Our Fight" heading (#FFFFFF), subtext, "Schedule Free Consultation" button (#B45309 bg)

### 9. FOOTER
- Background: background_color='#0F172A'
- 4 columns: Firm name | Practice Areas | Resources | Contact — color=#94A3B8/#FFFFFF
- Disclaimer: "The information on this website is for general purposes only and does not constitute legal advice." — color=#64748B, small
- Copyright

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.4s ease !important; letter-spacing: 1px !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(180, 83, 9, 0.25); }
.elementor-image img { transition: transform 0.6s ease; }
.elementor-image:hover img { transform: scale(1.03); }
.elementor-field-group input:focus, .elementor-field-group select:focus, .elementor-field-group textarea:focus { border-color: #B45309 !important; box-shadow: 0 0 0 3px rgba(180, 83, 9, 0.1) !important; }
::selection { background: #1E293B; color: #FFFFFF; }
```

### Element-Level — Practice Area Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-6px); box-shadow: 0 15px 40px rgba(0,0,0,0.08); }
```

### Element-Level — Notable Results Cards:
```css
selector { transition: transform 0.3s ease, border-color 0.3s ease; border-left: 4px solid transparent; }
selector:hover { transform: translateX(5px); border-left-color: #B45309; }
```

### Element-Level — Consultation Form:
```css
selector { box-shadow: 0 25px 60px rgba(0,0,0,0.3); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-icon-box-wrapper, .elementor-widget-text-editor').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(30px)'; el.style.transition = 'opacity 0.7s ease, transform 0.7s ease'; observer.observe(el);
});
// Counter for results bar
const cObs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target; const text = el.textContent.trim(); const match = text.match(/(\d+)/);
      if (match) { const target=parseInt(match[1]); const suffix=text.replace(/\d+/,''); const prefix=text.substring(0,text.indexOf(match[1]));
        let c=0; const dur=1500; const start=performance.now();
        function step(now){const p=Math.min((now-start)/dur,1);const e=1-Math.pow(1-p,3);c=Math.round(target*e);el.textContent=prefix+c+suffix;if(p<1)requestAnimationFrame(step);}
        requestAnimationFrame(step);
      } cObs.unobserve(el);
    }
  });
}, { threshold: 0.5 });
document.querySelectorAll('.elementor-heading-title').forEach(el => { if(/[\d$]/.test(el.textContent.trim().charAt(0))) cObs.observe(el); });
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Authoritative: dark navys, gold accents, serif-feel headings — Case results with dollar amounts — Free consultation form — Legal disclaimer in footer — Publish as draft
