Create a friendly, playful landing page for "Paws & Shine" — a premium pet grooming salon.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings — these are stripped automatically and cause layout issues.
- NEVER set _flex_size: 'grow' on any element.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children — the build-page tool calculates these automatically.

## DESIGN SYSTEM

### Color Palette
- Primary: #7C3AED (friendly purple)
- Primary Light: #A78BFA (lighter purple)
- Accent: #F472B6 (playful pink)
- Accent Light: #FBCFE8 (soft pink)
- Teal: #14B8A6 (fresh teal)
- Dark: #1E1B4B (deep indigo)
- Light Text: #FFFFFF
- Body Text: #6B7280 (gray)
- Light BG: #FAF5FF (lavender tint)
- Card BG: #FFFFFF
- Border: #E9D5FF

### Typography
- Headings: weight 700-800, title case — friendly, rounded feel
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#7C3AED
- Body text: size 16px, color=#6B7280, line-height 1.7

## IMAGE SOURCING — DO THIS FIRST
1. "pet grooming salon dog bath" — hero background
2. "cute dog grooming professional" — services
3. "cat grooming brushing" — services
4. "happy dog after grooming" — results
5. "pet grooming tools professional" — about
6. "small dog haircut grooming" — gallery
7. "pet spa treatment dog" — premium services
8. "pet grooming salon interior" — about

## SVG ICONS
Playful, rounded icons: Paw print, Bone, Scissors, Bath/bubbles, Heart, Star, Clock, Shield, Brush, Ribbon/bow.

## PAGE STRUCTURE

### 1. HERO SECTION (2-column: text left, booking right)
- Background: sideloaded grooming image, background_size='cover'
- Overlay: background_overlay_color='#1E1B4B', background_overlay_opacity={size:0.65,unit:'px'}
- Min-height: {size:620,unit:'px'}
- Row:
  - Left: "YOUR PET DESERVES THE BEST" label (#F472B6), "Where Every Pet Gets the Star Treatment" heading (#FFFFFF, 46px), subtext (#E9D5FF), "Book Now" + "Our Services" buttons
  - Right: Booking card — white bg, rounded corners, "Book a Grooming Session" heading, form (Pet Name, Owner Name, Phone, Pet Type [Dog, Cat, Other], Breed, Service [Full Groom, Bath & Brush, Nail Trim, Puppy's First Groom, Cat Grooming, De-shedding], "Schedule Appointment" button — #7C3AED bg)

### 2. SERVICES (6 cards in 3x2)
- Background: background_color='#FAF5FF'
- "OUR SERVICES" subtitle + "Tail-Wagging Treatments" heading
- 6 cards: paw icon, service name, description, price (#7C3AED bold)
  - Full Grooming Package ($65) | Bath & Brush ($35) | Nail Trim & Filing ($20) | Puppy's First Groom ($45) | Cat Grooming ($55) | De-shedding Treatment ($50)

### 3. WHY US (2-column)
- Background: background_color='#FFFFFF'
- Left: "WHY PAWS & SHINE" subtitle, heading, text, icon list: "Certified Groomers" | "Organic Products" | "Stress-Free Environment" | "No Cage Waiting"
- Right: Happy groomed dog image

### 4. GALLERY (3x2)
- Background: background_color='#FAF5FF'
- "HAPPY PETS" subtitle + "Before & After" heading
- 6 cute pet images

### 5. PRICING (3 cards)
- Background: background_color='#FFFFFF'
- "PACKAGES" subtitle + heading
- Small Dog ($45), Medium Dog ($55 — FEATURED), Large Dog ($70)
- Each: breed size, service list, "Book" button

### 6. TESTIMONIALS (3 cards)
- Background: background_color='#FAF5FF'
- Stars (#F472B6), quote, pet owner name + pet name in italic

### 7. CTA
- Background: background_color='#7C3AED'
- "Give Your Pet the Spa Day They Deserve" heading (#FFFFFF), "Book Appointment" button (#FFFFFF bg, #7C3AED text)

### 8. LOCATION (2-column)
- Background: background_color='#FFFFFF'
- Left: Address, phone, hours (Mon-Sat 8AM-6PM)
- Right: Google Maps

### 9. FOOTER
- Background: background_color='#1E1B4B'
- 4 columns — color=#A78BFA/#FFFFFF
- Copyright

## CUSTOM CSS

### Page-Level:
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(124, 58, 237, 0.3); }
.elementor-image img { transition: transform 0.5s ease; }
.elementor-image:hover img { transform: scale(1.05); }
.elementor-field-group input:focus, .elementor-field-group select:focus { border-color: #7C3AED !important; box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.15) !important; }
```

### Element-Level — Service Cards:
```css
selector { transition: transform 0.3s ease, box-shadow 0.3s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 15px 40px rgba(124, 58, 237, 0.12); }
```

### Element-Level — Gallery Images:
```css
selector { overflow: hidden; border-radius: 12px; }
selector img { transition: transform 0.5s ease; }
selector:hover img { transform: scale(1.08); }
```

## CUSTOM JAVASCRIPT (add-custom-js, wrap_dom_ready=true):
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.style.opacity = '1'; entry.target.style.transform = 'translateY(0)'; observer.unobserve(entry.target); }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.elementor-heading-title, .elementor-image, .elementor-icon-box-wrapper').forEach(el => {
  el.style.opacity = '0'; el.style.transform = 'translateY(25px)'; el.style.transition = 'opacity 0.6s ease, transform 0.6s ease'; observer.observe(el);
});
```

## EXECUTION ORDER
1. Search & sideload images → 2. Upload SVG icons → 3. Build page → 4. Page-level CSS → 5. Element-level CSS → 6. Custom JS

## FINAL CHECKLIST
- background_background + background_color on every colored container — All text colors explicit — NO flex_wrap or _flex_size — Playful/friendly: purples, pinks, teals, rounded corners — Services with pet-specific pricing — Booking form with pet details — Publish as draft
