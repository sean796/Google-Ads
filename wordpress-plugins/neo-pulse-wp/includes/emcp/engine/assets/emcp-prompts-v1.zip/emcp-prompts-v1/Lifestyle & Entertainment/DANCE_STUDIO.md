Create a vibrant, dynamic landing page for "Rhythm & Grace Dance Studio" — a dance school offering classes in multiple styles.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #AB47BC (vibrant purple)
- Primary Dark: #8E24AA (deeper purple for hover)
- Accent: #FF6F00 (energetic amber)
- Light BG: #F8F0FA (soft lavender)
- Dark: #1A1020 (deep purple-black)
- Dark Surface: #2A1E30
- Light Text: #FFFFFF
- Body Text: #4A4050 (purple-gray)
- Muted: #8A7E90
- Pink: #EC407A (dance pink)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700-800, title case — dynamic, energetic
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#AB47BC, weight=600
- Body text: size 16-17px, color=#4A4050, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Class cards: _animation='zoomIn', stagger 100ms
- About image: _animation='fadeInLeft'
- About text: _animation='fadeInRight', _animation_delay=200
- Instructor cards: _animation='fadeInUp', stagger 150ms
- CTA: _animation='bounceIn'

## IMAGE SOURCING — DO THIS FIRST
1. "dance class studio ballet" — hero
2. "hip hop dance class group" — classes
3. "ballet dancer elegant pose" — ballet
4. "salsa dance couple class" — latin
5. "contemporary dance movement" — contemporary
6. "dance studio interior mirror" — atmosphere
7. "children dance class kids" — kids
8. "dance performance stage recital" — events

## SVG ICONS
- Dance figure icon | Music note icon | Star icon | Heart icon | Clock icon | Calendar icon | Users icon | Phone icon | Map pin icon | Award icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded dance studio, overlay #1A1020 at 0.55
- Min-height 650px, centered:
  - Label: "DANCE · MOVE · INSPIRE" — color=#FF6F00, _animation='fadeInDown'
  - Heading: "Every Body Can Dance" — size=50px, weight=800, _animation='fadeInDown', _animation_delay=200
  - Subtext about all ages, all levels, professional instructors — _animation='fadeInUp', _animation_delay=400
  - Buttons: "Free Trial Class" (#AB47BC) | "Class Schedule" (border #FF6F00)

### 2. TRUST BAR
- Background: #AB47BC
- "1,000+ Students" | "8 Dance Styles" | "10 Instructors" | "Annual Showcase"

### 3. DANCE STYLES (2 rows of 4)
- Background: #F8F0FA
- Heading: "Find Your Style" — _animation='fadeInUp'
- 8 style cards (_animation='zoomIn', stagger 100ms):
  - Ballet | Hip Hop | Contemporary | Latin/Salsa | Jazz | Tap | Ballroom | Kids Dance
  - Each: image/icon, style name, age group, "from $20/class"

### 4. ABOUT (2-column)
- Background: #FFFFFF
- Image (elegant dancer) + story, mission, inclusive community

### 5. INSTRUCTORS (4 cards on dark)
- Background: #1A1020
- Heading: "Our Instructors" — color=#FFFFFF
- 4 instructor cards: Name, specialty, years, brief bio

### 6. PRICING (3 tiers)
- Background: #F8F0FA
- Drop-In ($20) | Monthly Unlimited ($129 — POPULAR) | Annual ($999 — BEST VALUE)

### 7. TESTIMONIALS (3 cards)
- Background: #FFFFFF

### 8. CTA
- Background: #AB47BC
- Heading: "Ready to Hit the Floor?" — _animation='bounceIn'
- Buttons: "Book Free Trial" | "Call (555) 901-2345"

### 9. FOOTER — Background: #1A1020

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.3s ease !important; }
.elementor-button:hover { transform: translateY(-2px) scale(1.02); box-shadow: 0 8px 25px rgba(171, 71, 188, 0.3); }
::selection { background: #AB47BC; color: #FFFFFF; }
```
### Element-Level CSS — Style Cards:
```css
selector { transition: transform 0.4s ease, box-shadow 0.4s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(26, 16, 32, 0.12); }
```

## FINAL CHECKLIST
- Dynamic, vibrant — purples, ambers, pinks
- Bouncy CTA animation for energy
- 8 dance styles with pricing
- Free trial prominently featured
- Tiered membership pricing
- NO flex_wrap or _flex_size — Publish as draft
