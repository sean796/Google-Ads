Create a strong, trustworthy landing page for "Ironclad Auto Repair" — a full-service auto repair and maintenance shop.

## CRITICAL LAYOUT RULES
- For side-by-side columns, use a parent container with flex_direction=row. Children will auto-get content_width=full with equal percentage widths.
- NEVER set flex_wrap or _flex_size in any container settings.
- Top-level containers should use content_width=boxed (default).
- Do NOT manually set content_width or width on row children.

## DESIGN SYSTEM

### Color Palette
- Primary: #D32F2F (bold red)
- Primary Dark: #B71C1C (deeper red for hover)
- Accent: #FFC107 (warning yellow/gold)
- Light BG: #F5F5F5 (light gray)
- Dark: #1A1A1A (garage dark)
- Dark Surface: #252525
- Light Text: #FFFFFF
- Body Text: #555555 (neutral gray)
- Muted: #888888
- Blue: #1565C0 (tool blue accent)
- Card BG: #FFFFFF

### Typography
- Headings: weight 700-800, uppercase — strong, industrial
- Section subtitles: uppercase, letter-spacing=3px, size=12px, color=#D32F2F, weight=700
- Body text: size 16px, color=#555555, line-height 1.8

## ENTRANCE ANIMATIONS
- Hero heading: _animation='fadeInDown', _animation_delay=200
- Hero subtext: _animation='fadeInUp', _animation_delay=400
- Hero buttons: _animation='fadeInUp', _animation_delay=600
- Section headings: _animation='fadeInUp'
- Service cards: _animation='fadeInUp', stagger 100ms
- About image: _animation='fadeInLeft'
- CTA: _animation='zoomIn'

## IMAGE SOURCING — DO THIS FIRST
1. "auto repair shop garage mechanic" — hero
2. "mechanic working car engine" — services
3. "brake repair automobile" — brakes
4. "oil change car service" — maintenance
5. "auto shop interior professional" — atmosphere
6. "car diagnostic computer scan" — diagnostics
7. "tire rotation wheel alignment" — tires
8. "mechanic team professional" — team

## SVG ICONS
- Wrench icon | Car icon | Shield icon | Gauge icon | Clock icon | Phone icon | Check icon | Map pin icon | Star icon | Gear icon

## PAGE STRUCTURE

### 1. HERO
- Background: sideloaded auto shop, overlay #1A1A1A at 0.65
- Min-height 650px
- Row: Left text + Right appointment card
  - Label: "HONEST · RELIABLE · EXPERT" — color=#FFC107, _animation='fadeInDown'
  - Heading: "AUTO REPAIR YOU CAN TRUST" — size=48px, weight=800, uppercase, _animation='fadeInDown', _animation_delay=200
  - Subtext — _animation='fadeInUp', _animation_delay=400
  - Buttons: "BOOK APPOINTMENT" (#D32F2F, sharp corners) | "CALL NOW" (border #FFC107, text #FFC107)
  - Right: "Free Inspection" card — first-visit offer

### 2. TRUST BAR
- Background: #D32F2F
- "ASE Certified" | "20+ Years" | "50,000+ Repairs" | "12-Month Warranty"

### 3. SERVICES (2 rows of 3)
- Background: #F5F5F5
- 6 cards: Oil Change & Lube | Brake Repair | Engine Diagnostics | Tire Services | Transmission | AC & Heating
- Each with icon, service name, starting price

### 4. WHY US (2-column)
- Background: #FFFFFF
- Image + experience, ASE certified, warranty, upfront pricing, all makes/models

### 5. SPECIALS (dark section)
- Background: #1A1A1A
- Heading: "THIS MONTH'S SPECIALS" — color=#FFC107
- 3 offer cards: "Oil Change $29.99" | "Brake Inspection FREE" | "AC Check $49.99"
- Limited time urgency

### 6. REVIEWS (3 cards)
- Background: #F5F5F5
- Star ratings (#FFC107)

### 7. LOCATION
- Background: #FFFFFF
- Address, hours (Mon-Fri 7:30AM-6PM, Sat 8AM-2PM), Google Maps

### 8. CTA
- Background: #D32F2F
- Heading: "DON'T WAIT — SCHEDULE TODAY" — weight=800, _animation='zoomIn'
- Buttons: "BOOK ONLINE" | "CALL (555) 345-6789"

### 9. FOOTER — Background: #1A1A1A

## CUSTOM CSS (minimal)
```css
html { scroll-behavior: smooth; }
.elementor-button { transition: all 0.25s ease !important; text-transform: uppercase !important; letter-spacing: 2px !important; }
.elementor-button:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(211, 47, 47, 0.4); }
::selection { background: #D32F2F; color: #FFFFFF; }
```
### Element-Level CSS — Service Cards:
```css
selector { transition: transform 0.3s ease, box-shadow 0.3s ease; }
selector:hover { transform: translateY(-8px); box-shadow: 0 20px 50px rgba(26, 26, 26, 0.12); }
```

## FINAL CHECKLIST
- Strong, industrial — reds, yellows, dark grays
- Bold uppercase typography
- Monthly specials section with urgency
- Trust: ASE certified, warranty, years
- Sharp corners on buttons
- NO flex_wrap or _flex_size — Publish as draft
